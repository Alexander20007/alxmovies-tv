-- ============================================================================
-- ALXmovies — SALAS: RETOMAR EXATAMENTE ONDE PARARAM
-- Rode DEPOIS de watch-rooms.sql. Só ACRESCENTA uma função (não altera nada que já existe). Pode rodar de novo.
--
-- Por que: a posição da sala só era gravada pelo ANFITRIÃO (update_watch_room_state). Quando o último a sair era um convidado,
-- ou o anfitrião saía sem pausar, a posição ficava velha — e o app ainda ignorava a posição salva ao abrir a sala.
-- Agora o app grava a posição ao sair (e a cada ~10 s quando só resta uma pessoa) usando esta função, e retoma dali.
-- ============================================================================
create or replace function public.save_watch_room_position(p_room_id uuid, p_position_seconds numeric)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is null then raise exception 'não autenticado'; end if;
  if p_position_seconds is null or p_position_seconds < 0 or p_position_seconds > 86400 then raise exception 'posição inválida'; end if;
  if not exists (select 1 from watch_room_members m where m.room_id = p_room_id and m.user_id = auth.uid()) then
    raise exception 'você não está nesta sala';
  end if;

  -- O anfitrião sempre pode gravar. Um convidado só grava se o anfitrião está sem atualizar há mais de 12 s
  -- (ou seja, não há ninguém controlando) — assim nunca sobrescreve o anfitrião que está assistindo ao vivo.
  update watch_rooms
     set is_playing = false,
         position_seconds = p_position_seconds,
         state_updated_at = now()
   where id = p_room_id
     and is_active = true
     and (host_user_id = auth.uid() or state_updated_at < now() - interval '12 seconds');
end;
$$;

revoke execute on function public.save_watch_room_position(uuid, numeric) from public, anon;
grant  execute on function public.save_watch_room_position(uuid, numeric) to authenticated;

import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { checkAccess, type AccessResult } from "@/services/access";
import { clearEndpoints } from "@/lib/endpoints";

/** Tela de bloqueio por IP/país (definido pelo admin em Admin → Bloqueios). O dono nunca é bloqueado. */
export function AccessGate({ children }: { children: ReactNode }) {
  const [res, setRes] = useState<AccessResult>({ blocked: false });
  const [busy, setBusy] = useState(false);
  const last = useRef(0);

  const run = useCallback(async () => {
    last.current = Date.now();
    const r = await checkAccess();
    if (r.blocked) clearEndpoints();
    setRes(r);
  }, []);

  useEffect(() => {
    void run();
    const onVis = () => { if (document.visibilityState === "visible" && Date.now() - last.current > 60_000) void run(); };
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, [run]);

  if (!res.blocked) return <>{children}</>;
  return (
    <div className="gate-blocked" role="alert">
      <div className="gate-ico" aria-hidden="true">🚫</div>
      <h1>Acesso indisponível</h1>
      <p>{res.kind === "ip" ? "O ALXmovies não está disponível para esta rede neste momento." : "O ALXmovies não está disponível na sua região neste momento."}</p>
      <button type="button" disabled={busy} onClick={async () => { setBusy(true); await run(); setBusy(false); }}>{busy ? "Verificando…" : "Tentar de novo"}</button>
      <small>Se você acha que isso é um engano, entre em contato com o suporte.</small>
    </div>
  );
}

import { useEffect, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { PlayerLoading } from "@/components/player/PlayerLoading";
import { Icon } from "@/components/Icon";
import { useChannelFavorites } from "@/hooks/useChannelFavorites";
import { enterFullscreenLandscape } from "@/lib/media";
import { channelGroupLabel, getChannelProgramGuide, getChannelStatus, type Channel, type ProgramInfo } from "@/services/channels";
import { isNative, shareLink } from "@/lib/native";
import { useBackClose } from "@/hooks/useBackClose";
import { useImmersiveLandscape } from "@/hooks/useImmersiveLandscape";
import { useWakeLock } from "@/hooks/useWakeLock";

const clock = (iso: string | null) => {
  if (!iso) return null;
  const d = new Date(iso);
  return isNaN(d.getTime()) ? null : d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
};
const progressOf = (p: ProgramInfo | null | undefined) => {
  if (!p?.inicio || !p.fim) return null;
  const a = new Date(p.inicio).getTime(), b = new Date(p.fim).getTime();
  return b > a ? Math.max(0, Math.min(100, ((Date.now() - a) / (b - a)) * 100)) : null;
};

interface Props { list: Channel[]; index: number; onIndex: (i: number) => void; onClose: () => void }

/**
 * Player de canais com o mesmo visual do player de filmes: tela de carregamento com o logo, controles de vidro que somem sozinhos,
 * título + AO VIVO + programa atual, barra do programa e botões Anterior/Próximo. (O vídeo do canal é uma página incorporada.)
 */
export function ChannelPlayer({ list, index, onIndex, onClose }: Props) {
  const channel = list[index];
  const { isFavorite, toggle, busy } = useChannelFavorites();
  const wrap = useRef<HTMLDivElement>(null);
  const hideTimer = useRef<number>();
  const [ui, setUi] = useState(true);
  const [loaded, setLoaded] = useState(false);
  const [guide, setGuide] = useState(false);
  const [shared, setShared] = useState(false);
  useImmersiveLandscape(true);
  useWakeLock(true);
  useBackClose(true, () => { if (guide) setGuide(false); else onClose(); });

  const epg = useQuery({ queryKey: ["epg", channel?.stream], queryFn: () => getChannelProgramGuide(channel.stream), enabled: !!channel, staleTime: 60_000, refetchInterval: 60_000 });

  const bump = () => {
    setUi(true);
    window.clearTimeout(hideTimer.current);
    hideTimer.current = window.setTimeout(() => setUi(false), 4500);
  };
  useEffect(() => {
    setLoaded(false); setGuide(false); bump();
    const t = window.setTimeout(() => setLoaded(true), 12000); // se o vídeo não avisar que carregou, libera a tela mesmo assim
    return () => { window.clearTimeout(t); window.clearTimeout(hideTimer.current); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [channel?.stream]);

  // web: tela cheia/paisagem ao abrir e a cada troca de canal (o clique que abriu conta como gesto)
  useEffect(() => { if (!isNative && channel && wrap.current) enterFullscreenLandscape(wrap.current); }, [channel?.stream]);
  useEffect(() => () => { if (document.fullscreenElement) void document.exitFullscreen?.(); }, []);

  if (!channel) return null;
  const name = channel.name || "Canal";
  const group = channelGroupLabel(channel.group);
  const g = epg.data;
  const pct = progressOf(g?.atual);
  const fav = isFavorite(channel.stream);
  const online = getChannelStatus(channel.stream)?.online;
  const go = (d: number) => onIndex((index + d + list.length) % list.length);

  async function share() {
    const url = `${window.location.origin}/home?openChannel=${encodeURIComponent(channel.stream)}`;
    const r = await shareLink({ title: `${name} — ALXmovies`, url });
    if (r === "copied") { setShared(true); setTimeout(() => setShared(false), 2000); }
  }

  return (
    <div className="cpl" ref={wrap}>
      <iframe key={channel.stream} src={channel.stream} className="cpl-frame" title={name} onLoad={() => setLoaded(true)}
        allow="autoplay; fullscreen; encrypted-media" allowFullScreen referrerPolicy="no-referrer"
        sandbox="allow-scripts allow-same-origin allow-forms allow-presentation" />

      {!loaded && <PlayerLoading title={name} subtitle={group || "Ao vivo"} poster={channel.logo ?? undefined} text="Conectando ao canal…" />}
      {!loaded && <button type="button" className="cpl-x" aria-label="Voltar" onClick={onClose}><Icon name="arrowLeft" size={24} strokeWidth={2.4} /></button>}

      {loaded && !ui && <button type="button" className="cpl-handle" aria-label="Mostrar controles" onClick={bump}><Icon name="more" size={22} /></button>}

      {loaded && (
        <div className={`cpl-ui${ui ? " on" : ""}`}>
          <div className="cpl-top">
            <button type="button" className="cpl-round" aria-label="Voltar" onClick={onClose}><Icon name="arrowLeft" size={24} strokeWidth={2.4} /></button>
            <span className="cpl-logo">{channel.logo ? <img src={channel.logo} alt="" onError={(e) => { e.currentTarget.style.display = "none"; }} /> : "📡"}</span>
            <div className="cpl-titles">
              <b>{name}</b>
              <small>{g?.atual ? g.atual.titulo : group || "Ao vivo"}</small>
            </div>
            <span className={`cc-badge cpl-badge ${online === false ? "off" : "on"}`}><i />{online === false ? "OFFLINE" : "AO VIVO"}</span>
            <button type="button" className={`cpl-round${fav ? " fav" : ""}`} disabled={busy} aria-label="Favoritar" onClick={() => { toggle(channel); bump(); }}>
              <Icon name="heart" size={22} fill={fav ? "currentColor" : "none"} />
            </button>
            <button type="button" className="cpl-round" aria-label="Compartilhar" onClick={() => { void share(); bump(); }}>
              <Icon name={shared ? "check" : "share"} size={21} />
            </button>
          </div>

          <div className="cpl-bottom">
            {g?.atual && pct !== null && (
              <div className="cpl-prog">
                <span>{clock(g.atual.inicio)}</span>
                <div><i style={{ width: `${pct}%` }} /></div>
                <span>{clock(g.atual.fim)}</span>
              </div>
            )}
            <div className="cpl-pills">
              <button type="button" onClick={() => { go(-1); bump(); }}><Icon name="chevronRight" size={18} strokeWidth={2.6} className="flip" /> Anterior</button>
              <span className="cpl-pos">{index + 1} / {list.length}</span>
              <button type="button" onClick={() => { setGuide(true); bump(); }}><Icon name="list" size={18} /> Programação</button>
              <button type="button" className="acc" onClick={() => { go(1); bump(); }}>Próximo <Icon name="chevronRight" size={18} strokeWidth={2.6} /></button>
            </div>
          </div>
        </div>
      )}

      {guide && (
        <div className="cpl-sheet-bg" onClick={(e) => e.target === e.currentTarget && setGuide(false)}>
          <div className="cpl-sheet">
            <div className="dv-sheet-grip" />
            <h2>{name}</h2>
            {g?.atual ? (
              <div className="cpl-prog-card">
                <small><span className="cn-live"><i />AGORA</span>{clock(g.atual.inicio) && clock(g.atual.fim) ? ` · ${clock(g.atual.inicio)}–${clock(g.atual.fim)}` : ""}</small>
                <b>{g.atual.titulo}</b>
                {pct !== null && <div className="cn-bar"><i style={{ width: `${pct}%` }} /></div>}
              </div>
            ) : <p className="cn-muted">Guia de programação indisponível para este canal.</p>}
            {g?.proximo && <div className="cpl-prog-card next"><small>A SEGUIR{clock(g.proximo.inicio) ? ` · ${clock(g.proximo.inicio)}` : ""}</small><b>{g.proximo.titulo}</b></div>}
            <button type="button" className="dv-btn" onClick={() => setGuide(false)}>Fechar</button>
          </div>
        </div>
      )}
    </div>
  );
}

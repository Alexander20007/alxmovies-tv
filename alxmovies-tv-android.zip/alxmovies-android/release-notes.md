## Novo
- Login da Smart TV só com código: sem e-mail nem senha, digite os 8 números gerados no celular (foto de perfil → Entrar na Smart TV)
- Versão para Android TV / Smart TV: feita para o controle remoto (setas, OK e voltar)
- Barra lateral de navegação (Buscar, Início, Canais, Salas, Minha lista e mais)
- Player em tela cheia com controle remoto: ← → pulam, OK pausa, teclas de mídia, canal anterior/próximo
- Destaque da Home com botões Assistir e Detalhes; tela de detalhes em formato horizontal
- Teclado da TV abre ao apertar OK num campo de texto

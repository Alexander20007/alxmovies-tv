import { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Icon, type IconName } from "@/components/Icon";
import { ProfileSheet } from "@/components/ProfileSheet";
import { useChannelsUi } from "@/context/ChannelsUiContext";
import { useProfile } from "@/context/ProfileContext";
import { useNotificationFeed } from "@/hooks/useNotificationFeed";
import { useUnreadTotal } from "@/hooks/useSocialData";

interface Dest { to: string; icon: IconName; label: string; badge?: number }

/** Barra lateral da TV: só ícones; quando o foco entra nela, abre mostrando os nomes (como Netflix / YouTube na TV). */
export function TvRail() {
  const { pathname } = useLocation();
  const { openPanel } = useChannelsUi();
  const { activeProfile } = useProfile();
  const unread = useUnreadTotal().data ?? 0;
  const { unreadCount } = useNotificationFeed();
  const [profileOpen, setProfileOpen] = useState(false);

  useEffect(() => { setProfileOpen(false); }, [pathname]);

  const top: Dest[] = [
    { to: "/search", icon: "search", label: "Buscar" },
    { to: "/home", icon: "home", label: "Início" },
    { to: "", icon: "tv", label: "Canais ao vivo" },
    { to: "/salas", icon: "users", label: "Salas" },
    { to: "/mylist", icon: "bookmark", label: "Minha lista" },
  ];
  const more: Dest[] = [
    { to: "/amigos", icon: "userPlus", label: "Amigos" },
    { to: "/mensagens", icon: "chat", label: "Mensagens", badge: unread },
    { to: "/notificacoes", icon: "bell", label: "Avisos", badge: unreadCount },
    { to: "/laura", icon: "sparkles", label: "Laura IA" },
  ];

  const item = (d: Dest) => {
    const active = d.to !== "" && pathname === d.to;
    const inner = (
      <>
        <span className="tvr-ico">
          <Icon name={d.icon} size={26} strokeWidth={active ? 2.5 : 2} />
          {!!d.badge && d.badge > 0 && <i className="tvr-badge">{d.badge > 9 ? "9+" : d.badge}</i>}
        </span>
        <span className="tvr-label">{d.label}</span>
      </>
    );
    return d.to === ""
      ? <button key="canais" type="button" className="tvr-item" onClick={openPanel}>{inner}</button>
      : <Link key={d.to} to={d.to} className={`tvr-item${active ? " active" : ""}`} aria-current={active ? "page" : undefined}>{inner}</Link>;
  };

  const initial = (activeProfile?.name ?? "?").charAt(0).toUpperCase();
  return (
    <>
      <nav className="tvr" data-tv-rail aria-label="Navegação principal">
        <button type="button" className="tvr-item tvr-profile" onClick={() => setProfileOpen(true)} aria-label={`Perfil ${activeProfile?.name ?? ""}`}>
          <span className="tvr-ico tvr-avatar" style={activeProfile?.avatar ? undefined : { background: activeProfile?.color_theme || "#555" }}>
            {activeProfile?.avatar ? <img src={activeProfile.avatar} alt="" onError={(e) => e.currentTarget.remove()} /> : initial}
          </span>
          <span className="tvr-label">{activeProfile?.name ?? "Perfil"}</span>
        </button>
        <div className="tvr-group">{top.map(item)}</div>
        <div className="tvr-group tvr-more">{more.map(item)}</div>
      </nav>
      <div className={`native-scrim${profileOpen ? " show" : ""}`} onClick={() => setProfileOpen(false)} />
      <ProfileSheet open={profileOpen} onClose={() => setProfileOpen(false)} />
    </>
  );
}

import { useEffect, useState } from "react";
import { Navigate, useLocation, useNavigate, useSearchParams } from "react-router-dom";
import { AuthBackground } from "@/components/AuthBackground";
import { useAuth } from "@/context/AuthContext";
import { isReservedName, RESERVED_MSG } from "@/lib/reservedNames";
import { requestPasswordReset } from "@/services/account";
import { BusyButton } from "@/components/Spinner";
import { isTV } from "@/lib/tv";
import TvLogin from "@/pages/TvLogin";
import { getGoogleLoginConfig, type GoogleLoginConfig } from "@/lib/googleLogin";

type Mode = "login" | "signup" | "forgot";

const ERRORS: Record<string, string> = {
  "Invalid login credentials": "E-mail ou senha incorretos.",
  "User already registered": "Já existe uma conta com esse e-mail.",
  "Email not confirmed": "Confirme seu e-mail antes de entrar.",
};
const translate = (msg: string) => ERRORS[msg] ?? msg;
const errMsg = (e: unknown) => (e instanceof Error ? e.message : "Erro inesperado");

const COPY: Record<Mode, { title: string; subtitle: string; submit: string; switchText: string; switchLink: string }> = {
  login: { title: "Bem-vindo de volta", subtitle: "Entre para continuar assistindo.", submit: "Entrar", switchText: "Novo por aqui?", switchLink: "Criar conta" },
  signup: { title: "Criar sua conta", subtitle: "Leva menos de um minuto.", submit: "Cadastrar", switchText: "Já tem conta?", switchLink: "Entrar" },
  forgot: { title: "Recuperar senha", subtitle: "Enviamos um link para você criar uma nova senha.", submit: "Enviar link de recuperação", switchText: "Lembrou a senha?", switchLink: "Voltar para o login" },
};

function strength(pw: string) {
  let score = 0;
  if (pw.length >= 6) score++;
  if (pw.length >= 10) score++;
  if (/[A-Z]/.test(pw) && /[0-9]/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  return { pct: [0, 25, 55, 80, 100][score], color: ["#ff2d55", "#ff2d55", "#e0a11c", "#e0a11c", "#2e9e4a"][score] };
}

/** Na TV só existe o login por código (sem e-mail/senha); no celular/web, o login de sempre. */
export default function Login() {
  return isTV ? <TvLogin /> : <PhoneLogin />;
}

function PhoneLogin() {
  const { user, signIn, signUp, signInWithGoogle } = useAuth();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const from = (useLocation().state as { from?: string } | null)?.from ?? "/home";

  const [mode, setMode] = useState<Mode>("login");
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [age, setAge] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [google, setGoogle] = useState<GoogleLoginConfig>({ enabled: false, webClientId: "" });
  const [googleBusy, setGoogleBusy] = useState(false);


  useEffect(() => { void getGoogleLoginConfig().then(setGoogle); }, []);

  useEffect(() => {
    if (params.get("expired") === "guest" || params.get("guest") === "ended") setMessage("O acesso de convidado foi encerrado. Entre com a sua conta ou crie uma conta nova (leva menos de um minuto).");
    if (params.get("reset") === "success") setMessage("Senha atualizada! Entre com a nova senha.");
  }, [params]);

  if (user) return <Navigate to="/profiles" replace state={{ from }} />;

  const copy = COPY[mode];
  const toProfiles = () => navigate("/profiles", { replace: true, state: { from } });
  const changeMode = (m: Mode) => { setMode(m); setError(""); setMessage(""); };
  const fail = (m: string) => { setError(m); setMessage(""); };

  async function submit() {
    setError(""); setMessage("");
    const mail = email.trim();

    if (mode === "forgot") {
      if (!mail) return fail("Digite seu e-mail.");
      setBusy(true);
      try { await requestPasswordReset(mail); setMessage("Se esse e-mail tiver uma conta, enviamos um link de recuperação. Confira sua caixa de entrada (e o spam)."); }
      catch (e) { fail(translate(errMsg(e))); }
      finally { setBusy(false); }
      return;
    }

    if (!mail || !password) return fail("Preencha e-mail e senha.");
    if (password.length < 6) return fail("A senha precisa ter pelo menos 6 caracteres.");
    if (mode === "signup") {
      const u = username.trim();
      if (!u) return fail("Escolha um nome de usuário.");
      if (!/^[a-zA-Z0-9_.]{3,24}$/.test(u)) return fail("Nome de usuário deve ter 3–24 caracteres (letras, números, _ ou .).");
      if (isReservedName(u)) return fail(RESERVED_MSG);
      if (!age) return fail("Informe sua idade.");
    }

    setBusy(true);
    try {
      if (mode === "login") { await signIn(mail, password); toProfiles(); }
      else {
        await signUp(mail, password, { age: Number(age), username: username.trim(), phone: phone.trim() || null });
        setMode("login");
        setMessage("Conta criada! Verifique seu e-mail para confirmar antes de entrar.");
      }
    } catch (e) { fail(translate(errMsg(e))); }
    finally { setBusy(false); }
  }

  async function googleLogin() {
    setError(""); setMessage(""); setGoogleBusy(true);
    try { if (await signInWithGoogle(google)) toProfiles(); }
    catch (e) { fail(translate(errMsg(e))); }
    finally { setGoogleBusy(false); }
  }

  const st = strength(password);
  const onEnter = (e: React.KeyboardEvent) => { if (e.key === "Enter") void submit(); };

  return (
    <>
      <div className="auth-screen">
        <AuthBackground />
        <div style={{ position: "relative", display: "flex", flexDirection: "column", alignItems: "center" }}>
          <div className="auth-brand"><div className="logo-mark">A</div><span>ALXmovies</span></div>

          <div className="auth-box">
            <h1>{copy.title}</h1>
            <p className="auth-subtitle">{copy.subtitle}</p>
            <p className="auth-error" style={{ display: error ? "block" : "none" }}>{error}</p>
            <p className="auth-message" style={{ display: message ? "block" : "none" }}>{message}</p>

            <div className="auth-field">
              <label htmlFor="email">E-mail</label>
              <input id="email" type="email" placeholder="voce@email.com" autoComplete="email" value={email}
                onChange={(e) => setEmail(e.target.value)} onKeyDown={(e) => mode === "forgot" && onEnter(e)} />
            </div>

            {mode === "signup" && (
              <div className="auth-row-2" style={{ display: "flex" }}>
                <div className="auth-field">
                  <label htmlFor="username">Nome de usuário</label>
                  <input id="username" type="text" placeholder="ex: joao123" maxLength={24} autoComplete="username" value={username} onChange={(e) => setUsername(e.target.value)} />
                </div>
                <div className="auth-field">
                  <label htmlFor="phone">Telefone</label>
                  <input id="phone" type="tel" placeholder="(11) 91234-5678" maxLength={20} autoComplete="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
                </div>
              </div>
            )}

            {mode !== "forgot" && (
              <div className="auth-field" style={{ display: "flex" }}>
                <label htmlFor="password">Senha</label>
                <div className="password-wrap">
                  <input id="password" type={showPw ? "text" : "password"} placeholder="••••••••" autoComplete={mode === "login" ? "current-password" : "new-password"}
                    value={password} onChange={(e) => setPassword(e.target.value)} onKeyDown={onEnter} />
                  <button type="button" className="password-toggle" aria-label="Mostrar senha" onClick={() => setShowPw((v) => !v)}>{showPw ? "🙈" : "👁"}</button>
                </div>
                {mode === "signup" && (
                  <div className="password-strength" style={{ display: "block" }}>
                    <div className="password-strength-bar" style={{ width: `${st.pct}%`, background: st.color }} />
                  </div>
                )}
              </div>
            )}

            {mode === "signup" && (
              <div className="auth-field" style={{ display: "flex" }}>
                <label htmlFor="age">Idade</label>
                <input id="age" type="number" min={1} max={120} placeholder="Sua idade" value={age} onChange={(e) => setAge(e.target.value)} />
              </div>
            )}

            {mode === "login" && <p className="auth-forgot"><a onClick={() => changeMode("forgot")}>Esqueceu a senha?</a></p>}

            <BusyButton className="auth-submit" loading={busy} onClick={() => void submit()}>
              {busy ? (mode === "login" ? "Entrando..." : mode === "signup" ? "Cadastrando..." : "Enviando...") : copy.submit}
            </BusyButton>

            {mode !== "forgot" && google.enabled && (
              <>
                <div className="auth-divider" style={{ display: "flex" }}><span>ou</span></div>
                <button type="button" className="auth-google-btn" disabled={googleBusy || busy} onClick={() => void googleLogin()}>
                  <svg viewBox="0 0 48 48" width="20" height="20" aria-hidden="true">
                    <path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.9 2.4 30.4 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.9 6.1C12.4 13.6 17.7 9.5 24 9.5z" />
                    <path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.6 5.9c4.4-4.1 7-10.1 7-17.6z" />
                    <path fill="#FBBC05" d="M10.5 28.7c-.5-1.4-.8-3-.8-4.7s.3-3.2.8-4.7l-7.9-6.1C.9 16.4 0 20.1 0 24s.9 7.6 2.6 10.8l7.9-6.1z" />
                    <path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.6-5.9c-2.1 1.4-4.9 2.3-8.3 2.3-6.3 0-11.6-4.1-13.5-9.8l-7.9 6.1C6.5 42.6 14.6 48 24 48z" />
                  </svg>
                  {googleBusy ? "Abrindo o Google..." : "Continuar com Google"}
                </button>
              </>
            )}

            <p className="auth-switch">
              <span>{copy.switchText}</span>{" "}
              <a onClick={() => changeMode(mode === "login" ? "signup" : "login")}>{copy.switchLink}</a>
            </p>
            {mode === "signup" && (
              <p className="auth-terms" style={{ display: "block" }}>
                Ao criar uma conta, você concorda com o uso do serviço para fins pessoais e confirma que os dados informados são verdadeiros.
              </p>
            )}
          </div>
        </div>
      </div>

    </>
  );
}

import { useCallback, useEffect, useRef, useState } from "react";
import { Navigate, useLocation, useNavigate } from "react-router-dom";
import { AuthBackground } from "@/components/AuthBackground";
import { useAuth } from "@/context/AuthContext";
import { storage } from "@/lib/storage";
import { signInWithTvCode } from "@/services/tvLogin";

const LEN = 8;
const KEYS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "del", "0", "ok"] as const;

/** Login da Smart TV: sem e-mail nem senha, só o código de 8 números gerado no celular. */
export default function TvLogin() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const from = (useLocation().state as { from?: string } | null)?.from ?? "/home";
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const busyRef = useRef(false);

  const submit = useCallback(async (value: string) => {
    if (busyRef.current) return;
    if (value.length !== LEN) { setError(`Digite os ${LEN} números do código.`); return; }
    busyRef.current = true; setBusy(true); setError("");
    try {
      storage.clearGuest();
      await signInWithTvCode(value);
      navigate("/profiles", { replace: true, state: { from } });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Não foi possível entrar agora.");
      setCode("");
    } finally { busyRef.current = false; setBusy(false); }
  }, [navigate, from]);

  const press = useCallback((d: string) => {
    if (busyRef.current) return;
    setError("");
    setCode((c) => {
      const next = (c + d).slice(0, LEN);
      if (next.length === LEN && c.length < LEN) setTimeout(() => void submit(next), 250);
      return next;
    });
  }, [submit]);
  const erase = useCallback(() => { if (!busyRef.current) { setError(""); setCode((c) => c.slice(0, -1)); } }, []);

  // números do controle remoto (teclado numérico) e Backspace/Delete
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (/^[0-9]$/.test(e.key)) { e.preventDefault(); press(e.key); }
      else if (e.key === "Backspace" || e.key === "Delete") { e.preventDefault(); erase(); }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [press, erase]);

  if (user) return <Navigate to="/profiles" replace state={{ from }} />;

  return (
    <div className="auth-screen tvl">
      <AuthBackground />
      <div className="tvl-card">
        <section className="tvl-info">
          <div className="auth-brand"><div className="logo-mark">A</div><span>ALXmovies</span></div>
          <h1>Entrar com código</h1>
          <ol className="tvl-steps">
            <li><b>1</b><span>No celular, abra o app ALXmovies já logado.</span></li>
            <li><b>2</b><span>Toque na sua <em>foto de perfil</em> e em <em>Entrar na Smart TV</em>.</span></li>
            <li><b>3</b><span>Digite aqui os <em>8 números</em> que aparecerem. O código vale 10 minutos.</span></li>
          </ol>
        </section>

        <section className="tvl-pad">
          <div className="tvl-code" role="status" aria-live="polite" aria-label={`Código: ${code || "vazio"}`}>
            {Array.from({ length: LEN }, (_, i) => (
              <span key={i} className={`tvl-cell${i === code.length ? " cur" : ""}${code[i] ? " on" : ""}`}>{code[i] ?? ""}</span>
            ))}
          </div>
          <p className={`tvl-msg${error ? " err" : ""}`} aria-live="assertive">
            {busy ? "Entrando…" : error || "Use o teclado numérico do controle ou os botões abaixo."}
          </p>
          <div className="tvl-keys">
            {KEYS.map((k) => k === "del"
              ? <button key={k} type="button" className="tvl-key fn" onClick={erase} disabled={busy} aria-label="Apagar">⌫</button>
              : k === "ok"
                ? <button key={k} type="button" className="tvl-key fn go tv-primary" onClick={() => void submit(code)} disabled={busy}>Entrar</button>
                : <button key={k} type="button" className="tvl-key" onClick={() => press(k)} disabled={busy}
                    {...(k === "5" ? { "data-tv-autofocus": "" } : {})}>{k}</button>)}
          </div>
        </section>
      </div>
    </div>
  );
}

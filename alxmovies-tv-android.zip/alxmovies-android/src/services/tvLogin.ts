import { CONFIG } from "@/lib/config";
import { apiFetch } from "@/lib/proxy";
import { supabase } from "@/lib/supabase";

/** Só os dígitos do código (aceita espaço ou traço). */
export const tvCodeDigits = (code: string) => code.replace(/\D/g, "").slice(0, 8);

/**
 * Entra na conta com o código de 8 números gerado no celular (foto de perfil → "Entrar na Smart TV").
 * Chama a função de borda `tv-login` e coloca a sessão devolvida no Supabase. Erros já vêm em português.
 */
export async function signInWithTvCode(code: string): Promise<void> {
  const digits = tvCodeDigits(code);
  if (digits.length !== 8) throw new Error("Digite os 8 números do código.");

  const url = `${CONFIG.FUNCTIONS_URL}/tv-login`;
  const init: RequestInit = {
    method: "POST",
    headers: {
      apikey: CONFIG.SUPABASE_ANON_KEY,
      Authorization: `Bearer ${CONFIG.SUPABASE_ANON_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ code: digits }),
  };

  let res: Response;
  try {
    res = await (CONFIG.USE_PROXY ? apiFetch(url, init) : fetch(url, init));
  } catch {
    throw new Error("Sem conexão com a internet. Verifique a rede da TV e tente de novo.");
  }

  let body: { session?: { access_token?: string; refresh_token?: string }; error?: string } = {};
  try { body = await res.json(); } catch { /* resposta sem JSON */ }

  if (!res.ok) {
    if (body.error) throw new Error(body.error);
    if (res.status === 429) throw new Error("Muitas tentativas. Aguarde alguns minutos e tente de novo.");
    if (res.status === 400) throw new Error("Código inválido ou expirado. Gere um novo no celular.");
    throw new Error("Não foi possível entrar agora. Tente de novo em instantes.");
  }

  const s = body.session;
  if (!s?.access_token || !s?.refresh_token) throw new Error("Não foi possível entrar agora. Tente de novo em instantes.");
  const { error } = await supabase.auth.setSession({ access_token: s.access_token, refresh_token: s.refresh_token });
  if (error) throw new Error("Não foi possível entrar agora. Gere um novo código no celular.");
}

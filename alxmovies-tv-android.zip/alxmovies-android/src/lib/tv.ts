import { Capacitor, registerPlugin } from "@capacitor/core";

/**
 * true quando o app roda como app de Android TV / Smart TV (controle remoto, sem toque).
 * Este projeto é o app de TV: dentro do APK é sempre true. Para testar a interface de celular no mesmo código,
 * compile com VITE_TV=false.
 */
export const isTV: boolean = Capacitor.isNativePlatform() && (import.meta.env.VITE_TV as string | undefined) !== "false";

interface AlxTvPlugin {
  /** Abre o teclado na tela (o WebView da TV não abre sozinho ao focar um campo pelo controle). */
  showKeyboard(): Promise<void>;
  hideKeyboard(): Promise<void>;
  isKeyboardOpen(): Promise<{ open: boolean }>;
  /** Informações da TV (para o Diagnóstico). */
  info(): Promise<{ tv: boolean; widthPx: number; heightPx: number; densityDpi: number; cssWidth: number }>;
}
export const AlxTv = registerPlugin<AlxTvPlugin>("AlxTv");

/** Códigos de tecla do controle remoto que o WebView nem sempre traduz para `key`. */
export const KEYCODE = { ENTER: 13, DPAD_CENTER: 23, LEFT: 37, UP: 38, RIGHT: 39, DOWN: 40, BACK: 4, MENU: 82 } as const;

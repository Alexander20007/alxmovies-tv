import { AlxTv, isTV, KEYCODE } from "./tv";

/**
 * Navegação pelo controle remoto da TV (setas + OK) para todo o app.
 *
 * O WebView da Android TV tem uma navegação própria por setas, mas ela falha com cartões (div com onClick), rolagem horizontal
 * das fileiras, janelas (modais) e a barra lateral. Aqui a navegação é feita por geometria: a seta escolhe o elemento clicável mais
 * próximo naquela direção. Nada precisa ser marcado nas telas — botões, links, campos, cartões e qualquer elemento com
 * `cursor: pointer` viram "focáveis" sozinhos.
 *
 *  • Janelas abertas (modais, painéis) prendem o foco dentro delas.
 *  • Ao trocar de tela o foco vai para o botão principal; ao voltar, para onde estava.
 *  • OK num campo de texto abre o teclado da TV.
 *  • Voltar (tecla do controle) é tratado em NativeShell (Capacitor).
 */

type Dir = "up" | "down" | "left" | "right";

// ---------- o que pode receber foco ----------
const NATIVE_ONLY = [
  "a[href]", "button", "input:not([type=\"hidden\"]):not([type=\"file\"])", "select", "textarea", "summary",
  "[role=\"button\"]", "[role=\"tab\"]", "[role=\"link\"]", "[role=\"menuitem\"]", "[role=\"switch\"]", "[role=\"checkbox\"]", "[role=\"radio\"]",
  "[contenteditable=\"true\"]",
].join(",");
const KNOWN_CLICKABLE = [
  ".media-card", ".sala-card", ".profile-item", ".channel-card", ".channel-group-card", ".chat-item", ".soc-row", ".hsp-card",
  ".header-bell-item", ".mini-profile-row", ".account-card-head", ".account-policy-link", ".d2-season-row", ".salas-busca-item",
  ".soc-pick", ".ex-ep", ".ns-item", ".hc-slide", "[tabindex]:not([tabindex=\"-1\"])",
].join(",");
const FOCUSABLE = `${NATIVE_ONLY},${KNOWN_CLICKABLE},[data-tvp]`;

/** Janelas e painéis: quando um deles está na tela, o foco fica preso dentro dele. */
const MODALS = [
  "[data-tv-modal]", "[role=\"dialog\"]", "[aria-modal=\"true\"]",
  ".modal-overlay", ".salas-modal", ".soc-modal", ".d2-modal", ".guest-code-overlay", ".channels-panel-overlay",
  ".ann-overlay", ".dlp-sheet-bg", ".dv-sheet-bg", ".dl-overlay", ".tr-bg", ".upg-bg", ".rm2-set-bg", ".rm2-sheet-bg", ".lr-sheet-bg",
  ".birthday-overlay", ".dg-screen", ".gate-blocked", ".ux", ".upd-full", ".cpx", ".cpl",
  ".ns-sheet.open", ".header-bell-panel.open", ".header-msgs-panel.open", ".tv-sheet.open",
].join(",");

const RAIL = "[data-tv-rail]";
const DIRS: Record<string, Dir> = { ArrowUp: "up", ArrowDown: "down", ArrowLeft: "left", ArrowRight: "right" };
const DIR_CODES: Record<number, Dir> = { [KEYCODE.UP]: "up", [KEYCODE.DOWN]: "down", [KEYCODE.LEFT]: "left", [KEYCODE.RIGHT]: "right" };
/** O que recebe foco primeiro ao abrir uma tela / janela (a primeira correspondência visível). */
const PREFER = "[data-tv-autofocus], .dv-primary, .hc-play, .btn-primary, .soc-btn.primary, .profile-item, .tv-primary";

const dirOf = (e: KeyboardEvent): Dir | null => DIRS[e.key] ?? ((e.key === "Unidentified" || !e.key) ? DIR_CODES[e.keyCode] ?? null : null);
const isEnter = (e: KeyboardEvent) => e.key === "Enter" || e.keyCode === KEYCODE.ENTER || e.keyCode === KEYCODE.DPAD_CENTER;

const TEXT_TYPES = new Set(["text", "search", "email", "password", "number", "tel", "url", ""]);
function isTextInput(el: Element | null): boolean {
  if (!el) return false;
  if (el instanceof HTMLTextAreaElement) return true;
  if (el instanceof HTMLInputElement) return TEXT_TYPES.has(el.type);
  return el instanceof HTMLElement && el.isContentEditable;
}

// ---------- visibilidade ----------
function isShown(el: HTMLElement): boolean {
  if (!el.isConnected) return false;
  const r = el.getBoundingClientRect();
  if (r.width < 2 || r.height < 2) return false;
  const cs = getComputedStyle(el);
  if (cs.visibility === "hidden" || cs.display === "none" || cs.pointerEvents === "none") return false;
  if (parseFloat(cs.opacity) < 0.05) return false;
  if (el.closest("[aria-hidden=\"true\"], [inert], [hidden]")) return false;
  return true;
}

function isDisabled(el: HTMLElement): boolean {
  return (el as HTMLButtonElement).disabled === true || el.getAttribute("aria-disabled") === "true" || !!el.closest("[data-tv-skip]");
}

// ---------- elementos com cursor "mão" que não são botão/link (div com onClick) ----------
const pending = new Set<Element>();
let tagTimer = 0;
function queueTag(n: Node) { if (n.nodeType === 1) pending.add(n as Element); }
function flushTags() {
  tagTimer = 0;
  const cursor = new Map<Element, string>();
  const cur = (el: Element) => { let c = cursor.get(el); if (c === undefined) { c = getComputedStyle(el).cursor; cursor.set(el, c); } return c; };
  const visit = (el: Element) => {
    if (el.hasAttribute("data-tvp") || el.matches(FOCUSABLE) || cur(el) !== "pointer") return;
    const p = el.parentElement;
    if (p && cur(p) === "pointer") return;           // o cursor é herdado: o clicável é o pai
    el.setAttribute("data-tvp", "");
  };
  const roots = Array.from(pending); pending.clear();
  let budget = 6000;
  for (const r of roots) {
    if (!r.isConnected) continue;
    visit(r);
    for (const el of Array.from(r.querySelectorAll("*"))) { if (budget-- <= 0) return; visit(el); }
  }
}

// ---------- janelas abertas ----------
function activeScope(): HTMLElement | null {
  const list = document.querySelectorAll<HTMLElement>(MODALS);
  for (let i = list.length - 1; i >= 0; i--) {
    const el = list[i];
    if (!el.closest(RAIL) && isShown(el) && el.querySelector(FOCUSABLE)) return el;
  }
  return null;
}

function collect(scope: ParentNode): HTMLElement[] {
  const out: HTMLElement[] = [];
  for (const el of Array.from(scope.querySelectorAll<HTMLElement>(FOCUSABLE))) {
    if (isDisabled(el)) continue;
    // um cartão que tem um botão dentro: o foco vai no botão, não no cartão
    if (!el.matches(NATIVE_ONLY) && el.querySelector(NATIVE_ONLY)) continue;
    out.push(el);
  }
  return out;
}

// ---------- foco ----------
let lastContent: HTMLElement | null = null;
const memory = new Map<string, string>();
const routeKey = () => location.pathname + location.search;
const inRail = (el: Element | null) => !!el?.closest(RAIL);

function signature(el: HTMLElement): string {
  const img = el.querySelector("img")?.getAttribute("alt") ?? "";
  const text = (el.getAttribute("aria-label") ?? el.textContent ?? "").replace(/\s+/g, " ").trim().slice(0, 60);
  return `${el.tagName}|${text}|${img}`;
}

function focusEl(el: HTMLElement) {
  if (el.tabIndex < 0 && !el.hasAttribute("tabindex")) el.setAttribute("tabindex", "-1");   // div clicável: precisa disso para aceitar foco
  try { el.focus({ preventScroll: true }); } catch { el.focus(); }
  const horizontal = !!el.closest(".row-track, .hc-track, .tv-hscroll");
  try { el.scrollIntoView({ block: "nearest", inline: horizontal ? "center" : "nearest" }); } catch { /* sem suporte */ }
  if (el.closest(".hc")) window.scrollTo({ top: 0, behavior: "smooth" });   // destaque da Home: mostra ele inteiro
}

/** Ponto de partida de uma tela: o botão principal, ou o item onde a pessoa estava, ou o primeiro de cima à esquerda. */
function focusDefault(scope: HTMLElement | null): boolean {
  const pool = collect(scope ?? document).filter((e) => (scope || !inRail(e)) && isShown(e));
  if (!pool.length) return false;
  let pick: HTMLElement | undefined;
  if (!scope) {
    const sig = memory.get(routeKey());
    if (sig) pick = pool.find((e) => signature(e) === sig);
  }
  pick ??= pool.find((e) => e.matches(PREFER));
  pick ??= pool.find((e) => isTextInput(e) && (e as HTMLInputElement).autofocus);
  pick ??= pool.slice().sort((a, b) => {
    const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
    return (ra.top + ra.left * 0.001) - (rb.top + rb.left * 0.001);
  })[0];
  if (!pick) return false;
  focusEl(pick);
  return true;
}

export function focusRail(): boolean {
  const rail = document.querySelector<HTMLElement>(RAIL);
  if (!rail) return false;
  const target = rail.querySelector<HTMLElement>("[aria-current=\"page\"]") ?? rail.querySelector<HTMLElement>("a,button");
  if (!target) return false;
  target.focus({ preventScroll: true });
  return true;
}
export const isFocusInRail = () => inRail(document.activeElement);

// ---------- escolher o próximo elemento ----------
function score(F: DOMRect, C: DOMRect, dir: Dir): number | null {
  const fcx = F.left + F.width / 2, fcy = F.top + F.height / 2, ccx = C.left + C.width / 2, ccy = C.top + C.height / 2;
  let primary: number, secondary: number, overlap: number;
  switch (dir) {
    case "right": if (ccx <= fcx + 2) return null; primary = Math.max(0, C.left - F.right); secondary = Math.abs(ccy - fcy); overlap = Math.min(F.bottom, C.bottom) - Math.max(F.top, C.top); break;
    case "left": if (ccx >= fcx - 2) return null; primary = Math.max(0, F.left - C.right); secondary = Math.abs(ccy - fcy); overlap = Math.min(F.bottom, C.bottom) - Math.max(F.top, C.top); break;
    case "down": if (ccy <= fcy + 2) return null; primary = Math.max(0, C.top - F.bottom); secondary = Math.abs(ccx - fcx); overlap = Math.min(F.right, C.right) - Math.max(F.left, C.left); break;
    default: if (ccy >= fcy - 2) return null; primary = Math.max(0, F.top - C.bottom); secondary = Math.abs(ccx - fcx); overlap = Math.min(F.right, C.right) - Math.max(F.left, C.left); break;
  }
  return primary + secondary * 2 + (overlap > 0 ? 0 : 600) + (ccx === fcx && ccy === fcy ? 5000 : 0);
}

function currentFocusable(): HTMLElement | null {
  const a = document.activeElement as HTMLElement | null;
  if (!a || a === document.body || a === document.documentElement) return null;
  return a.matches(FOCUSABLE) ? a : (a.closest(FOCUSABLE) as HTMLElement | null) ?? a;
}

function navigate(dir: Dir) {
  const scope = activeScope();
  const cur = currentFocusable();
  if (!cur || !cur.isConnected || (scope && !scope.contains(cur)) || !isShown(cur)) { focusDefault(scope); return; }

  const curInRail = inRail(cur);
  const F = cur.getBoundingClientRect();
  const scored: [number, HTMLElement][] = [];
  for (const el of collect(scope ?? document)) {
    if (el === cur || cur.contains(el) || el.contains(cur)) continue;
    const elInRail = inRail(el);
    if (curInRail && (dir === "up" || dir === "down") && !elInRail) continue;      // na barra lateral, cima/baixo ficam na barra
    if (!curInRail && elInRail && (dir === "up" || dir === "down")) continue;      // no conteúdo, cima/baixo não pulam para a barra
    if (curInRail && dir === "right" && elInRail) continue;
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) continue;
    const s = score(F, r, dir);
    if (s !== null) scored.push([s, el]);
  }
  scored.sort((a, b) => a[0] - b[0]);
  // primeiro item da fileira + seta para a esquerda = barra lateral (e não um botão de outra fileira)
  if (dir === "left" && !curInRail && !scope && !(scored[0] && scored[0][0] < 600)) {
    const active = document.querySelector<HTMLElement>(`${RAIL} [aria-current="page"]`) ?? document.querySelector<HTMLElement>(`${RAIL} a, ${RAIL} button`);
    if (active && isShown(active)) { focusEl(active); return; }
  }

  for (const [, el] of scored) {
    if (!isShown(el)) continue;
    let target = el;
    if (!curInRail && inRail(el)) target = document.querySelector<HTMLElement>(`${RAIL} [aria-current="page"]`) ?? el;       // esquerda → item atual da barra
    else if (curInRail && !inRail(el) && lastContent && lastContent.isConnected && isShown(lastContent) && (!scope || scope.contains(lastContent))) target = lastContent; // direita → onde estava
    focusEl(target);
    return;
  }
  // sem alvo: textos longos e listas sem botões rolam com cima/baixo
  if (dir === "up" || dir === "down") scrollFrom(cur, dir === "down" ? 1 : -1);
}

function scrollFrom(el: HTMLElement, sign: 1 | -1) {
  let p: HTMLElement | null = el.parentElement;
  while (p && p !== document.body) {
    const oy = getComputedStyle(p).overflowY;
    if ((oy === "auto" || oy === "scroll") && p.scrollHeight > p.clientHeight + 4) { p.scrollBy({ top: sign * p.clientHeight * 0.6, behavior: "smooth" }); return; }
    p = p.parentElement;
  }
  window.scrollBy({ top: sign * window.innerHeight * 0.6, behavior: "smooth" });
}

// ---------- campos de texto ----------
function leavesField(el: HTMLElement, dir: Dir): boolean {
  if (dir === "up" || dir === "down") return !(el instanceof HTMLTextAreaElement);
  try {
    const i = el as HTMLInputElement;
    const s = i.selectionStart, e = i.selectionEnd;
    if (s == null || e == null) return true;
    if (dir === "left") return s === 0 && e === 0;
    return s === i.value.length && e === i.value.length;
  } catch { return true; }
}

let imeOpen = false, imeTimer = 0;
const pollIme = () => { void AlxTv.isKeyboardOpen().then((r) => { imeOpen = !!r.open; }).catch(() => {}); };
function watchIme(on: boolean) {
  window.clearInterval(imeTimer);
  if (on) { pollIme(); imeTimer = window.setInterval(pollIme, 400); } else imeOpen = false;
}
export function openKeyboard() {
  imeOpen = true; watchIme(true);
  void AlxTv.showKeyboard().catch(() => {});
}

// ---------- teclas ----------
let lastNav = 0;
function onKeyDown(e: KeyboardEvent) {
  if (e.defaultPrevented || e.ctrlKey || e.altKey || e.metaKey) return;
  const a = document.activeElement as HTMLElement | null;
  const dir = dirOf(e);
  if (dir) {
    if (a) {
      if (isTextInput(a) && !leavesField(a, dir)) return;                                 // setas movem o cursor do texto
      if (a instanceof HTMLInputElement && a.type === "range" && (dir === "left" || dir === "right")) return;
      if (a instanceof HTMLSelectElement) return;
    }
    e.preventDefault();
    const now = performance.now();
    if (now - lastNav < 40) return;                                                         // segurar a seta não atropela a tela
    lastNav = now;
    navigate(dir);
    return;
  }
  if (isEnter(e) && a && a !== document.body) {
    if (isTextInput(a) || a instanceof HTMLSelectElement) return;                         // o campo trata (teclado / enviar)
    if (a instanceof HTMLInputElement && a.type === "range") return;
    e.preventDefault();
    if (!e.repeat) a.click();
  }
}

/** Fase de captura: o primeiro OK num campo de texto abre o teclado em vez de "enviar" o formulário. */
function onKeyCapture(e: KeyboardEvent) {
  if (!isEnter(e) || !e.isTrusted) return;
  const a = document.activeElement;
  if (a && isTextInput(a) && !imeOpen) {
    e.preventDefault(); e.stopImmediatePropagation();
    if (!e.repeat) openKeyboard();
  }
}

// ---------- acompanhar telas e janelas ----------
let reconTimer = 0;
let beforeModal: HTMLElement | null = null;
function reconcile() {
  reconTimer = 0;
  const scope = activeScope();
  const a = document.activeElement as HTMLElement | null;
  const lost = !a || a === document.body || a === document.documentElement || !a.isConnected || (!isShown(a) && !isTextInput(a));
  if (scope) {
    if (!a || !scope.contains(a)) {
      if (!lost && a && !inRail(a)) beforeModal = a;
      focusDefault(scope);
    }
    return;
  }
  if (!lost) return;
  if (beforeModal && beforeModal.isConnected && isShown(beforeModal)) { const b = beforeModal; beforeModal = null; focusEl(b); return; }
  beforeModal = null;
  focusDefault(null);
}
const schedule = () => { if (!reconTimer) reconTimer = window.setTimeout(reconcile, 110); };

let started = false;
export function startTvNav() {
  if (!isTV || started) return;
  started = true;

  document.addEventListener("keydown", onKeyCapture, true);
  document.addEventListener("keydown", onKeyDown, false);

  document.addEventListener("focusin", (e) => {
    const el = e.target as HTMLElement;
    if (isTextInput(el)) watchIme(true);
    if (!(el instanceof HTMLElement) || inRail(el)) return;
    if (!el.closest(MODALS)) { lastContent = el; memory.set(routeKey(), signature(el)); }
  });
  document.addEventListener("focusout", (e) => { if (isTextInput(e.target as Element)) watchIme(false); });

  const obs = new MutationObserver((muts) => {
    for (const m of muts) m.addedNodes.forEach(queueTag);
    if (!tagTimer) tagTimer = window.setTimeout(flushTags, 70);
    schedule();
  });
  obs.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ["class", "aria-hidden"] });
  window.addEventListener("popstate", schedule);
  document.addEventListener("visibilitychange", () => { if (document.visibilityState === "visible") schedule(); });
  queueTag(document.body); flushTags(); schedule();
}

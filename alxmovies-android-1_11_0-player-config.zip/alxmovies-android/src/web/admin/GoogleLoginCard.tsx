import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { adminGoogleLogin, adminSetGoogleLogin } from "@/services/admin";
import { Note, Section } from "./ui";

/** Login com Google no app Android: liga/desliga e guarda o ID do cliente Web do Google Cloud. Só o dono mexe. */
export function GoogleLoginCard() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["admin-google-login"], queryFn: adminGoogleLogin, retry: false });
  const [enabled, setEnabled] = useState(false);
  const [id, setId] = useState("");
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState<{ ok: boolean; text: string } | null>(null);
  useEffect(() => { if (q.data) { setEnabled(q.data.enabled); setId(q.data.web_client_id); } }, [q.data]);

  if (q.isLoading) return null;
  if (q.isError) return <Section title="Login com Google"><p className="wb-dim">{(q.error as Error).message}</p></Section>;

  async function save() {
    setBusy(true); setNote(null);
    try {
      await adminSetGoogleLogin(enabled, id);
      await qc.invalidateQueries({ queryKey: ["admin-google-login"] });
      setNote({ ok: true, text: enabled ? "Salvo. O botão “Continuar com Google” aparece na tela de login do app." : "Salvo. O botão do Google está escondido." });
    } catch (e) { setNote({ ok: false, text: e instanceof Error ? e.message : "Não foi possível salvar." }); }
    setBusy(false);
  }

  return (
    <Section title="Login com Google (app Android)">
      <p className="wb-dim ao-foot">
        Mostra o botão <b>Continuar com Google</b> na tela de entrada do app. Cole aqui o <b>ID do cliente do tipo “Aplicativo da Web”</b> do Google Cloud (o mesmo que você colocou no Supabase,
        em Authentication → Providers → Google). Além dele, o Google Cloud precisa de um cliente do tipo <b>Android</b> com o pacote <b>com.alxmovies.app</b> e o SHA-1 da chave de assinatura, que o GitHub mostra no resumo de cada build.
      </p>
      <label className="ao-tog">
        <span><b>{enabled ? "Ligado" : "Desligado"}</b><small>Mostrar o botão “Continuar com Google” no app.</small></span>
        <input type="checkbox" role="switch" checked={enabled} onChange={(e) => setEnabled(e.target.checked)} />
        <i />
      </label>
      <label className="ao-field">ID do cliente Web
        <input value={id} spellCheck={false} autoCapitalize="off" autoCorrect="off" placeholder="123456789012-abc….apps.googleusercontent.com" onChange={(e) => setId(e.target.value.trim())} />
      </label>
      <Note note={note} />
      <button type="button" className="wb-btn primary" disabled={busy} onClick={() => void save()}>{busy ? "Salvando…" : "Salvar"}</button>
    </Section>
  );
}

import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { adminSetTvApp, adminTvApp } from "@/services/admin";
import { Note, Section, useMyPerms } from "./ui";

/** Link de download do app da Smart TV (GitHub). Aparece no site para todos. Só o dono mexe. */
export function TvAppCard() {
  const me = useMyPerms();
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["admin-tv-app"], queryFn: adminTvApp, retry: false, enabled: me.owner });
  const [url, setUrl] = useState("");
  const [version, setVersion] = useState("");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  useEffect(() => { if (q.data) { setUrl(q.data.url); setVersion(q.data.version); setNote(q.data.note); } }, [q.data]);
  if (!me.owner) return null;
  if (q.isError) return <Section title="App da Smart TV"><p className="wb-dim">{(q.error as Error).message}</p></Section>;

  async function save() {
    setBusy(true); setMsg(null);
    try {
      await adminSetTvApp(url, version, note);
      await qc.invalidateQueries({ queryKey: ["admin-tv-app"] });
      await qc.invalidateQueries({ queryKey: ["tv-app"] });
      setMsg({ ok: true, text: url ? "Salvo. O botão “Baixar para Smart TV” já aparece no site." : "Salvo. O site mostra “em breve” para a Smart TV." });
    } catch (e) { setMsg({ ok: false, text: e instanceof Error ? e.message : "Não foi possível salvar." }); }
    setBusy(false);
  }

  return (
    <Section title="App da Smart TV">
      <p className="wb-dim ao-foot">
        Cole o link de download do app da TV (por exemplo, o do arquivo APK na página de Releases do GitHub). Ele aparece na seção <b>Smart TV</b> do site, com botão de baixar e de copiar o link.
        Deixe vazio para mostrar “em breve”.
      </p>
      <label className="ao-field">Link de download (https://…)
        <input value={url} inputMode="url" spellCheck={false} autoCapitalize="off" autoCorrect="off" placeholder="https://github.com/usuario/repositorio/releases/latest/download/ALXmovies-TV.apk" onChange={(e) => setUrl(e.target.value.trim())} />
      </label>
      <label className="ao-field">Versão (opcional)
        <input value={version} maxLength={30} placeholder="Ex.: 1.0" onChange={(e) => setVersion(e.target.value)} />
      </label>
      <label className="ao-field">Aviso para quem baixar (opcional)
        <input value={note} maxLength={200} placeholder="Ex.: Para TVs com Android TV ou Google TV." onChange={(e) => setNote(e.target.value)} />
      </label>
      <Note note={msg} />
      <button type="button" className="wb-btn primary" disabled={busy} onClick={() => void save()}>{busy ? "Salvando…" : "Salvar"}</button>
    </Section>
  );
}

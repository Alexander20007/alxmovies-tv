import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { adminDnsGuard, adminSetDnsGuard } from "@/services/admin";
import { DNS_GUARD_DEFAULT, existsPublicly } from "@/lib/dnsGuard";
import { Note, Section } from "./ui";

interface Form {
  enabled: boolean; mode: "warn" | "block";
  check_private_dns: boolean; check_ips: boolean; check_probe: boolean;
  probe_min: string; providers: string; ips: string; test_hosts: string; message: string;
}

const toLines = (v: unknown) => (Array.isArray(v) ? v.filter((x): x is string => typeof x === "string").join("\n") : "");
const fromLines = (s: string) => s.split(/[\n,;]+/).map((x) => x.trim()).filter(Boolean);

function toForm(c: Record<string, unknown>): Form {
  return {
    enabled: c.enabled === true, mode: c.mode === "block" ? "block" : "warn",
    check_private_dns: c.check_private_dns !== false, check_ips: c.check_ips !== false, check_probe: c.check_probe !== false,
    probe_min: String(typeof c.probe_min === "number" ? c.probe_min : 2),
    providers: toLines(c.providers), ips: toLines(c.ips), test_hosts: toLines(c.test_hosts), message: typeof c.message === "string" ? c.message : "",
  };
}

function Toggle({ on, label, hint, onChange }: { on: boolean; label: string; hint?: string; onChange: (v: boolean) => void }) {
  return (
    <label className="ao-tog">
      <span><b>{label}</b>{hint && <small>{hint}</small>}</span>
      <input type="checkbox" role="switch" checked={on} onChange={(e) => onChange(e.target.checked)} />
      <i />
    </label>
  );
}

/** Anti-AdBlock: detecta DNS e aplicativos que bloqueiam anúncios (AdGuard, NextDNS…) e avisa ou bloqueia. Só o dono mexe. */
export function AntiAdTab() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["admin-dnsguard"], queryFn: adminDnsGuard, retry: false });
  const [f, setF] = useState<Form | null>(null);
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState<{ ok: boolean; text: string } | null>(null);
  const [check, setCheck] = useState<{ host: string; ok: boolean }[] | null>(null);
  const [checking, setChecking] = useState(false);
  useEffect(() => { if (q.data) setF(toForm(q.data)); }, [q.data]);

  if (q.isLoading) return <p className="wb-dim">Carregando…</p>;
  if (q.isError || !f) return <p className="wb-dim">{q.error ? (q.error as Error).message : "Não foi possível carregar."}</p>;
  const set = (p: Partial<Form>) => setF({ ...f, ...p });

  /** Confere num DNS público se cada domínio de teste existe. Domínio que não existe NUNCA prova bloqueador (e é ignorado pelo app). */
  async function verify() {
    if (!f) return;
    setChecking(true); setCheck(null);
    const hosts = fromLines(f.test_hosts);
    const res = await Promise.all(hosts.map(async (host) => ({ host, ok: await existsPublicly(host) })));
    setCheck(res); setChecking(false);
  }

  async function save() {
    if (!f) return;
    setBusy(true); setNote(null);
    try {
      await adminSetDnsGuard({
        enabled: f.enabled, mode: f.mode, check_private_dns: f.check_private_dns, check_ips: f.check_ips, check_probe: f.check_probe,
        probe_min: Number(f.probe_min) || 2, providers: fromLines(f.providers), ips: fromLines(f.ips), test_hosts: fromLines(f.test_hosts), message: f.message,
      });
      await qc.invalidateQueries({ queryKey: ["admin-dnsguard"] });
      setNote({ ok: true, text: "Salvo. Os aparelhos usam a configuração nova quando abrem o app ou voltam do segundo plano." });
    } catch (e) { setNote({ ok: false, text: e instanceof Error ? e.message : "Não foi possível salvar." }); }
    setBusy(false);
  }

  return (
    <>
      <Section title="Anti-AdBlock">
        <p className="wb-dim ao-foot">
          O app olha o DNS do aparelho e, se achar um bloqueador de anúncios (AdGuard, NextDNS, Pi-hole, apps de VPN com bloqueio…), <b>avisa</b> ou <b>bloqueia</b> o uso até a pessoa desativar.
          Só funciona no app Android. <b>Você (dono) nunca é afetado</b>, então para testar use outra conta ou aparelho. Antes de ligar em modo “Bloquear”, teste em modo “Avisar”.
        </p>
        <Toggle on={f.enabled} label={f.enabled ? "Ligado" : "Desligado"} hint="Liga ou desliga a verificação para todos os usuários." onChange={(v) => set({ enabled: v })} />
        <div className="ao-seg">
          <button type="button" className={f.mode === "warn" ? "on" : ""} onClick={() => set({ mode: "warn" })}>⚠️ Avisar</button>
          <button type="button" className={f.mode === "block" ? "on" : ""} onClick={() => set({ mode: "block" })}>⛔ Bloquear</button>
        </div>
        <p className="wb-dim ao-foot">{f.mode === "warn" ? "Avisar: aparece uma tela explicando, e a pessoa pode tocar em “Continuar mesmo assim”." : "Bloquear: o app não abre enquanto o bloqueador estiver ativo. Só passa depois de desativá-lo."}</p>
      </Section>

      <Section title="O que verificar">
        <Toggle on={f.check_private_dns} label="DNS privado do Android" hint="Compara o servidor de DNS privado (Configurações → DNS privado) com a lista de provedores abaixo." onChange={(v) => set({ check_private_dns: v })} />
        <Toggle on={f.check_ips} label="Servidores de DNS da rede" hint="Compara os endereços IP dos DNS em uso com a lista de IPs abaixo." onChange={(v) => set({ check_ips: v })} />
        <Toggle on={f.check_probe} label="Teste de anúncios" hint="Tenta abrir domínios de anúncios. Se a rede recusar vários deles, é um bloqueador. Pega também apps de VPN/DNS que não aparecem nas listas." onChange={(v) => set({ check_probe: v })} />
        {f.check_probe && (
          <label className="ao-field">Domínios de teste recusados para considerar bloqueado (1 a 10)
            <input value={f.probe_min} inputMode="numeric" maxLength={2} onChange={(e) => set({ probe_min: e.target.value.replace(/\D/g, "") })} />
          </label>
        )}
      </Section>

      <Section title="Listas">
        <label className="ao-field">Provedores de DNS que bloqueiam anúncios (um por linha)
          <textarea rows={6} value={f.providers} spellCheck={false} autoCapitalize="off" onChange={(e) => set({ providers: e.target.value })} />
        </label>
        <p className="wb-dim ao-foot">Vale o domínio e todos os subdomínios: <b>nextdns.io</b> pega também <b>abc123.dns.nextdns.io</b>. Pode colar um link inteiro.</p>
        <label className="ao-field">IPs de DNS que bloqueiam anúncios (um por linha, aceita intervalo como 94.140.14.0/24)
          <textarea rows={5} value={f.ips} spellCheck={false} autoCapitalize="off" onChange={(e) => set({ ips: e.target.value })} />
        </label>
        <label className="ao-field">Domínios de anúncios para o teste (um por linha)
          <textarea rows={5} value={f.test_hosts} spellCheck={false} autoCapitalize="off" onChange={(e) => { set({ test_hosts: e.target.value }); setCheck(null); }} />
        </label>
        <p className="wb-dim ao-foot">Use domínios que <b>existem de verdade</b> e que todo bloqueador de anúncios barra (o padrão usa os do Google). O app só considera um domínio “bloqueado” depois de confirmar num DNS público que ele existe, então um domínio errado é ignorado e não acusa ninguém. Use pelo menos 3 domínios e um mínimo de 2 ou 3.</p>
        <button type="button" className="wb-btn" disabled={checking} onClick={() => void verify()}>{checking ? "Verificando…" : "Verificar se os domínios existem"}</button>
        {check && (
          <ul className="ao-donut" style={{ listStyle: "none", padding: 0, margin: 0, display: "grid", gap: 6 }}>
            {check.map((c) => <li key={c.host} style={{ display: "flex", gap: 8, fontSize: "0.88rem", color: c.ok ? "#9bf2bd" : "#ff9aa2" }}><b>{c.ok ? "✓" : "✗"}</b><span>{c.host}{c.ok ? " — existe" : " — não existe (ou não respondeu): troque ou remova"}</span></li>)}
          </ul>
        )}
      </Section>

      <Section title="Mensagem">
        <label className="ao-field">Texto mostrado à pessoa
          <textarea rows={4} maxLength={400} value={f.message} onChange={(e) => set({ message: e.target.value })} />
        </label>
        <Note note={note} />
        <div className="wb-row">
          <button type="button" className="wb-btn primary" disabled={busy} onClick={() => void save()}>{busy ? "Salvando…" : "Salvar"}</button>
          <button type="button" className="wb-btn" disabled={busy} onClick={() => setF({ ...toForm(DNS_GUARD_DEFAULT as unknown as Record<string, unknown>), enabled: f.enabled, mode: f.mode })}>Restaurar listas padrão</button>
        </div>
      </Section>
    </>
  );
}

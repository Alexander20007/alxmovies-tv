import { useEffect, useState, type ReactNode } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { adminApiEndpoints, adminPlayerConfig, adminSetPlayerConfig } from "@/services/admin";
import { DEFAULT_PLAYER_CONFIG, planForServer, sanitizePlayerConfig, type PlayerConfig, type PlayerRule, type ProxyMode } from "@/lib/playerConfig";
import { Note, Section, fmtDateTime } from "./ui";

const MODES: { id: ProxyMode; label: string }[] = [
  { id: "default", label: "Proxy padrão" },
  { id: "vip", label: "Proxy VIP" },
  { id: "none", label: "Sem proxy (ExoPlayer direto)" },
];

type Draft = PlayerConfig;
const clone = <T,>(x: T): T => JSON.parse(JSON.stringify(x));

function Field({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return <label className="ao-field">{label}{children}{hint && <small className="wb-dim">{hint}</small>}</label>;
}
function Txt({ v, on, ph }: { v: string; on: (s: string) => void; ph?: string }) {
  return <input value={v} placeholder={ph} autoCapitalize="off" spellCheck={false} onChange={(e) => on(e.target.value)} />;
}
function Num({ v, on }: { v: number; on: (n: number) => void }) {
  return <input type="number" inputMode="numeric" value={v} onChange={(e) => on(Number(e.target.value))} />;
}
function Check({ v, on, children }: { v: boolean; on: (b: boolean) => void; children: ReactNode }) {
  return <label className="ao-check"><input type="checkbox" checked={v} onChange={(e) => on(e.target.checked)} />{children}</label>;
}

const hdrToText = (h: Record<string, string>) => Object.entries(h).map(([k, v]) => `${k}: ${v}`).join("\n");
const textToHdr = (t: string) => {
  const o: Record<string, string> = {};
  for (const line of t.split("\n")) { const i = line.indexOf(":"); if (i > 0) o[line.slice(0, i).trim()] = line.slice(i + 1).trim(); }
  return o;
};

/** Testa o fluxo com o rascunho (sem salvar): lista os servidores, pede o link e mostra o link final (proxy + Referer). */
function TestBox({ cfg, base }: { cfg: Draft; base: string }) {
  const [type, setType] = useState<"movie" | "tv">("movie");
  const [id, setId] = useState("603");
  const [se, setSe] = useState("1");
  const [ep, setEp] = useState("1");
  const [servers, setServers] = useState<{ label: string; budget: string }[]>([]);
  const [server, setServer] = useState("");
  const [log, setLog] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const path = type === "tv" ? `tv/${id}/${se}/${ep}` : `movie/${id}`;
  const add = (l: string) => setLog((x) => [...x, l]);

  async function list() {
    setBusy(true); setLog([]); setServers([]);
    try {
      const url = `${base}${cfg.flow.serversPath}/${path}`;
      add(`GET ${url}`);
      const d = await (await fetch(url)).json();
      if (d.erro) throw new Error(d.erro);
      setServers(d.servidores ?? []); setServer(d.servidores?.[0]?.label ?? "");
      add(`✅ ${d.servidores?.length ?? 0} servidor(es).`);
    } catch (e) { add(`❌ ${e instanceof Error ? e.message : "Falhou."}`); }
    setBusy(false);
  }
  async function extract() {
    setBusy(true);
    try {
      const url = `${base}${cfg.flow.streamPath}/${path}?${cfg.flow.serverParam}=${encodeURIComponent(server)}`;
      add(`\nGET ${url}`);
      const d = await (await fetch(url)).json();
      if (d.erro || !d.m3u8) throw new Error(d.erro || d.ultimo_erro || "Sem link.");
      const plan = planForServer(cfg, server, d.m3u8, d.embed, base);
      add(`✅ Link extraído${d.cache ? " (cache)" : ""}.`);
      add(`Proxy usado: ${plan.mode} · Referer: ${plan.referer}`);
      add(`Link final: ${plan.url}`);
      try {
        const r = await fetch(plan.url);
        const t = await r.text();
        add(r.ok && t.trim().startsWith("#EXTM3U") ? "✅ A playlist abriu (#EXTM3U)." : `⚠️ Resposta ${r.status}: ${t.slice(0, 120)}`);
      } catch { add("ℹ️ O navegador não conseguiu abrir a playlist (CORS). No app, o ExoPlayer não tem esse limite."); }
    } catch (e) { add(`❌ ${e instanceof Error ? e.message : "Falhou."}`); }
    setBusy(false);
  }

  return (
    <div className="ao-prov">
      <div className="ao-prov-head"><div><b>Testar com este rascunho</b><small>Não salva nada. Usa o endereço da API principal (aba APIs).</small></div></div>
      <Field label="Tipo"><select value={type} onChange={(e) => setType(e.target.value as "movie" | "tv")}><option value="movie">Filme</option><option value="tv">Série</option></select></Field>
      <Field label="ID (TMDB)"><input type="number" value={id} onChange={(e) => setId(e.target.value)} /></Field>
      {type === "tv" && <><Field label="Temporada"><input type="number" value={se} onChange={(e) => setSe(e.target.value)} /></Field><Field label="Episódio"><input type="number" value={ep} onChange={(e) => setEp(e.target.value)} /></Field></>}
      <button type="button" className="wb-btn" disabled={busy || !base || !id} onClick={() => void list()}>1. Buscar servidores</button>
      {servers.length > 0 && (
        <>
          <Field label="Servidor"><select value={server} onChange={(e) => setServer(e.target.value)}>{servers.map((s) => <option key={s.label} value={s.label}>{s.label} ({s.budget})</option>)}</select></Field>
          <button type="button" className="wb-btn primary" disabled={busy} onClick={() => void extract()}>2. Extrair e montar o link</button>
        </>
      )}
      {log.length > 0 && <pre className="ao-foot" style={{ whiteSpace: "pre-wrap", wordBreak: "break-all", fontSize: 12 }}>{log.join("\n")}</pre>}
    </div>
  );
}

/** Configuração remota do player (tabela player_config). Só o dono mexe. */
export function PlayerTab() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["admin-player"], queryFn: adminPlayerConfig, retry: false });
  const apis = useQuery({ queryKey: ["admin-apis"], queryFn: adminApiEndpoints, retry: false });
  const [d, setD] = useState<Draft>(() => clone(DEFAULT_PLAYER_CONFIG));
  const [json, setJson] = useState("");
  const [advanced, setAdvanced] = useState(false);
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState<{ ok: boolean; text: string } | null>(null);

  useEffect(() => {
    if (q.data) { const c = sanitizePlayerConfig(q.data.config); setD(c); setJson(JSON.stringify(c, null, 2)); }
  }, [q.data]);

  if (q.isLoading) return <p className="wb-dim">Carregando…</p>;
  if (q.isError) return <p className="wb-dim">{(q.error as Error).message.includes("não foi instalado") ? "Rode o sql/player-config.sql no Supabase para ativar esta aba." : (q.error as Error).message}</p>;

  const set = (fn: (x: Draft) => void) => { const n = clone(d); fn(n); setD(n); setJson(JSON.stringify(n, null, 2)); setNote(null); };
  const streamBase = (apis.data ?? []).find((r) => r.key === "STREAM")?.url ?? "";
  const setRule = (i: number, patch: Partial<PlayerRule>) => set((x) => { x.proxy.rules[i] = { ...x.proxy.rules[i], ...patch }; });

  function fromJson(t: string) {
    setJson(t);
    try { setD(sanitizePlayerConfig(JSON.parse(t))); setNote(null); } catch { setNote({ ok: false, text: "JSON inválido." }); }
  }
  async function save() {
    setBusy(true); setNote(null);
    try {
      await adminSetPlayerConfig(d);
      setNote({ ok: true, text: "Salvo. Os aparelhos pegam a nova configuração ao abrir o app e a cada ~5 min enquanto assistem — sem atualizar o app." });
      await qc.invalidateQueries({ queryKey: ["admin-player"] });
    } catch (e) { setNote({ ok: false, text: e instanceof Error ? e.message : "Não foi possível salvar." }); }
    setBusy(false);
  }

  return (
    <>
      <Section title="Player — configuração remota" right={q.data ? <small className="wb-dim">versão {q.data.version} · {fmtDateTime(q.data.updated_at)}</small> : undefined}>
        <p className="wb-dim ao-foot">Vale para o player, as salas e os downloads. Valores inválidos são ignorados pelo app (ele usa o padrão), mas um proxy ou Referer errado faz os vídeos pararem: use o teste abaixo antes de salvar.</p>
      </Section>

      <Section title="Fluxo dos servidores">
        <div className="ao-provs">
          <div className="ao-prov">
            <Field label="Rota da lista de servidores" hint="GET {API}{rota}/movie/{id} · /tv/{id}/{temp}/{ep}"><Txt v={d.flow.serversPath} on={(v) => set((x) => { x.flow.serversPath = v; })} /></Field>
            <Field label="Rota do link do vídeo" hint="GET {API}{rota}/movie/{id}?servidor=…"><Txt v={d.flow.streamPath} on={(v) => set((x) => { x.flow.streamPath = v; })} /></Field>
            <Field label="Nome do parâmetro do servidor"><Txt v={d.flow.serverParam} on={(v) => set((x) => { x.flow.serverParam = v; })} /></Field>
            <Check v={d.flow.listServers} on={(v) => set((x) => { x.flow.listServers = v; })}>Consultar a lista de servidores na rota acima</Check>
            <Check v={d.flow.budgetMode === "success"} on={(v) => set((x) => { x.flow.budgetMode = v ? "success" : "all"; })}>Só liberar servidores com status “success” (desligado = todos, como no teste)</Check>
          </div>
          <div className="ao-prov">
            <Field label="Servidor prioritário no Automático" hint="Vazio = a API escolhe. Se falhar, tenta os próximos da lista."><Txt v={d.flow.priorityServer} on={(v) => set((x) => { x.flow.priorityServer = v; })} ph="ex.: VIP Player" /></Field>
            <Field label="Quantos servidores tentar se falhar (0–8)"><Num v={d.flow.autoTryMax} on={(v) => set((x) => { x.flow.autoTryMax = v; })} /></Field>
            <Field label="Avisar “demorando” após (ms)"><Num v={d.flow.slowAfterMs} on={(v) => set((x) => { x.flow.slowAfterMs = v; })} /></Field>
            <Field label="Desistir após (ms)"><Num v={d.flow.giveUpMs} on={(v) => set((x) => { x.flow.giveUpMs = v; })} /></Field>
          </div>
          <div className="ao-prov">
            <Check v={d.fallback.enabled} on={(v) => set((x) => { x.fallback.enabled = v; })}>API reserva ligada</Check>
            <Field label="Reserva começa a carregar após (ms)"><Num v={d.fallback.afterMs} on={(v) => set((x) => { x.fallback.afterMs = v; })} /></Field>
            <Field label="Reserva desiste após (ms)"><Num v={d.fallback.giveUpMs} on={(v) => set((x) => { x.fallback.giveUpMs = v; })} /></Field>
          </div>
        </div>
      </Section>

      <Section title="Proxies e Referer">
        <div className="ao-provs">
          <div className="ao-prov">
            <Field label="Rota do proxy padrão"><Txt v={d.proxy.paths.default} on={(v) => set((x) => { x.proxy.paths.default = v; })} /></Field>
            <Field label="Rota do proxy VIP"><Txt v={d.proxy.paths.vip} on={(v) => set((x) => { x.proxy.paths.vip = v; })} /></Field>
            <Field label="Parâmetro do link"><Txt v={d.proxy.urlParam} on={(v) => set((x) => { x.proxy.urlParam = v; })} /></Field>
            <Field label="Parâmetro do Referer"><Txt v={d.proxy.refererParam} on={(v) => set((x) => { x.proxy.refererParam = v; })} /></Field>
            <Field label="Referer padrão"><Txt v={d.proxy.defaultReferer} on={(v) => set((x) => { x.proxy.defaultReferer = v; })} /></Field>
            <Check v={d.proxy.useEmbedReferer} on={(v) => set((x) => { x.proxy.useEmbedReferer = v; })}>Usar o “embed” que a API devolve como Referer (se vier)</Check>
            <Field label="Proxy dos servidores sem regra">
              <select value={d.proxy.defaultMode} onChange={(e) => set((x) => { x.proxy.defaultMode = e.target.value as ProxyMode; })}>{MODES.map((m) => <option key={m.id} value={m.id}>{m.label}</option>)}</select>
            </Field>
          </div>
          {d.proxy.rules.map((r, i) => (
            <div className="ao-prov" key={i}>
              <div className="ao-prov-head"><div><b>Regra {i + 1}</b><small>Vale para servidores cujo nome contém o texto abaixo.</small></div></div>
              <Field label="Nome contém"><Txt v={r.match} on={(v) => setRule(i, { match: v.toLowerCase() })} ph="ex.: vip" /></Field>
              <Field label="Usar">
                <select value={r.proxy} onChange={(e) => setRule(i, { proxy: e.target.value as ProxyMode })}>{MODES.map((m) => <option key={m.id} value={m.id}>{m.label}</option>)}</select>
              </Field>
              <Field label="Referer próprio (opcional)"><Txt v={r.referer ?? ""} on={(v) => setRule(i, { referer: v })} ph="https://…" /></Field>
              <Field label="Headers extras (um por linha, Nome: valor)"><textarea rows={3} spellCheck={false} value={hdrToText(r.headers ?? {})} onChange={(e) => setRule(i, { headers: textToHdr(e.target.value) })} /></Field>
              <button type="button" className="wb-btn" onClick={() => set((x) => { x.proxy.rules.splice(i, 1); })}>Remover regra</button>
            </div>
          ))}
          <button type="button" className="wb-btn" disabled={d.proxy.rules.length >= 20} onClick={() => set((x) => { x.proxy.rules.push({ match: "", proxy: "default" }); })}>+ Adicionar regra</button>
        </div>
      </Section>

      <Section title="Salas (sincronia e anfitrião)">
        <div className="ao-provs">
          <div className="ao-prov">
            <Field label="Servidor principal das salas" hint="Nome exato, como aparece em “Buscar servidores” no teste. Vazio = Automático. Se falhar, tenta os outros."><Txt v={d.rooms.mainServer} on={(v) => set((x) => { x.rooms.mainServer = v; })} ph="ex.: VIP Player" /></Field>
            <Field label="Sinal do anfitrião a cada (ms)" hint="Posição e “estou aqui” enviados para quem assiste."><Num v={d.rooms.heartbeatMs} on={(v) => set((x) => { x.rooms.heartbeatMs = v; })} /></Field>
            <Check v={d.rooms.pingWhenPaused} on={(v) => set((x) => { x.rooms.pingWhenPaused = v; })}>Anfitrião pausado/carregando também manda sinal (evita o falso “anfitrião reconectando”)</Check>
            <Field label="Mostrar “Aguardando o anfitrião” só após ausente por (ms)" hint="Conta só se ele saiu da sala E parou de mandar sinal."><Num v={d.rooms.hostGraceMs} on={(v) => set((x) => { x.rooms.hostGraceMs = v; })} /></Field>
            <Field label="Próximo da fila assume a sala após ausente por (ms)"><Num v={d.rooms.claimHostAfterMs} on={(v) => set((x) => { x.rooms.claimHostAfterMs = v; })} /></Field>
          </div>
          <div className="ao-prov">
            <Field label="Corrigir o tempo só se estiver fora por mais de (s)"><Num v={d.rooms.driftToleranceSec} on={(v) => set((x) => { x.rooms.driftToleranceSec = v; })} /></Field>
            <Field label="Avisar “Ajustando sincronia” acima de (s)"><Num v={d.rooms.driftNoticeSec} on={(v) => set((x) => { x.rooms.driftNoticeSec = v; })} /></Field>
            <Check v={d.rooms.tryOtherServers} on={(v) => set((x) => { x.rooms.tryOtherServers = v; })}>Se o vídeo falhar, tentar outros servidores antes da API reserva</Check>
            <Field label="Tempo máximo para o vídeo carregar (ms)"><Num v={d.rooms.loadTimeoutMs} on={(v) => set((x) => { x.rooms.loadTimeoutMs = v; })} /></Field>
          </div>
        </div>
        <p className="wb-dim ao-foot">As salas usam o mesmo fluxo de servidores, proxies/Referer e ajustes do ExoPlayer das seções acima.</p>
      </Section>

      <Section title="ExoPlayer (rede e buffer)">
        <div className="ao-provs">
          <div className="ao-prov">
            <Field label="Tempo para conectar (ms)"><Num v={d.exo.connectTimeoutMs} on={(v) => set((x) => { x.exo.connectTimeoutMs = v; })} /></Field>
            <Field label="Tempo de leitura (ms)"><Num v={d.exo.readTimeoutMs} on={(v) => set((x) => { x.exo.readTimeoutMs = v; })} /></Field>
            <Field label="User-Agent"><textarea rows={3} spellCheck={false} value={d.exo.userAgent} onChange={(e) => set((x) => { x.exo.userAgent = e.target.value.replace(/[\r\n]/g, ""); })} /></Field>
            <Check v={d.exo.sendOrigin} on={(v) => set((x) => { x.exo.sendOrigin = v; })}>Mandar também o header Origin (quando o ExoPlayer manda o Referer)</Check>
            <Field label="Headers extras para todos (um por linha)"><textarea rows={3} spellCheck={false} value={hdrToText(d.exo.headers)} onChange={(e) => set((x) => { x.exo.headers = textToHdr(e.target.value); })} /></Field>
          </div>
          <div className="ao-prov">
            <Field label="Buffer mínimo (ms)"><Num v={d.exo.minBufferMs} on={(v) => set((x) => { x.exo.minBufferMs = v; })} /></Field>
            <Field label="Buffer máximo (ms)"><Num v={d.exo.maxBufferMs} on={(v) => set((x) => { x.exo.maxBufferMs = v; })} /></Field>
            <Field label="Buffer para começar a tocar (ms)"><Num v={d.exo.bufferForPlaybackMs} on={(v) => set((x) => { x.exo.bufferForPlaybackMs = v; })} /></Field>
            <Field label="Buffer para retomar após travar (ms)"><Num v={d.exo.bufferForPlaybackAfterRebufferMs} on={(v) => set((x) => { x.exo.bufferForPlaybackAfterRebufferMs = v; })} /></Field>
          </div>
        </div>
      </Section>

      <TestBox cfg={d} base={streamBase.replace(/\/+$/, "")} />

      <Section title="Avançado">
        <Check v={advanced} on={setAdvanced}>Editar o JSON completo</Check>
        {advanced && <textarea rows={16} spellCheck={false} autoCapitalize="off" value={json} onChange={(e) => fromJson(e.target.value)} />}
      </Section>

      <Note note={note} />
      <div className="ao-provs">
        <button type="button" className="wb-btn primary" disabled={busy} onClick={() => void save()}>{busy ? "Salvando…" : "Salvar configuração"}</button>
        <button type="button" className="wb-btn" disabled={busy} onClick={() => { const c = clone(DEFAULT_PLAYER_CONFIG); setD(c); setJson(JSON.stringify(c, null, 2)); setNote(null); }}>Restaurar o padrão (sem salvar)</button>
      </div>
    </>
  );
}

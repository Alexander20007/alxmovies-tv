import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { adminAddDnsBlock, adminDnsBlocks, adminRemoveDnsBlock } from "@/services/admin";
import { Note, Section } from "./ui";

/** Bloqueio de DNS (domínios). Só o dono mexe. Bloquear exemplo.com bloqueia também todos os subdomínios. */
export function DnsBlocks() {
  const qc = useQueryClient();
  const list = useQuery({ queryKey: ["admin-dns"], queryFn: adminDnsBlocks, retry: false });
  const [host, setHost] = useState("");
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState<{ ok: boolean; text: string } | null>(null);
  const refresh = () => void qc.invalidateQueries({ queryKey: ["admin-dns"] });

  async function add() {
    setBusy(true); setNote(null);
    try { await adminAddDnsBlock(host, reason); setHost(""); setReason(""); setNote({ ok: true, text: "Domínio bloqueado. Os aparelhos recebem a lista nova quando abrem o app ou voltam do segundo plano." }); refresh(); }
    catch (e) { setNote({ ok: false, text: e instanceof Error ? e.message : "Não foi possível bloquear." }); }
    setBusy(false);
  }
  async function remove(id: number) {
    setBusy(true); setNote(null);
    try { await adminRemoveDnsBlock(id); refresh(); } catch (e) { setNote({ ok: false, text: e instanceof Error ? e.message : "Não foi possível desbloquear." }); }
    setBusy(false);
  }

  const rows = list.data ?? [];
  return (
    <Section title="Domínios (DNS)">
      <p className="wb-dim ao-foot">
        Bloqueie qualquer domínio: o app deixa de carregar imagens, vídeos, downloads e APIs dele. Bloquear <b>exemplo.com</b> bloqueia também <b>cdn.exemplo.com</b>, <b>a.b.exemplo.com</b> e todos os outros subdomínios.
        Você pode colar um link inteiro (https://exemplo.com/pagina) que o painel guarda só o domínio. O painel não deixa bloquear o Supabase, o site nem o domínio de uma API de filmes ou canais em uso.
      </p>
      <div className="ao-prov">
        <label className="ao-field">Domínio
          <input value={host} autoCapitalize="off" autoCorrect="off" spellCheck={false} inputMode="url" placeholder="anuncios.exemplo.com" onChange={(e) => setHost(e.target.value.trim())} />
        </label>
        <label className="ao-field">Motivo (só você vê)
          <input value={reason} maxLength={120} placeholder="Ex.: anúncios, link malicioso…" onChange={(e) => setReason(e.target.value)} />
        </label>
        <Note note={note} />
        <button type="button" className="wb-btn primary" disabled={busy || !host} onClick={() => void add()}>{busy ? "Salvando…" : "Bloquear domínio"}</button>
      </div>

      <h3 className="ao-sub">Domínios bloqueados ({rows.length})</h3>
      {list.isLoading && <p className="wb-dim">Carregando…</p>}
      {list.isError && <p className="wb-dim">{(list.error as Error).message}</p>}
      {list.isSuccess && rows.length === 0 && <p className="wb-dim">Nenhum domínio bloqueado.</p>}
      <div className="ao-provs">
        {rows.map((r) => (
          <div key={r.id} className="ao-prov">
            <div className="ao-prov-head">
              <div>
                <b>🧱 {r.host}</b>
                <small>inclui *.{r.host}{r.reason ? ` · ${r.reason}` : ""} · desde {new Date(r.created_at).toLocaleDateString("pt-BR")}</small>
              </div>
              <button type="button" className="wb-btn" disabled={busy} onClick={() => void remove(r.id)}>Desbloquear</button>
            </div>
          </div>
        ))}
      </div>
    </Section>
  );
}

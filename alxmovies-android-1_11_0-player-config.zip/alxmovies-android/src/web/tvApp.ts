import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/lib/supabase";

/** Link de download do app da Smart TV (o dono cola em Admin → Resumo → App da Smart TV). Vazio = ainda não publicado. */
export interface TvApp { url: string; version: string; note: string }

export function useTvApp() {
  return useQuery({
    queryKey: ["tv-app"],
    staleTime: 5 * 60_000,
    retry: 0,
    queryFn: async (): Promise<TvApp> => {
      const { data, error } = await supabase.rpc("get_tv_app");
      const d = (!error && data && typeof data === "object" ? data : {}) as Partial<TvApp>;
      return { url: typeof d.url === "string" ? d.url : "", version: typeof d.version === "string" ? d.version : "", note: typeof d.note === "string" ? d.note : "" };
    },
  });
}

import { createElement, useEffect, useRef, useState, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { useSearchParams } from "react-router-dom";
import { posterUrl, tmdb } from "@/services/tmdb";
import { getPublicDownloads } from "@/services/siteDownloads";
import { useTvApp } from "./tvApp";
import { DownloadButton, Footer, Nav } from "./Chrome";
import { isAndroid, isDesktop, useRelease } from "./release";
import { Link } from "react-router-dom";

const FEATURES: { icon: string; title: string; text: string }[] = [
  { icon: "🎬", title: "Filmes e séries", text: "Catálogo atualizado, com detalhes, elenco, trailer e a opção de continuar de onde parou." },
  { icon: "📡", title: "TV ao vivo", text: "Canais de TV ao vivo com a programação do que está passando agora e do que vem a seguir." },
  { icon: "👥", title: "Salas para assistir junto", text: "Todo mundo vê a mesma coisa ao mesmo tempo, com chat, reações e fila de filmes." },
  { icon: "✨", title: "Laura IA", text: "Uma assistente que recomenda e abre filmes, séries e canais — por texto ou por voz." },
  { icon: "⬇️", title: "Downloads dentro do app", text: "Baixe filmes e episódios, acompanhe o progresso e assista sem internet, como no YouTube." },
  { icon: "🛡️", title: "Perfis e controle parental", text: "Cada pessoa com o seu perfil e a classificação indicativa liberada para cada um." },
  { icon: "💬", title: "Amigos e mensagens", text: "Converse, adicione amigos e receba os avisos das conversas no celular." },
  { icon: "⭐", title: "Sua lista e avaliações", text: "Salve o que quer ver, marque como visto e diga o que achou: gostei, amei ou não gostei." },
  { icon: "🎞️", title: "Trailers e informações", text: "Veja o trailer, o elenco e a filmografia de qualquer ator ou atriz." },
  { icon: "🎚️", title: "Assista do seu jeito", text: "Legendas, qualidade da imagem, velocidade e ajuste de brilho e volume na ponta do dedo." },
  { icon: "🔔", title: "Avisos e novidades", text: "Notificações de mensagens, avisos da equipe e aviso quando existe versão nova do app." },
  { icon: "🎡", title: "Planos e Roda da Sorte", text: "Entre no site, gire a roda todo dia e ganhe downloads extras ou um plano por alguns dias." },
  { icon: "🛠️", title: "Seja admin", text: "Faça um teste rápido no site e ganhe Premium, selo de admin e um painel para ajudar a equipe." },
  { icon: "🔄", title: "Sempre atualizado", text: "Atualize o app em poucos toques, sem precisar voltar ao site." },
];

const STEPS = [
  { t: "Baixe o arquivo", d: "Toque em “Baixar o app” e aguarde o ALXmovies.apk terminar de baixar." },
  { t: "Abra o arquivo", d: "Abra o download pelo aviso do navegador ou pelo app Arquivos. Se o Android pedir, ative “Permitir desta fonte”." },
  { t: "Instale", d: "Toque em Instalar. O Android pode avisar que o app não veio da Play Store — é normal para apps instalados por APK." },
  { t: "Entre e aproveite", d: "Abra o ALXmovies, crie sua conta ou entre e pronto. As próximas atualizações são avisadas dentro do app." },
];

const FAQ = [
  { q: "O app é gratuito?", a: "Existe o plano Grátis, com anúncios e um limite mensal de downloads. Os planos Apoiador, Premium e Família têm mais downloads e sem anúncios, e você também pode ganhar um plano na Roda da Sorte." },
  { q: "Por que o site não tem os filmes?", a: "No site você cria e gerencia a conta, vê os planos, gira a Roda da Sorte e baixa o app. Tudo o que você assiste — filmes, séries, canais e salas — fica no aplicativo." },
  { q: "Posso assistir sem internet?", a: "Pode. Baixe o filme ou episódio dentro do app, abra a aba Downloads e assista quando quiser, mesmo sem conexão." },
  { q: "Como viro admin?", a: "Entre na sua conta no site e faça o teste em “Seja admin”. Quem passa ganha o plano Premium incluso, o selo de admin e um painel para sugerir avisos." },
  { q: "Preciso criar uma conta?", a: "Sim, uma conta gratuita. Com ela você tem seus perfis, sua lista, o que já viu e pode usar as salas e conversar com amigos." },
  { q: "Funciona no iPhone?", a: "Por enquanto só em celulares Android. Abra este site no seu Android para baixar." },
  { q: "Posso ter perfis para a família?", a: "Pode. Cada perfil tem a sua lista e a classificação indicativa liberada para ele, ideal para crianças." },
  { q: "Como atualizo o app?", a: "O próprio app avisa quando há uma versão nova (também por notificação) e atualiza sem você precisar voltar aqui." },
  { q: "A instalação não abriu, e agora?", a: "Confirme que você permitiu instalar apps desta fonte (Configurações › Segurança ou Apps) e tente abrir o arquivo de novo. Se baixou pela barra de notificações, abra por lá." },
];

const fmtDate = (iso: string) => (iso ? new Date(iso).toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" }) : "");

/** Aparece suavemente quando entra na tela. */
function Rv({ tag = "div", className = "", delay = 0, children }: { tag?: "div" | "article" | "section" | "li"; className?: string; delay?: number; children: ReactNode }) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [on, setOn] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el || typeof IntersectionObserver === "undefined") { setOn(true); return; }
    const io = new IntersectionObserver((es) => { if (es.some((e) => e.isIntersecting)) { setOn(true); io.disconnect(); } }, { rootMargin: "0px 0px -8% 0px", threshold: 0.08 });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return createElement(tag as "div", { ref, className: `wb-rv${on ? " in" : ""} ${className}`.trim(), style: { transitionDelay: `${delay}ms` } }, children);
}

/** Número que sobe de 0 até o valor quando aparece. */
function CountUp({ to }: { to: number }) {
  const ref = useRef<HTMLSpanElement | null>(null);
  const [n, setN] = useState(0);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let raf = 0, started = false;
    const run = () => {
      if (started) return; started = true;
      const t0 = performance.now(), dur = 1400;
      const tick = (t: number) => { const k = Math.min(1, (t - t0) / dur); setN(Math.round(to * (1 - Math.pow(1 - k, 3)))); if (k < 1) raf = requestAnimationFrame(tick); };
      raf = requestAnimationFrame(tick);
    };
    if (typeof IntersectionObserver === "undefined") { setN(to); return; }
    const io = new IntersectionObserver((es) => { if (es.some((e) => e.isIntersecting)) { run(); io.disconnect(); } }, { threshold: 0.4 });
    io.observe(el);
    return () => { io.disconnect(); cancelAnimationFrame(raf); };
  }, [to]);
  return <span ref={ref}>{n.toLocaleString("pt-BR")}</span>;
}

const MARQUEE = ["Filmes", "Séries", "TV ao vivo", "Salas para assistir junto", "Laura IA", "Downloads offline", "Perfis e controle parental", "Amigos e mensagens", "Trailers e elenco"];

function Eyebrow({ children }: { children: ReactNode }) { return <span className="wb-eye">{children}</span>; }

function usePosters() {
  const q = useQuery({ queryKey: ["web-trending"], queryFn: () => tmdb.trending("movie", "week"), staleTime: 30 * 60_000, retry: 0 });
  return (q.data?.results ?? []).filter((m) => m.poster_path);
}

function PhoneWall({ posters }: { posters: { id: number; poster_path: string | null }[] }) {
  const list = posters.slice(0, 18);
  const cols = [0, 1, 2].map((c) => list.filter((_, i) => i % 3 === c));
  return (
    <div className="wb-phone" aria-hidden>
      <div className="wb-phone-top"><b>ALXMOVIES</b><i /><i /></div>
      <div className="wb-wall">
        {cols.map((col, ci) => (
          <div key={ci} className={`wb-col c${ci}`}>
            {[...col, ...col].map((m, i) => <img key={`${m.id}-${i}`} src={posterUrl(m.poster_path, "w342")} alt="" loading="lazy" />)}
            {!col.length && Array.from({ length: 6 }, (_, i) => <span key={i} className="wb-tile" />)}
          </div>
        ))}
      </div>
      <div className="wb-phone-nav"><i /><i /><i /><i /><i /></div>
    </div>
  );
}

/** Mini-telas desenhadas em CSS para mostrar como o app é, sem precisar de capturas de tela. */
const SHOWS = [
  { id: "inicio", tab: "Início", title: "Tudo na tela inicial", text: "Destaques que passam sozinhos, o que você estava vendo, filmes e séries em alta e atalhos para tudo." },
  { id: "canais", tab: "TV ao vivo", title: "Canais ao vivo", text: "Veja quais canais estão no ar agora, o programa atual e o próximo, e abra com um toque." },
  { id: "salas", tab: "Salas", title: "Assista junto", text: "Crie uma sala, chame os amigos e vejam juntos, com chat e reações em tempo real." },
  { id: "laura", tab: "Laura IA", title: "Peça para a Laura", text: "Diga o que quer ver. A Laura indica, abre o filme ou o canal e cuida da sua lista." },
] as const;

function Screen({ id, posters }: { id: (typeof SHOWS)[number]["id"]; posters: { id: number; poster_path: string | null }[] }) {
  if (id === "inicio") {
    return (
      <div className="wb-scr">
        <div className="wb-scr-hero">{posters[0] && <img src={posterUrl(posters[0].poster_path, "w342")} alt="" />}<div><small>EM ALTA HOJE</small><b>Título em destaque</b></div></div>
        <p className="wb-scr-h">Continuar assistindo</p>
        <div className="wb-scr-row">{posters.slice(1, 5).map((m) => <img key={m.id} src={posterUrl(m.poster_path, "w342")} alt="" />)}</div>
        <p className="wb-scr-h">Em alta</p>
        <div className="wb-scr-row">{posters.slice(5, 9).map((m) => <img key={m.id} src={posterUrl(m.poster_path, "w342")} alt="" />)}</div>
      </div>
    );
  }
  if (id === "canais") {
    const ch = [["📰", "Notícias"], ["⚽", "Esportes"], ["🎬", "Filmes"], ["🧸", "Infantil"], ["🎵", "Música"], ["📺", "Variedades"]];
    return (
      <div className="wb-scr">
        <p className="wb-scr-h">📡 Canais ao vivo</p>
        <div className="wb-scr-ch">{ch.map(([e, n], i) => <span key={n}><em className={i === 5 ? "off" : ""}>{i === 5 ? "OFFLINE" : "AO VIVO"}</em><b>{e}</b><small>{n}</small></span>)}</div>
        <div className="wb-scr-now"><small>AGORA</small><b>Programa em exibição</b><i><u /></i></div>
      </div>
    );
  }
  if (id === "salas") {
    return (
      <div className="wb-scr">
        <div className="wb-scr-video"><span>▶</span></div>
        <div className="wb-scr-chat">
          <p><b>Ana</b> bora começar! 🍿</p>
          <p className="me">Já estou aqui</p>
          <p><b>Beto</b> que cena 😮</p>
        </div>
        <div className="wb-scr-people"><span>A</span><span>B</span><span>C</span><span>+2</span></div>
      </div>
    );
  }
  return (
    <div className="wb-scr">
      <div className="wb-scr-msgs">
        <p className="me">Quero um filme de ação para hoje</p>
        <p className="bot">Separei três opções para você 🎬</p>
        <div className="wb-scr-row">{posters.slice(9, 12).map((m) => <img key={m.id} src={posterUrl(m.poster_path, "w342")} alt="" />)}</div>
        <p className="me">Reproduzir o primeiro</p>
        <p className="done">✓ Abrindo o filme…</p>
      </div>
    </div>
  );
}

function Showcase({ posters }: { posters: { id: number; poster_path: string | null }[] }) {
  const [i, setI] = useState(0);
  useEffect(() => { const t = setInterval(() => setI((n) => (n + 1) % SHOWS.length), 6000); return () => clearInterval(t); }, []);
  const cur = SHOWS[i];
  return (
    <div className="wb-show">
      <div className="wb-show-txt">
        <div className="wb-tabs" role="tablist">
          {SHOWS.map((s, n) => <button key={s.id} type="button" role="tab" aria-selected={n === i} className={n === i ? "on" : ""} onClick={() => setI(n)}>{s.tab}</button>)}
        </div>
        <h3>{cur.title}</h3>
        <p>{cur.text}</p>
      </div>
      <div className="wb-mock"><Screen id={cur.id} posters={posters} /></div>
    </div>
  );
}

function ShareSite() {
  const [done, setDone] = useState(false);
  const go = async () => {
    const data = { title: "ALXmovies", text: "Filmes, séries e TV ao vivo no seu celular Android.", url: window.location.origin };
    try {
      if (navigator.share) { await navigator.share(data); return; }
      await navigator.clipboard.writeText(data.url); setDone(true); setTimeout(() => setDone(false), 2000);
    } catch { /* cancelou */ }
  };
  return <button type="button" className="wb-btn" onClick={() => void go()}>{done ? "Link copiado!" : "Convidar um amigo"}</button>;
}

export default function Landing() {
  const { info, apkUrl } = useRelease();
  const posters = usePosters();
  const [params] = useSearchParams();
  const [open, setOpen] = useState<number | null>(0);
  const [stick, setStick] = useState(false);
  const [prog, setProg] = useState(0);
  const pub = useQuery({ queryKey: ["site-downloads"], queryFn: getPublicDownloads, staleTime: 5 * 60_000, retry: 0 });
  const downloads = pub.data ?? 0;
  const tv = useTvApp().data;
  const [tvCopied, setTvCopied] = useState(false);
  useEffect(() => { document.title = "ALXmovies — Filmes, séries e TV ao vivo no seu celular"; }, []);
  useEffect(() => {
    const on = () => {
      setStick(window.scrollY > 560);
      const h = document.documentElement.scrollHeight - window.innerHeight;
      setProg(h > 0 ? Math.min(1, window.scrollY / h) : 0);
    };
    on(); window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);

  const band: { n?: number; text?: string; label: string }[] = [
    ...(downloads > 0 ? [{ n: downloads, label: "downloads do app" }] : []),
    { n: FEATURES.length, label: "recursos em um só app" },
    ...(info?.version ? [{ text: `v${info.version}`, label: "versão mais recente" }] : []),
    { text: "Grátis", label: "para começar agora" },
  ];

  return (
    <div className="wb">
      <div className="wb-progress" aria-hidden style={{ transform: `scaleX(${prog})` }} />
      <Nav />
      {params.get("reset") === "ok" && <div className="wb-banner ok">Senha alterada com sucesso! Abra o app do ALXmovies e entre com a nova senha.</div>}

      <section className="wb-hero">
        <div className="wb-aurora" aria-hidden><i /><i /><i /></div>
        <div className="wb-gridbg" aria-hidden />
        <div className="wb-glow" aria-hidden />
        <div className="wb-hero-txt">
          <span className="wb-pill"><u />Para Android · Grátis</span>
          <h1>Filmes, séries e <span>TV ao vivo</span> no seu celular</h1>
          <p>Um só app para assistir, salvar sua lista, conversar com amigos e ver junto em salas. Baixe o ALXmovies e comece agora.</p>
          <div className="wb-cta">
            <DownloadButton big />
            <a className="wb-btn big ghost" href="#telas">Ver por dentro</a>
          </div>
          <ul className="wb-meta">
            {info?.version && <li>Versão <b>{info.version}</b></li>}
            {info?.date && <li>Atualizado em <b>{fmtDate(info.date)}</b></li>}
            {downloads > 0 && <li><b>{downloads.toLocaleString("pt-BR")}</b> downloads</li>}
          </ul>
        </div>
        <div className="wb-stage">
          <PhoneWall posters={posters} />
          <div className="wb-chip c1"><b>📡</b><span>AO VIVO<small>Canais no ar agora</small></span></div>
          <div className="wb-chip c2"><b>👥</b><span>Sala com amigos<small>Todos vendo juntos</small></span></div>
          <div className="wb-chip c3"><b>✨</b><span>Laura IA<small>Peça e ela abre</small></span></div>
        </div>
      </section>

      <section className="wb-marquee" aria-label="Destaques do app">
        <div className="wb-marquee-track">
          {[...MARQUEE, ...MARQUEE].map((t, i) => <span key={i}><i />{t}</span>)}
        </div>
      </section>

      <section className="wb-band">
        {band.map((b) => (
          <Rv key={b.label} className="wb-band-i">
            <b>{b.n !== undefined ? <CountUp to={b.n} /> : b.text}</b>
            <span>{b.label}</span>
          </Rv>
        ))}
      </section>

      <section className="wb-stats">
        <div><b>🎬</b><span>Filmes e séries</span></div>
        <div><b>📡</b><span>TV ao vivo</span></div>
        <div><b>👥</b><span>Salas e amigos</span></div>
        <div><b>✨</b><span>Laura IA</span></div>
      </section>

      <section className="wb-sec" id="recursos">
        <Rv><Eyebrow>Recursos</Eyebrow><h2>Tudo o que o app faz por você</h2>
        <p className="wb-sub">Uma conta, um app, tudo no seu celular.</p></Rv>
        <div className="wb-grid">
          {FEATURES.map((f, i) => <Rv key={f.title} tag="article" className="wb-card" delay={(i % 4) * 70}><span>{f.icon}</span><h3>{f.title}</h3><p>{f.text}</p></Rv>)}
        </div>
      </section>

      <section className="wb-sec" id="telas">
        <Rv><Eyebrow>Telas</Eyebrow><h2>Conheça por dentro</h2>
        <p className="wb-sub">Um jeito simples e bonito de assistir.</p></Rv>
        <Rv><Showcase posters={posters} /></Rv>
      </section>

      {posters.length > 0 && (
        <section className="wb-sec wide">
          <Rv><Eyebrow>Em alta</Eyebrow><h2>Em alta agora no app</h2>
          <p className="wb-sub">Os filmes mais vistos da semana.</p></Rv>
          <div className="wb-reel"><div className="wb-reel-track">{[...posters.slice(0, 14), ...posters.slice(0, 14)].map((m, i) => <img key={`${m.id}-${i}`} src={posterUrl(m.poster_path, "w342")} alt="" loading="lazy" />)}</div></div>
        </section>
      )}

      {info && info.notes.length > 0 && (
        <section className="wb-sec narrow">
          <Rv><Eyebrow>Novidades</Eyebrow><h2>Novidades da versão {info.version}</h2>
          <ul className="wb-notes">{info.notes.map((n, i) => <li key={i}>{n}</li>)}</ul></Rv>
        </section>
      )}

      <section className="wb-sec narrow" id="roda">
        <Rv className="wb-feat">
          <Eyebrow>Prêmios</Eyebrow>
          <h2>🎡 Roda da Sorte</h2>
          <p className="wb-sub">Entre na sua conta, gire uma vez por dia e ganhe downloads extras ou um plano por alguns dias.</p>
          <div className="wb-row center" style={{ marginTop: 22 }}>
            <Link className="wb-btn primary big" to="/roda">Girar a roda</Link>
            <Link className="wb-btn big" to="/planos">Ver planos</Link>
          </div>
        </Rv>
      </section>

      <section className="wb-sec" id="instalar">
        <Rv><Eyebrow>Instalação</Eyebrow><h2>Como instalar</h2>
        <p className="wb-sub">Leva menos de um minuto.</p></Rv>
        <ol className="wb-steps">
          {STEPS.map((s, i) => <Rv key={s.t} tag="li" delay={i * 90}><span>{i + 1}</span><div><h3>{s.t}</h3><p>{s.d}</p></div></Rv>)}
        </ol>
        <div className="wb-cta center"><DownloadButton big /></div>
        {isDesktop() && (
          <div className="wb-qr">
            <img src={`https://api.qrserver.com/v1/create-qr-code/?size=220x220&margin=8&data=${encodeURIComponent(window.location.origin)}`} alt="QR code para abrir o site no celular" width={150} height={150} />
            <p><b>Está no computador?</b><br />Aponte a câmera do celular Android para o código e baixe por lá.</p>
          </div>
        )}
      </section>

      <section className="wb-sec" id="tv">
        <Rv><Eyebrow>Smart TV</Eyebrow><h2>Também na sua TV</h2>
        <p className="wb-sub">O mesmo ALXmovies na tela grande, sem digitar e-mail nem senha com o controle remoto.</p></Rv>
        <Rv className="wb-tv">
          <div className="wb-tv-art" aria-hidden="true">
            <div className="wb-tv-screen">
              <div className="wb-tv-posters"><i /><i /><i /><i /><i /><i /></div>
              <div className="wb-tv-code"><small>Código</small><b>4829 1637</b></div>
            </div>
            <div className="wb-tv-stand" />
          </div>
          <div className="wb-tv-body">
            <ol className="wb-tv-steps">
              <li><span>1</span><div><h3>Baixe o app da TV</h3><p>Use o botão abaixo. Na TV, o jeito mais fácil é o app <b>Downloader</b>: digite o endereço do link.</p></div></li>
              <li><span>2</span><div><h3>Instale na TV</h3><p>Funciona em TVs com Android TV ou Google TV. Permita a instalação de apps de fora da loja quando a TV pedir.</p></div></li>
              <li><span>3</span><div><h3>Gere o código no celular</h3><p>No app do celular, toque na sua <b>foto de perfil</b> e em <b>Entrar na Smart TV</b>. Aparece um código de 8 números.</p></div></li>
              <li><span>4</span><div><h3>Digite na TV</h3><p>Na TV, escolha <b>Entrar com código</b> e digite os números. Pronto, a mesma conta, sem senha.</p></div></li>
            </ol>
            {tv?.url ? (
              <div className="wb-tv-cta">
                <a className="wb-btn primary big" href={tv.url} rel="noopener">
                  <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="M12 3v12m0 0-5-5m5 5 5-5M5 21h14" /></svg>
                  <span>Baixar para Smart TV</span>{tv.version && <em>v{tv.version.replace(/^v/i, "")}</em>}
                </a>
                <button type="button" className="wb-btn big ghost" onClick={() => { void navigator.clipboard?.writeText(tv.url).then(() => { setTvCopied(true); window.setTimeout(() => setTvCopied(false), 1800); }).catch(() => {}); }}>{tvCopied ? "Link copiado ✓" : "Copiar link"}</button>
              </div>
            ) : (
              <div className="wb-note">O app para Smart TV está a caminho. Volte aqui em breve para baixar.</div>
            )}
            {tv?.note && <p className="wb-dim wb-tv-note">{tv.note}</p>}
          </div>
        </Rv>
      </section>

      <section className="wb-sec narrow" id="faq">
        <Rv><Eyebrow>Ajuda</Eyebrow><h2>Dúvidas frequentes</h2></Rv>
        <div className="wb-faq">
          {FAQ.map((f, i) => (
            <div key={f.q} className={`wb-q${open === i ? " open" : ""}`}>
              <button type="button" onClick={() => setOpen(open === i ? null : i)} aria-expanded={open === i}><span>{f.q}</span><i /></button>
              {open === i && <p>{f.a}</p>}
            </div>
          ))}
        </div>
      </section>

      <section className="wb-final">
        <div className="wb-final-card">
          <div className="wb-aurora" aria-hidden><i /><i /></div>
          <h2>Pronto para assistir?</h2>
          <p>Baixe o ALXmovies e tenha tudo na palma da mão.</p>
          <div className="wb-cta center"><DownloadButton big /><ShareSite /></div>
        </div>
      </section>
      <Footer />

      {isAndroid() && stick && (
        <a className="wb-sticky" href={apkUrl}><span>ALXmovies</span><b>Baixar o app</b></a>
      )}
    </div>
  );
}

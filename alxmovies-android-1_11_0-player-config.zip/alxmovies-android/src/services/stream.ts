import { CONFIG } from "@/lib/config";
import { apiFetch } from "@/lib/proxy";
import { defaultNet, getPlayerConfig, planForServer, refreshPlayerConfigSoon, type NetOptions, type PlayerConfig } from "@/lib/playerConfig";
import type { MediaType } from "@/types";

export interface StreamRequest { type: MediaType; id: number; season?: number; episode?: number }
export interface StreamResult {
  /** de qual API veio o link: a principal (alx-api) ou a reserva (a do player das salas) */
  source: "main" | "fallback";
  title: string;
  /** link FINAL, já com o proxy certo do servidor (regras em Admin → Player) */
  m3u8: string;
  server: string;
  servers: { label: string; ok: boolean }[];
  nextEpisode: { season: number; episode: number } | null;
  expiresAt: number | null;
  cached: boolean;
  /** ajustes de rede do ExoPlayer (tempos, User-Agent, buffer, headers) vindos da configuração remota */
  net: NetOptions;
}
interface Opts extends StreamRequest { server?: string | null; onSlow?: () => void }
export interface ResolveOpts extends Opts {
  /** usa só a API reserva (ex.: o vídeo da principal falhou no meio da reprodução) */
  fallbackOnly?: boolean;
}

/** Nome do "servidor" que representa a API reserva no menu do player. */
export const FALLBACK_SERVER = "Reserva";

const base = () => CONFIG.STREAM_BASE_URL.replace(/\/+$/, "");
/** Links de vídeo (player/1DM): rota de mídia do proxy, pois esses pedidos não carregam JWT/nonce. */
const mediaBase = () => CONFIG.STREAM_MEDIA_URL.replace(/\/+$/, "");

const mediaPath = (r: StreamRequest) => (r.type === "tv" ? `tv/${r.id}/${r.season}/${r.episode}` : `movie/${r.id}`);

// ---------- lista de servidores (GET {serversPath}/movie/{id} · /tv/{id}/{s}/{e}) ----------
type ServerRow = { label: string; ok: boolean };
const serversCache = new Map<string, { at: number; list: ServerRow[] }>();
const SERVERS_TTL_MS = 60_000;

const toRows = (arr: unknown, cfg: PlayerConfig): ServerRow[] =>
  (Array.isArray(arr) ? arr : [])
    .filter((s: any) => s && typeof s.label === "string" && s.label)
    .map((s: any) => ({ label: String(s.label), ok: cfg.flow.budgetMode === "success" ? s.budget === "success" : true }));

export async function fetchServers(r: StreamRequest, signal?: AbortSignal): Promise<ServerRow[]> {
  const cfg = getPlayerConfig();
  const key = `${r.type}-${mediaPath(r)}-${cfg.flow.budgetMode}`;
  const hit = serversCache.get(key);
  if (hit && Date.now() - hit.at < SERVERS_TTL_MS) return hit.list;
  const res = await apiFetch(`${base()}${cfg.flow.serversPath}/${mediaPath(r)}`, { signal });
  const data: any = await res.json().catch(() => null);
  if (!res.ok || data?.erro) throw new Error(data?.erro || "Não foi possível listar os servidores.");
  const list = toRows(data?.servidores, cfg);
  if (list.length) serversCache.set(key, { at: Date.now(), list });
  return list;
}

// ---------- link do vídeo (GET {streamPath}/movie/{id}?servidor=...) ----------
async function requestOnce(o: Opts, controller: AbortController, cfg: PlayerConfig) {
  let url = `${base()}${cfg.flow.streamPath}/${mediaPath(o)}`;
  if (o.server) url += `?${cfg.flow.serverParam}=${encodeURIComponent(o.server)}`;

  const slow = setTimeout(() => o.onSlow?.(), cfg.flow.slowAfterMs);
  let data: any = null;
  try {
    let res: Response;
    try {
      res = await apiFetch(url, { signal: controller.signal });
    } catch (err) {
      if ((err as Error).name === "AbortError") throw new Error("O servidor de vídeo demorou demais para responder. Tente de novo.");
      await new Promise((r) => setTimeout(r, 1200));
      res = await apiFetch(url, { signal: controller.signal }).catch(() => {
        throw new Error("Sem conexão com o servidor de vídeo. Verifique sua internet.");
      });
    }
    data = await res.json().catch(() => null);
  } finally {
    clearTimeout(slow);
  }
  if (!data?.m3u8 || data.erro) throw new Error(data?.erro || data?.ultimo_erro || "Este vídeo não está disponível no momento.");
  return data;
}

const titleOf = (t: unknown): string =>
  typeof t === "string" ? t : t && typeof t === "object" ? String((t as any).pt || (t as any).en || Object.values(t as object)[0] || "") : "";

export async function fetchStream(o: Opts): Promise<StreamResult> {
  const cfg = getPlayerConfig();
  const controller = new AbortController();
  const kill = setTimeout(() => controller.abort(), cfg.flow.giveUpMs);
  let data: any;
  let chosen = o.server || "";
  let listed: Promise<ServerRow[]> | null = null;
  try {
    // a lista de servidores vem em paralelo com o link (não faz o vídeo esperar)
    if (cfg.flow.listServers) listed = fetchServers(o, controller.signal).catch(() => []);
    if (o.server) data = await requestOnce(o, controller, cfg);
    else {
      // Automático: servidor prioritário (se houver) → a API escolhe → próximos da lista, até autoTryMax
      const tried = new Set<string>();
      let lastErr: unknown = null;
      const attempt = async (srv: string | null) => {
        try { data = await requestOnce({ ...o, server: srv }, controller, cfg); chosen = srv || data.servidor || ""; return true; }
        catch (e) { lastErr = e; return false; }
      };
      let ok = false;
      if (cfg.flow.priorityServer) { tried.add(cfg.flow.priorityServer); ok = await attempt(cfg.flow.priorityServer); }
      if (!ok) ok = await attempt(null);
      if (!ok && cfg.flow.autoTryMax > 0) {
        const list = (await (listed ?? fetchServers(o, controller.signal).catch(() => []))).filter((s) => s.ok && !tried.has(s.label));
        for (const s of list.slice(0, cfg.flow.autoTryMax)) { if (await attempt(s.label)) { ok = true; break; } }
      }
      if (!ok) throw lastErr instanceof Error ? lastErr : new Error("Este vídeo não está disponível no momento.");
    }
  } finally {
    clearTimeout(kill);
  }

  const server: string = data.servidor || chosen || "";
  // proxy certo + Referer certo para ESTE servidor (regras vindas do painel)
  const plan = planForServer(cfg, chosen || server, data.m3u8, typeof data.embed === "string" ? data.embed : undefined, mediaBase());

  // a lista não pode atrasar o vídeo: espera no máximo 3 s por ela
  let servers = listed ? await Promise.race([listed, new Promise<ServerRow[]>((r) => setTimeout(() => r([]), 3000))]) : [];
  if (!servers.length) servers = toRows(data.servidores_disponiveis, cfg);
  const n = data.proximo_episodio;
  return {
    source: "main",
    title: titleOf(data.titulo),
    m3u8: plan.url,
    server,
    servers,
    nextEpisode: n?.season && n?.episode ? { season: Number(n.season), episode: Number(n.episode) } : null,
    expiresAt: data.expires_at ? data.expires_at * 1000 : null,
    cached: !!data.cache,
    net: plan.net,
  };
}

// ---------- API reserva (a mesma lógica que já existia no player das salas) ----------
export async function fetchFallbackStream({ type, id, season, episode }: StreamRequest): Promise<StreamResult> {
  const cfg = getPlayerConfig();
  const fb = CONFIG.EXTRACTOR_BASE_URL.replace(/\/+$/, "");
  const fbMedia = CONFIG.EXTRACTOR_MEDIA_URL.replace(/\/+$/, ""); // links de vídeo: rota de mídia do proxy
  let url = `${fb}/extract?tmdb_id=${id}&type=${type || "movie"}`;
  if (type === "tv" && season && episode) url += `&season=${season}&episode=${episode}`;

  const controller = new AbortController();
  const kill = setTimeout(() => controller.abort(), cfg.fallback.giveUpMs);
  try {
    const res = await apiFetch(url, { signal: controller.signal });
    const data = await res.json().catch(() => null);
    if (!data?.success || !data.hlsUrl) throw new Error("Não foi possível carregar o vídeo.");
    return {
      source: "fallback",
      title: "",
      m3u8: `${fbMedia}/proxy?url=${encodeURIComponent(data.hlsUrl)}&cookies=${encodeURIComponent(data.cookies || "")}`,
      server: FALLBACK_SERVER,
      servers: [],
      nextEpisode: null,
      expiresAt: null,
      cached: false,
      net: defaultNet(cfg),
    };
  } catch (e) {
    if ((e as Error).name === "AbortError") throw new Error("O servidor de vídeo demorou demais para responder. Tente de novo.");
    throw e instanceof Error ? e : new Error("Não foi possível carregar o vídeo.");
  } finally {
    clearTimeout(kill);
  }
}

/**
 * Ponto único de entrada dos dois players (tela de assistir e salas) e dos downloads.
 * 1) tenta a API principal; 2) se ela estiver offline, não achar o link, ou demorar mais de `fallback.afterMs`,
 * a API reserva carrega em segundo plano e vale o primeiro link que chegar (se a reserva estiver ligada no painel).
 * Se o usuário escolheu um servidor específico, só a principal é usada.
 */
export function resolveStream(o: ResolveOpts): Promise<StreamResult> {
  refreshPlayerConfigSoon();   // pega mudanças do painel sem esperar o app reabrir (vale para o próximo vídeo)
  const cfg = getPlayerConfig();
  if (o.fallbackOnly) return fetchFallbackStream(o);
  if (o.server || !cfg.fallback.enabled) return fetchStream(o);

  return new Promise<StreamResult>((resolve, reject) => {
    let settled = false;
    let mainErr: unknown = null;
    let fbStarted = false, fbFailed = false, mainFailed = false;
    let timer: ReturnType<typeof setTimeout>;

    const win = (r: StreamResult) => { if (!settled) { settled = true; clearTimeout(timer); resolve(r); } };
    const lose = () => {
      if (settled || !mainFailed || !fbFailed) return;
      settled = true; clearTimeout(timer);
      reject(mainErr instanceof Error ? mainErr : new Error("Este vídeo não está disponível no momento."));
    };
    const startFallback = () => {
      if (fbStarted || settled) return;
      fbStarted = true;
      fetchFallbackStream(o).then(win, () => { fbFailed = true; lose(); });
    };

    timer = setTimeout(startFallback, cfg.fallback.afterMs);
    fetchStream(o).then(win, (e) => { mainErr = e; mainFailed = true; startFallback(); lose(); });
  });
}

import { supabase } from "@/lib/supabase";
import { CONFIG } from "@/lib/config";

/**
 * Entrar no app da Smart TV por código (a TV não tem campo de e-mail/senha):
 *  1) CELULAR (já logado): createTvLoginCode() gera um código de 8 números, válido por 10 minutos e de uso único.
 *  2) TV: signInWithTvCode(código digitado) troca o código por uma sessão da mesma conta (função de borda "tv-login").
 */
export interface TvCode { code: string; expiresAt: number }

export async function createTvLoginCode(): Promise<TvCode> {
  const { data, error } = await supabase.rpc("create_tv_login_code");
  if (error) throw new Error(error.message);
  const d = data as { code?: string; expires_at?: string } | null;
  if (!d?.code) throw new Error("Não foi possível gerar o código. Tente de novo.");
  const exp = d.expires_at ? new Date(d.expires_at).getTime() : Date.now() + 10 * 60_000;
  return { code: d.code, expiresAt: Number.isFinite(exp) ? exp : Date.now() + 10 * 60_000 };
}

/** Usado pelo app da TV: entra na conta com o código que o celular mostrou. */
export async function signInWithTvCode(code: string): Promise<void> {
  const r = await fetch(`${CONFIG.SUPABASE_URL}/functions/v1/tv-login`, {
    method: "POST",
    headers: { "Content-Type": "application/json", apikey: CONFIG.SUPABASE_ANON_KEY, Authorization: `Bearer ${CONFIG.SUPABASE_ANON_KEY}` },
    body: JSON.stringify({ code }),
  });
  const d = (await r.json().catch(() => ({}))) as { session?: { access_token?: string; refresh_token?: string }; error?: string };
  if (!r.ok || !d.session?.access_token || !d.session.refresh_token) throw new Error(d.error || "Não foi possível entrar com o código.");
  const { error } = await supabase.auth.setSession({ access_token: d.session.access_token, refresh_token: d.session.refresh_token });
  if (error) throw new Error(error.message);
}

/**
 * Configuração REMOTA do player (tabela `player_config` do Supabase; o dono edita em Admin → 🎛 Player).
 * Define como o app busca servidores, qual proxy/Referer usa em cada servidor e os ajustes do ExoPlayer.
 * O app guarda uma cópia no aparelho e atualiza em segundo plano. Cada campo é conferido aqui: valor inválido
 * vira o padrão, então uma configuração errada no painel nunca deixa o app sem player.
 */
export type ProxyMode = "default" | "vip" | "none";
export interface PlayerRule { match: string; proxy: ProxyMode; referer?: string; headers?: Record<string, string> }
export interface PlayerConfig {
  flow: {
    serversPath: string; streamPath: string; serverParam: string;
    /** consulta a lista de servidores em {serversPath} (o stream também pode trazer a lista) */
    listServers: boolean;
    /** "all": todos os servidores liberados (como no HTML de teste) · "success": só os com status success */
    budgetMode: "all" | "success";
    /** servidor tentado primeiro no Automático ("" = deixa a API escolher) */
    priorityServer: string;
    /** no Automático, quantos servidores da lista tentar se o primeiro falhar */
    autoTryMax: number;
    slowAfterMs: number; giveUpMs: number;
  };
  proxy: {
    defaultMode: ProxyMode;
    paths: { default: string; vip: string };
    urlParam: string; refererParam: string;
    defaultReferer: string; useEmbedReferer: boolean;
    rules: PlayerRule[];
  };
  fallback: { enabled: boolean; afterMs: number; giveUpMs: number };
  /** Player das salas: sincronia, anfitrião e recuperação de erro */
  rooms: {
    /** servidor principal das salas (nome exato, ex.: "VIP Player"); vazio = Automático. Se falhar, tenta os outros. */
    mainServer: string;
    /** de quanto em quanto tempo o anfitrião manda sinal de vida/posição (ms) */
    heartbeatMs: number;
    /** anfitrião pausado/carregando também manda "ping" (evita o falso "anfitrião reconectando") */
    pingWhenPaused: boolean;
    /** quanto tempo o anfitrião precisa ficar FORA da presença (e sem sinal) para aparecer "Aguardando o anfitrião" (ms) */
    hostGraceMs: number;
    /** depois de quanto tempo ausente o próximo da fila assume a sala sozinho (ms) */
    claimHostAfterMs: number;
    /** só corrige o tempo de quem assiste se estiver mais de X s fora do anfitrião */
    driftToleranceSec: number;
    /** mostra "Ajustando sincronia" quando a diferença passar de X s */
    driftNoticeSec: number;
    /** se o vídeo falhar: tenta os outros servidores da lista antes da API reserva */
    tryOtherServers: boolean;
    /** tempo máximo para o vídeo da sala carregar (ms) */
    loadTimeoutMs: number;
  };
  exo: {
    connectTimeoutMs: number; readTimeoutMs: number; userAgent: string; sendOrigin: boolean; headers: Record<string, string>;
    minBufferMs: number; maxBufferMs: number; bufferForPlaybackMs: number; bufferForPlaybackAfterRebufferMs: number;
  };
}

export const DEFAULT_PLAYER_CONFIG: PlayerConfig = {
  flow: { serversPath: "/api/servers", streamPath: "/api/stream", serverParam: "servidor", listServers: true, budgetMode: "all", priorityServer: "", autoTryMax: 3, slowAfterMs: 6000, giveUpMs: 90000 },
  proxy: {
    defaultMode: "default",
    paths: { default: "/api/proxy", vip: "/api/proxy/vip" },
    urlParam: "url", refererParam: "referer",
    defaultReferer: "https://v2.watchplay.shop/", useEmbedReferer: true,
    rules: [{ match: "vip", proxy: "vip" }],
  },
  fallback: { enabled: true, afterMs: 8000, giveUpMs: 60000 },
  rooms: { mainServer: "", heartbeatMs: 10000, pingWhenPaused: true, hostGraceMs: 8000, claimHostAfterMs: 15000, driftToleranceSec: 2.5, driftNoticeSec: 3, tryOtherServers: true, loadTimeoutMs: 45000 },
  exo: {
    connectTimeoutMs: 15000, readTimeoutMs: 25000,
    userAgent: "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36",
    sendOrigin: true, headers: {},
    minBufferMs: 50000, maxBufferMs: 50000, bufferForPlaybackMs: 2500, bufferForPlaybackAfterRebufferMs: 5000,
  },
};

// ---------- conferência dos campos ----------
const isObj = (v: unknown): v is Record<string, unknown> => !!v && typeof v === "object" && !Array.isArray(v);
const str = (v: unknown, d: string, max = 300) => (typeof v === "string" && v.length <= max && !/[\r\n]/.test(v) ? v.trim() : d);
const num = (v: unknown, d: number, min: number, max: number) => (typeof v === "number" && isFinite(v) ? Math.min(max, Math.max(min, Math.round(v))) : d);
const numF = (v: unknown, d: number, min: number, max: number) => (typeof v === "number" && isFinite(v) ? Math.min(max, Math.max(min, Math.round(v * 10) / 10)) : d);
const bool = (v: unknown, d: boolean) => (typeof v === "boolean" ? v : d);
const path = (v: unknown, d: string) => { const s = str(v, d, 120); return /^\/[^\s?#]*$/.test(s) ? s.replace(/\/+$/, "") || "/" : d; };
const param = (v: unknown, d: string) => { const s = str(v, d, 40); return /^[A-Za-z0-9_.-]+$/.test(s) ? s : d; };
const mode = (v: unknown, d: ProxyMode): ProxyMode => (v === "default" || v === "vip" || v === "none" ? v : d);
const httpUrl = (v: unknown, d: string) => { const s = str(v, d, 300); return /^https?:\/\/\S+$/i.test(s) ? s : d; };
const headers = (v: unknown): Record<string, string> => {
  const out: Record<string, string> = {};
  if (!isObj(v)) return out;
  for (const [k, val] of Object.entries(v).slice(0, 12)) {
    if (/^[A-Za-z0-9-]{1,40}$/.test(k) && typeof val === "string" && val.length <= 400 && !/[\r\n]/.test(val)) out[k] = val;
  }
  return out;
};

export function sanitizePlayerConfig(raw: unknown): PlayerConfig {
  const D = DEFAULT_PLAYER_CONFIG;
  const r = isObj(raw) ? raw : {};
  const f = isObj(r.flow) ? r.flow : {}, p = isObj(r.proxy) ? r.proxy : {}, fb = isObj(r.fallback) ? r.fallback : {}, e = isObj(r.exo) ? r.exo : {};
  const rm = isObj(r.rooms) ? r.rooms : {};
  const pp = isObj(p.paths) ? p.paths : {};
  const rules: PlayerRule[] = [];
  if (Array.isArray(p.rules)) {
    for (const x of p.rules.slice(0, 20)) {
      if (!isObj(x)) continue;
      const match = str(x.match, "", 60).toLowerCase();
      if (!match) continue;
      const rule: PlayerRule = { match, proxy: mode(x.proxy, D.proxy.defaultMode) };
      const ref = typeof x.referer === "string" && x.referer.trim() ? httpUrl(x.referer, "") : "";
      if (ref) rule.referer = ref;
      const h = headers(x.headers);
      if (Object.keys(h).length) rule.headers = h;
      rules.push(rule);
    }
  } else rules.push(...D.proxy.rules);
  return {
    flow: {
      serversPath: path(f.serversPath, D.flow.serversPath), streamPath: path(f.streamPath, D.flow.streamPath), serverParam: param(f.serverParam, D.flow.serverParam),
      listServers: bool(f.listServers, D.flow.listServers), budgetMode: f.budgetMode === "success" ? "success" : "all",
      priorityServer: str(f.priorityServer, D.flow.priorityServer, 60), autoTryMax: num(f.autoTryMax, D.flow.autoTryMax, 0, 8),
      slowAfterMs: num(f.slowAfterMs, D.flow.slowAfterMs, 1000, 60000), giveUpMs: num(f.giveUpMs, D.flow.giveUpMs, 10000, 180000),
    },
    proxy: {
      defaultMode: mode(p.defaultMode, D.proxy.defaultMode),
      paths: { default: path(pp.default, D.proxy.paths.default), vip: path(pp.vip, D.proxy.paths.vip) },
      urlParam: param(p.urlParam, D.proxy.urlParam), refererParam: param(p.refererParam, D.proxy.refererParam),
      defaultReferer: httpUrl(p.defaultReferer, D.proxy.defaultReferer), useEmbedReferer: bool(p.useEmbedReferer, D.proxy.useEmbedReferer),
      rules,
    },
    fallback: {
      enabled: bool(fb.enabled, D.fallback.enabled), afterMs: num(fb.afterMs, D.fallback.afterMs, 1000, 60000), giveUpMs: num(fb.giveUpMs, D.fallback.giveUpMs, 10000, 180000),
    },
    rooms: {
      mainServer: str(rm.mainServer, D.rooms.mainServer, 60), heartbeatMs: num(rm.heartbeatMs, D.rooms.heartbeatMs, 3000, 60000), pingWhenPaused: bool(rm.pingWhenPaused, D.rooms.pingWhenPaused),
      hostGraceMs: num(rm.hostGraceMs, D.rooms.hostGraceMs, 2000, 120000), claimHostAfterMs: num(rm.claimHostAfterMs, D.rooms.claimHostAfterMs, 5000, 300000),
      driftToleranceSec: numF(rm.driftToleranceSec, D.rooms.driftToleranceSec, 0.5, 15), driftNoticeSec: numF(rm.driftNoticeSec, D.rooms.driftNoticeSec, 0.5, 30),
      tryOtherServers: bool(rm.tryOtherServers, D.rooms.tryOtherServers), loadTimeoutMs: num(rm.loadTimeoutMs, D.rooms.loadTimeoutMs, 10000, 120000),
    },
    exo: {
      connectTimeoutMs: num(e.connectTimeoutMs, D.exo.connectTimeoutMs, 3000, 60000), readTimeoutMs: num(e.readTimeoutMs, D.exo.readTimeoutMs, 3000, 90000),
      userAgent: str(e.userAgent, D.exo.userAgent), sendOrigin: bool(e.sendOrigin, D.exo.sendOrigin), headers: headers(e.headers),
      minBufferMs: num(e.minBufferMs, D.exo.minBufferMs, 5000, 180000), maxBufferMs: num(e.maxBufferMs, D.exo.maxBufferMs, 5000, 300000),
      bufferForPlaybackMs: num(e.bufferForPlaybackMs, D.exo.bufferForPlaybackMs, 500, 30000),
      bufferForPlaybackAfterRebufferMs: num(e.bufferForPlaybackAfterRebufferMs, D.exo.bufferForPlaybackAfterRebufferMs, 500, 60000),
    },
  };
}

// ---------- cópia no aparelho + atualização em segundo plano ----------
const CACHE_KEY = "alx:player:v1";
const REFRESH_EVERY_MS = 5 * 60_000;

function readCache(): PlayerConfig {
  try { return sanitizePlayerConfig(JSON.parse(localStorage.getItem(CACHE_KEY) || "null")); } catch { return DEFAULT_PLAYER_CONFIG; }
}
let current: PlayerConfig = readCache();
let origin: { url: string; key: string } | null = null;
let lastFetch = 0;

/** Configuração atual do player (a salva no aparelho, ou o padrão). */
export const getPlayerConfig = (): PlayerConfig => current;

function fetchRemote(): Promise<void> {
  if (!origin) return Promise.resolve();
  const { url, key } = origin;
  lastFetch = Date.now();
  return fetch(`${url}/rest/v1/rpc/get_player_config`, {
    method: "POST",
    headers: { apikey: key, Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: "{}",
  })
    .then((r) => (r.ok ? r.json() : Promise.reject(new Error(String(r.status)))))
    .then((d: unknown) => {
      if (!isObj(d) || !Object.keys(d).length) return;   // sql ainda não instalado / vazio: segue com o que tem
      current = sanitizePlayerConfig(d);
      try { localStorage.setItem(CACHE_KEY, JSON.stringify(current)); } catch { /* sem espaço: segue sem cópia */ }
    })
    .catch(() => { lastFetch = 0; /* offline: usa a cópia salva */ });
}

/** Chamado ao abrir o app: com cópia salva abre na hora e atualiza em segundo plano; sem cópia espera até 6 s. */
export function initPlayerConfig(supabaseUrl: string, anonKey: string): Promise<void> {
  origin = { url: supabaseUrl, key: anonKey };
  const refresh = fetchRemote();
  if (localStorage.getItem(CACHE_KEY)) return Promise.resolve();
  return Promise.race([refresh, new Promise<void>((r) => setTimeout(r, 6000))]);
}

/** Chamado ao pedir um vídeo: se a cópia tem mais de 5 min, atualiza em segundo plano (vale para o próximo vídeo). */
export function refreshPlayerConfigSoon() {
  if (origin && Date.now() - lastFetch > REFRESH_EVERY_MS) void fetchRemote();
}

/** Apaga a cópia salva (aparelho bloqueado). */
export function clearPlayerConfig() {
  current = DEFAULT_PLAYER_CONFIG;
  try { localStorage.removeItem(CACHE_KEY); } catch { /* sem acesso */ }
}

// ---------- regras: qual proxy/Referer usar em cada servidor ----------
export interface NetOptions {
  connectTimeoutMs: number; readTimeoutMs: number; userAgent: string; sendOrigin: boolean;
  /** Referer/headers que o ExoPlayer deve mandar (só quando o link NÃO passa por proxy; o proxy já cuida disso) */
  referer: string; headers: Record<string, string>;
  minBufferMs: number; maxBufferMs: number; bufferForPlaybackMs: number; bufferForPlaybackAfterRebufferMs: number;
}

export function ruleFor(cfg: PlayerConfig, server: string): PlayerRule | null {
  const s = server.toLowerCase();
  return cfg.proxy.rules.find((r) => s.includes(r.match)) ?? null;
}

/** Monta o link final (proxy certo + Referer certo) e os ajustes de rede do ExoPlayer para este servidor. */
export function planForServer(cfg: PlayerConfig, serverLabel: string, m3u8: string, embed: string | undefined, mediaBase: string) {
  const rule = ruleFor(cfg, serverLabel);
  const modeUsed: ProxyMode = rule?.proxy ?? cfg.proxy.defaultMode;
  const referer = rule?.referer || (cfg.proxy.useEmbedReferer && embed ? embed : "") || cfg.proxy.defaultReferer;
  const { paths, urlParam, refererParam } = cfg.proxy;
  const url = modeUsed === "none"
    ? m3u8
    : `${mediaBase}${modeUsed === "vip" ? paths.vip : paths.default}?${urlParam}=${encodeURIComponent(m3u8)}&${refererParam}=${encodeURIComponent(referer)}`;
  const e = cfg.exo;
  const net: NetOptions = {
    connectTimeoutMs: e.connectTimeoutMs, readTimeoutMs: e.readTimeoutMs, userAgent: e.userAgent, sendOrigin: e.sendOrigin,
    referer: modeUsed === "none" ? referer : "",
    headers: { ...e.headers, ...(rule?.headers ?? {}) },
    minBufferMs: e.minBufferMs, maxBufferMs: Math.max(e.maxBufferMs, e.minBufferMs),
    bufferForPlaybackMs: e.bufferForPlaybackMs, bufferForPlaybackAfterRebufferMs: e.bufferForPlaybackAfterRebufferMs,
  };
  return { url, mode: modeUsed, referer, net };
}

/** Só os ajustes de rede (links que não têm servidor/Referer próprio, ex.: API reserva). */
export function defaultNet(cfg: PlayerConfig): NetOptions {
  const n = planForServer(cfg, "", "", undefined, "").net;
  return { ...n, referer: "" };
}

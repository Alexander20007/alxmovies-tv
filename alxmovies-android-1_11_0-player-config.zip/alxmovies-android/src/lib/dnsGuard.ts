import { registerPlugin } from "@capacitor/core";
import { isNative } from "./native";
import { supabase } from "./supabase";
import { CONFIG } from "./config";

/**
 * Anti-AdBlock: detecta DNS/aplicativos que bloqueiam anúncios (AdGuard, NextDNS…). O Android só coleta os fatos (AlxDnsGuard);
 * a decisão usa a lista configurada pelo admin em Admin → Anti-AdBlock.
 */
export interface DnsGuardConfig {
  enabled: boolean;
  mode: "warn" | "block";
  check_private_dns: boolean;
  check_ips: boolean;
  check_probe: boolean;
  probe_min: number;
  providers: string[];
  ips: string[];
  test_hosts: string[];
  message: string;
}

interface Facts {
  privateDnsMode?: string; privateDnsHost?: string; privateDnsActive?: boolean;
  dnsServers?: string[]; vpn?: boolean; controlOk?: boolean;
  probe?: { host: string; result: string }[];
}
interface AlxDnsGuardPlugin { inspect(o: { testHosts: string[]; controlHosts: string[] }): Promise<Facts> }
const Native = registerPlugin<AlxDnsGuardPlugin>("AlxDnsGuard");

export interface Verdict { blocked: boolean; reasons: string[] }

const CACHE_KEY = "alx:dnsGuard:v1";

export const DNS_GUARD_DEFAULT: DnsGuardConfig = {
  enabled: false, mode: "warn", check_private_dns: true, check_ips: true, check_probe: true, probe_min: 3,
  providers: ["adguard-dns.com", "adguard.com", "nextdns.io", "controld.com", "cleanbrowsing.org", "adblock.dns.mullvad.net", "ahadns.net", "noads.libredns.gr", "blahdns.com", "dnswarden.com"],
  ips: ["94.140.14.14", "94.140.15.15", "94.140.14.15", "94.140.15.16", "2a10:50c0::ad1:ff", "2a10:50c0::ad2:ff"],
  test_hosts: ["doubleclick.net", "pagead2.googlesyndication.com", "googleadservices.com", "adservice.google.com", "securepubads.g.doubleclick.net"],
  message: "O ALXmovies é gratuito graças aos anúncios. Detectamos um DNS ou aplicativo que bloqueia anúncios neste aparelho. Desative-o para continuar.",
};

const strs = (v: unknown): string[] => (Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : []);

function parse(raw: unknown): DnsGuardConfig | null {
  if (!raw || typeof raw !== "object") return null;
  const r = raw as Record<string, unknown>;
  return {
    enabled: r.enabled === true,
    mode: r.mode === "block" ? "block" : "warn",
    check_private_dns: r.check_private_dns !== false,
    check_ips: r.check_ips !== false,
    check_probe: r.check_probe !== false,
    probe_min: typeof r.probe_min === "number" && r.probe_min >= 1 ? Math.min(10, Math.floor(r.probe_min)) : 2,
    providers: strs(r.providers).map((s) => s.toLowerCase()),
    ips: strs(r.ips).map((s) => s.toLowerCase()),
    test_hosts: strs(r.test_hosts),
    message: typeof r.message === "string" && r.message.trim() ? r.message : DNS_GUARD_DEFAULT.message,
  };
}

/** Configuração do painel (guardada no aparelho para funcionar offline). O dono recebe sempre "desligado". */
export async function loadDnsGuardConfig(): Promise<DnsGuardConfig> {
  try {
    const { data, error } = await supabase.rpc("get_dns_guard");
    const cfg = !error ? parse(data) : null;
    if (cfg) { try { localStorage.setItem(CACHE_KEY, JSON.stringify(cfg)); } catch { /* sem espaço */ } return cfg; }
  } catch { /* offline */ }
  try { const c = parse(JSON.parse(localStorage.getItem(CACHE_KEY) || "null")); if (c) return c; } catch { /* sem cópia */ }
  return { ...DNS_GUARD_DEFAULT };
}

/** host == domínio ou subdomínio dele (nextdns.io casa com abc123.dns.nextdns.io, mas não com mynextdns.io). */
export const hostMatches = (host: string, domain: string) => { const h = host.toLowerCase().replace(/\.+$/, ""); return h === domain || h.endsWith("." + domain); };

function ipv4ToInt(ip: string): number | null {
  const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(ip);
  if (!m) return null;
  const p = m.slice(1).map(Number);
  if (p.some((x) => x > 255)) return null;
  return ((p[0] << 24) | (p[1] << 16) | (p[2] << 8) | p[3]) >>> 0;
}

/** IP igual ao da lista, ou dentro do intervalo (ex.: 94.140.14.0/24). */
export function ipMatches(ip: string, entry: string): boolean {
  const a = ip.toLowerCase().split("%")[0];
  const e = entry.toLowerCase();
  if (!e.includes("/")) return a === e;
  const [net, bitsS] = e.split("/");
  const bits = Number(bitsS), x = ipv4ToInt(a), y = ipv4ToInt(net);
  if (x === null || y === null || !(bits >= 0 && bits <= 32)) return false;
  const mask = bits === 0 ? 0 : (0xffffffff << (32 - bits)) >>> 0;
  return ((x & mask) >>> 0) === ((y & mask) >>> 0);
}

/** Confere num DNS público (DNS-sobre-HTTPS) se o domínio EXISTE de verdade. Domínio inexistente nunca prova bloqueador. */
export async function existsPublicly(host: string): Promise<boolean> {
  const q = encodeURIComponent(host);
  for (const u of [`https://dns.google/resolve?name=${q}&type=A`, `https://cloudflare-dns.com/dns-query?name=${q}&type=A`]) {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), 3500);
    try {
      const r = await fetch(u, { headers: { accept: "application/dns-json" }, signal: ctl.signal });
      if (!r.ok) continue;
      const d = (await r.json()) as { Status?: number; Answer?: { type?: number }[] };
      if (d.Status === 0 && Array.isArray(d.Answer) && d.Answer.some((x) => x.type === 1 || x.type === 5)) return true;   // tem endereço (A) ou aponta para outro nome (CNAME)
      if (d.Status === 3) return false;                                                                                  // NXDOMAIN: não existe
    } catch { /* tenta o próximo servidor */ } finally { clearTimeout(t); }
  }
  return false;   // sem resposta: não dá para provar nada
}

/** Regras do painel que só dependem do DNS configurado no aparelho: DNS privado e IPs dos servidores. */
export function judgeStatic(cfg: DnsGuardConfig, f: Facts): string[] {
  const reasons: string[] = [];
  if (cfg.check_private_dns) {
    const h = (f.privateDnsHost ?? "").trim();
    if (h && cfg.providers.some((d) => hostMatches(h, d))) reasons.push(`DNS privado do aparelho: ${h}`);
  }
  if (cfg.check_ips) {
    const hit = (f.dnsServers ?? []).find((ip) => cfg.ips.some((e) => ipMatches(ip, e)));
    if (hit) reasons.push(`Servidor de DNS da rede: ${hit.split("%")[0]}`);
  }
  return reasons;
}

/**
 * Teste de anúncios, SEM falso positivo: um domínio só conta como "bloqueado" se (1) o aparelho não conseguiu resolvê-lo
 * (NXDOMAIN ou 0.0.0.0) E (2) um DNS público confirma que ele existe. Sem internet, ou com domínio inexistente, não acusa ninguém.
 */
export async function judgeProbe(cfg: DnsGuardConfig, f: Facts): Promise<string[]> {
  if (!cfg.check_probe || f.controlOk === false) return [];
  const failed = (f.probe ?? []).filter((p) => p.result === "nxdomain" || p.result === "sinkhole").map((p) => p.host);
  if (!failed.length) return [];
  const exists = await Promise.all(failed.map((h) => existsPublicly(h)));
  const confirmed = failed.filter((_, i) => exists[i]);
  return confirmed.length >= Math.max(1, cfg.probe_min) ? [`Domínios de anúncios recusados pela sua rede: ${confirmed.join(", ")}`] : [];
}

/** Verifica este aparelho. Fora do app Android, ou se algo falhar, NÃO acusa ninguém. */
export async function checkDnsGuard(cfg: DnsGuardConfig): Promise<Verdict> {
  if (!isNative || !cfg.enabled) return { blocked: false, reasons: [] };
  try {
    const controls = ["www.google.com"];
    try { controls.unshift(new URL(CONFIG.SUPABASE_URL).hostname); } catch { /* sem domínio do Supabase */ }
    const facts = await Native.inspect({ testHosts: cfg.check_probe ? cfg.test_hosts : [], controlHosts: controls });
    const reasons = [...judgeStatic(cfg, facts), ...(await judgeProbe(cfg, facts))];
    return { blocked: reasons.length > 0, reasons };
  } catch { return { blocked: false, reasons: [] }; }
}

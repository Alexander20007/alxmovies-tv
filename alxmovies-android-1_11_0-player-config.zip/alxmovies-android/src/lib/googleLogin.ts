import { registerPlugin } from "@capacitor/core";
import { isNative } from "./native";
import { supabase } from "./supabase";

/**
 * Entrar com Google no app Android: o Android abre a janela de contas (Credential Manager), devolve um ID token do Google
 * e o Supabase troca esse token por uma sessão (signInWithIdToken). O ID do cliente Web vem do painel (Admin → APIs).
 */
interface AlxGoogleLoginPlugin {
  signIn(o: { serverClientId: string; nonce: string }): Promise<{ idToken?: string; email?: string; name?: string; cancelled?: boolean }>;
}
const Native = registerPlugin<AlxGoogleLoginPlugin>("AlxGoogleLogin");

export interface GoogleLoginConfig { enabled: boolean; webClientId: string }

/** O botão só aparece no app Android, com o login ligado e o ID do cliente Web preenchido no painel. */
export async function getGoogleLoginConfig(): Promise<GoogleLoginConfig> {
  if (!isNative) return { enabled: false, webClientId: "" };
  try {
    const { data, error } = await supabase.rpc("get_google_login");
    if (error || !data || typeof data !== "object") return { enabled: false, webClientId: "" };
    const d = data as { enabled?: boolean; web_client_id?: string };
    const id = typeof d.web_client_id === "string" ? d.web_client_id.trim() : "";
    return { enabled: d.enabled === true && id !== "", webClientId: id };
  } catch { return { enabled: false, webClientId: "" }; }
}

const toHex = (buf: ArrayBuffer) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");

/** Nonce de segurança: o Google recebe o hash; o Supabase recebe o valor original e confere. */
async function makeNonce(): Promise<{ raw: string; hashed: string }> {
  const raw = toHex(crypto.getRandomValues(new Uint8Array(32)).buffer);
  const hashed = toHex(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw)));
  return { raw, hashed };
}

/** Nome de usuário válido (3–24: letras, números, _ ou .) a partir do nome do Google ou do e-mail. */
function usernameFrom(name: string | undefined, email: string | undefined): string {
  const base = (name || email?.split("@")[0] || "usuario").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-zA-Z0-9_.]+/g, "").slice(0, 20);
  return (base.length >= 3 ? base : `usuario${base}`).slice(0, 24);
}

/** Abre o login do Google. Devolve "ok" se entrou, "cancelled" se a pessoa fechou a janela. Erros viram Error com mensagem em português. */
export async function signInWithGoogle(cfg: GoogleLoginConfig): Promise<"ok" | "cancelled"> {
  if (!isNative || !cfg.enabled) throw new Error("O login com Google não está disponível.");
  const { raw, hashed } = await makeNonce();
  let r: Awaited<ReturnType<AlxGoogleLoginPlugin["signIn"]>>;
  try { r = await Native.signIn({ serverClientId: cfg.webClientId, nonce: hashed }); }
  catch (e) { throw new Error(e instanceof Error && e.message ? e.message : "Não foi possível abrir o login com Google."); }
  if (r.cancelled) return "cancelled";
  if (!r.idToken) throw new Error("O Google não devolveu a identificação. Tente de novo.");
  const { data, error } = await supabase.auth.signInWithIdToken({ provider: "google", token: r.idToken, nonce: raw });
  if (error) throw new Error(/nonce/i.test(error.message) ? "O Google recusou a verificação de segurança. Tente de novo." : error.message);
  // conta nova: o Google não manda nome de usuário no formato do app, então criamos um a partir do nome (a pessoa pode trocar em Conta)
  try {
    const meta = (data.user?.user_metadata ?? {}) as { username?: string };
    if (!meta.username) await supabase.auth.updateUser({ data: { username: usernameFrom(r.name, r.email) } });
  } catch { /* sem nome de usuário por enquanto: o app funciona igual */ }
  return "ok";
}

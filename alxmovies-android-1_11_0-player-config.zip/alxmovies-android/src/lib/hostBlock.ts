import { registerPlugin } from "@capacitor/core";
import { isNative } from "./native";

/**
 * Bloqueio de DNS (domínios) controlado pelo admin: Admin → Bloqueios → Domínios.
 * Bloquear exemplo.com bloqueia também todos os subdomínios (cdn.exemplo.com…), como um DNS. IP só bloqueia o IP exato.
 * No app Android a lista também vai para o código nativo (WebView, player, salas, baixador); aqui no JavaScript
 * ela barra fetch e XMLHttpRequest. A lista fica guardada no aparelho e é atualizada ao abrir o app.
 */
interface AlxHostBlockPlugin { set(o: { hosts: string[] }): Promise<void> }
const Native = registerPlugin<AlxHostBlockPlugin>("AlxHostBlock");

const CACHE_KEY = "alx:blockedHosts:v1";
const IPV4 = /^\d{1,3}(\.\d{1,3}){3}$/;
const norm = (h: string) => h.trim().toLowerCase().replace(/\.+$/, "");

function readCache(): string[] {
  try {
    const a = JSON.parse(localStorage.getItem(CACHE_KEY) || "[]");
    return Array.isArray(a) ? a.filter((x): x is string => typeof x === "string") : [];
  } catch { return []; }
}

let blocked = new Set<string>(readCache().map(norm).filter(Boolean));

/** true se o domínio (ou um domínio "pai" dele) está bloqueado. */
export function isBlockedHost(host: string | null | undefined): boolean {
  if (!host || blocked.size === 0) return false;
  let h = norm(host);
  if (!h) return false;
  if (IPV4.test(h)) return blocked.has(h);
  for (;;) {
    if (blocked.has(h)) return true;
    const i = h.indexOf(".");
    if (i < 0) return false;
    h = h.slice(i + 1);
  }
}

export function isBlockedUrl(url: string): boolean {
  try { return isBlockedHost(new URL(url, window.location.href).hostname); } catch { return false; }
}

let guarded = false;
/** Faz fetch e XMLHttpRequest recusarem domínios bloqueados (como se o DNS não resolvesse). */
function installGuard() {
  if (guarded || typeof window === "undefined") return;
  guarded = true;
  const origFetch = window.fetch.bind(window);
  window.fetch = (input: RequestInfo | URL, init?: RequestInit) => {
    const url = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
    if (isBlockedUrl(url)) return Promise.reject(new TypeError("Failed to fetch"));
    return origFetch(input, init);
  };
  type Xhr = XMLHttpRequest & { __alxBlocked?: boolean };
  const origOpen = XMLHttpRequest.prototype.open;
  const origSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (this: Xhr, ...args: unknown[]) {
    this.__alxBlocked = isBlockedUrl(String(args[1]));
    return (origOpen as (...a: unknown[]) => void).apply(this, args);
  } as typeof XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.send = function (this: Xhr, body?: Document | XMLHttpRequestBodyInit | null) {
    if (this.__alxBlocked) {
      window.setTimeout(() => { this.dispatchEvent(new ProgressEvent("error")); this.dispatchEvent(new ProgressEvent("loadend")); }, 0);
      return;
    }
    return origSend.call(this, body);
  };
}

function apply(list: string[]) {
  blocked = new Set(list.map(norm).filter(Boolean));
  if (isNative) void Native.set({ hosts: [...blocked] }).catch(() => { /* app antigo, sem o plugin: segue só com o bloqueio do JavaScript */ });
}

/** Busca a lista atual no Supabase e aplica (JS + Android). Falha de rede = mantém a lista salva. */
export async function refreshHostBlock(supabaseUrl: string, anonKey: string): Promise<void> {
  try {
    const r = await fetch(`${supabaseUrl}/rest/v1/rpc/get_blocked_hosts`, {
      method: "POST",
      headers: { apikey: anonKey, Authorization: `Bearer ${anonKey}`, "Content-Type": "application/json" },
      body: "{}",
    });
    if (!r.ok) return;
    const d: unknown = await r.json();
    if (!Array.isArray(d)) return;
    const list = d.filter((x): x is string => typeof x === "string");
    try { localStorage.setItem(CACHE_KEY, JSON.stringify(list)); } catch { /* sem espaço: segue sem cópia */ }
    apply(list);
  } catch { /* offline: usa a lista salva */ }
}

/** Liga o bloqueio ao abrir o app: usa a lista salva na hora e atualiza em segundo plano (não atrasa a abertura). */
export function initHostBlock(supabaseUrl: string, anonKey: string) {
  installGuard();
  apply([...blocked]);
  void refreshHostBlock(supabaseUrl, anonKey);
}

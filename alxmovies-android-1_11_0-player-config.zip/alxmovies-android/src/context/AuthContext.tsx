import { unregisterPushToken } from "@/lib/pushToken";
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { useNavigate } from "react-router-dom";
import type { User } from "@supabase/supabase-js";
import { supabase } from "@/lib/supabase";
import { storage } from "@/lib/storage";
import { signInWithGoogle as googleSignIn, type GoogleLoginConfig } from "@/lib/googleLogin";

interface AuthValue {
  user: User | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, metadata?: Record<string, unknown>) => Promise<void>;
  /** Entrar com Google (só no app Android). Devolve false se a pessoa fechou a janela do Google. */
  signInWithGoogle: (cfg: GoogleLoginConfig) => Promise<boolean>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const navigate = useNavigate();
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setUser(data.session?.user ?? null);
      setLoading(false);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      setUser(session?.user ?? null);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  const signOut = useCallback(async () => {
    await unregisterPushToken(); // antes de perder o login
    storage.clearProfileId();
    storage.clearGuest();
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  }, []);

  // O acesso de convidado foi removido: quem ainda estiver com uma sessão de convidado é desconectado e vai para o login.
  useEffect(() => {
    if (!user?.is_anonymous) return;
    void signOut().catch(() => { /* sem internet: tenta de novo na próxima abertura */ }).finally(() => navigate("/login?guest=ended", { replace: true }));
  }, [user, signOut, navigate]);

  const value = useMemo<AuthValue>(
    () => ({
      user,
      loading,
      signIn: async (email, password) => {
        storage.clearGuest();
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      },
      signUp: async (email, password, metadata = {}) => {
        storage.clearGuest();
        const { error } = await supabase.auth.signUp({ email, password, options: { data: metadata } });
        if (error) throw error;
      },
      signInWithGoogle: async (cfg) => {
        storage.clearGuest();
        return (await googleSignIn(cfg)) === "ok";
      },
      signOut,
    }),
    [user, loading, signOut]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth deve ser usado dentro de <AuthProvider>");
  return ctx;
}

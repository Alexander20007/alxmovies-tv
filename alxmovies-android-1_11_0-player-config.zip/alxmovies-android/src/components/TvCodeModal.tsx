import { useCallback, useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { Icon } from "@/components/Icon";
import { useBackClose } from "@/hooks/useBackClose";
import { createTvLoginCode, type TvCode } from "@/services/tvLogin";

const fmtTime = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

/** "Entrar na Smart TV": mostra um código de 8 números (10 minutos, uso único) para digitar no app da TV. */
export function TvCodeModal({ onClose }: { onClose: () => void }) {
  const [tv, setTv] = useState<TvCode | null>(null);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(true);
  const [left, setLeft] = useState(0);
  const [copied, setCopied] = useState(false);
  useBackClose(true, onClose);

  const make = useCallback(async () => {
    setBusy(true); setErr(""); setCopied(false);
    try {
      const c = await createTvLoginCode();
      setTv(c);
      setLeft(Math.max(0, Math.round((c.expiresAt - Date.now()) / 1000)));
    } catch (e) {
      setTv(null);
      setErr(e instanceof Error && e.message ? e.message : "Não foi possível gerar o código.");
    } finally { setBusy(false); }
  }, []);

  useEffect(() => { void make(); }, [make]);
  useEffect(() => {
    if (!tv) return;
    const t = window.setInterval(() => setLeft(Math.max(0, Math.round((tv.expiresAt - Date.now()) / 1000))), 1000);
    return () => window.clearInterval(t);
  }, [tv]);

  const expired = !!tv && left <= 0;
  const spaced = tv ? `${tv.code.slice(0, 4)} ${tv.code.slice(4)}` : "";
  async function copy() {
    if (!tv) return;
    try { await navigator.clipboard.writeText(tv.code); setCopied(true); window.setTimeout(() => setCopied(false), 1800); } catch { /* sem permissão de copiar */ }
  }

  return createPortal(
    <div className="tvc-bg" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="tvc" role="dialog" aria-modal="true" aria-labelledby="tvc-title">
        <button type="button" className="tvc-x" aria-label="Fechar" onClick={onClose}><Icon name="close" size={20} /></button>
        <div className="tvc-ico" aria-hidden="true"><Icon name="tv" size={30} /></div>
        <h2 id="tvc-title">Entrar na Smart TV</h2>
        <p className="tvc-sub">Sem digitar e-mail nem senha na TV.</p>

        <ol className="tvc-steps">
          <li>Abra o <b>ALXmovies</b> na sua TV.</li>
          <li>Escolha <b>Entrar com código</b>.</li>
          <li>Digite o código abaixo.</li>
        </ol>

        {busy && <div className="tvc-code load" aria-busy="true">Gerando…</div>}
        {!busy && err && <p className="tvc-err">{err}</p>}
        {!busy && tv && (
          <>
            <div className={`tvc-code${expired ? " dead" : ""}`} aria-label={`Código ${tv.code.split("").join(" ")}`}>{spaced}</div>
            <div className="tvc-time">{expired ? "Código expirado" : `Expira em ${fmtTime(left)}`}</div>
            {!expired && <div className="tvc-bar" aria-hidden><i style={{ width: `${Math.min(100, (left / 600) * 100)}%` }} /></div>}
          </>
        )}

        <div className="tvc-btns">
          {tv && !expired && <button type="button" className="tvc-sec" onClick={() => void copy()}>{copied ? "Copiado ✓" : "Copiar código"}</button>}
          <button type="button" className="tvc-main" disabled={busy} onClick={() => void make()}>{tv && !expired ? "Gerar novo código" : "Gerar código"}</button>
        </div>
        <p className="tvc-warn">Não compartilhe este código: quem o digitar entra na sua conta. Ele vale uma vez só.</p>
      </div>
    </div>,
    document.body,
  );
}

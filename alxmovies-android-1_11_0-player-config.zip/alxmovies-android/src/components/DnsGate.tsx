import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { checkDnsGuard, loadDnsGuardConfig, type DnsGuardConfig, type Verdict } from "@/lib/dnsGuard";
import { isNative } from "@/lib/native";

const WARNED_KEY = "alx:dnsWarned";

/** Anti-AdBlock: avisa ou bloqueia quando o aparelho usa um DNS/app que bloqueia anúncios (configurado em Admin → Anti-AdBlock). */
export function DnsGate({ children }: { children: ReactNode }) {
  const [cfg, setCfg] = useState<DnsGuardConfig | null>(null);
  const [v, setV] = useState<Verdict>({ blocked: false, reasons: [] });
  const [busy, setBusy] = useState(false);
  const [dismissed, setDismissed] = useState(() => { try { return sessionStorage.getItem(WARNED_KEY) === "1"; } catch { return false; } });
  const last = useRef(0);

  const run = useCallback(async () => {
    if (!isNative) return;
    last.current = Date.now();
    const c = await loadDnsGuardConfig();
    setCfg(c);
    setV(c.enabled ? await checkDnsGuard(c) : { blocked: false, reasons: [] });
  }, []);

  useEffect(() => {
    void run();
    const onVis = () => { if (document.visibilityState === "visible" && Date.now() - last.current > 30_000) void run(); };
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, [run]);

  if (!cfg || !v.blocked) return <>{children}</>;
  if (cfg.mode === "warn" && dismissed) return <>{children}</>;

  const recheck = async () => { setBusy(true); await run(); setBusy(false); };
  const warn = cfg.mode === "warn";
  return (
    <>
      {warn ? children : null}
      <div className="dg-screen" role="alertdialog" aria-modal="true" aria-labelledby="dg-title">
        <div className="dg-box">
          <div className="dg-ico" aria-hidden="true">🛡️</div>
          <h1 id="dg-title">{warn ? "Bloqueador de anúncios detectado" : "Desative o bloqueador de anúncios"}</h1>
          <p>{cfg.message}</p>
          <ul className="dg-why">{v.reasons.map((r) => <li key={r}>{r}</li>)}</ul>
          <ol className="dg-steps">
            <li>Abra <b>Configurações → Rede e Internet → DNS privado</b> e escolha <b>Automático</b> ou <b>Desativado</b>.</li>
            <li>Se usa um app como AdGuard, NextDNS, Blokada ou uma VPN com bloqueio de anúncios, desative-o.</li>
            <li>Volte aqui e toque em <b>Verificar de novo</b>.</li>
          </ol>
          <button type="button" className="dg-main" disabled={busy} onClick={() => void recheck()}>{busy ? "Verificando…" : "Verificar de novo"}</button>
          {warn && <button type="button" className="dg-sec" onClick={() => { try { sessionStorage.setItem(WARNED_KEY, "1"); } catch { /* sem acesso */ } setDismissed(true); }}>Continuar mesmo assim</button>}
        </div>
      </div>
    </>
  );
}

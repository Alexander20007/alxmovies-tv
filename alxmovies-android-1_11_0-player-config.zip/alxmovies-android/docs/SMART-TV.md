# App da Smart TV — o que o banco, o site e o app do celular já oferecem

O app da TV **não tem e-mail nem senha**. A pessoa entra com um **código de 8 números** gerado no celular.

## Fluxo
1. **Celular (já logado):** foto de perfil → **Entrar na Smart TV** → aparece um código de 8 números (vale **10 minutos**, **uso único**).
2. **TV:** tela "Entrar com código" → a pessoa digita os 8 números.
3. O app da TV chama a função de borda `tv-login`, recebe uma **sessão** e passa a usar a conta normalmente.

## O que o app da TV precisa fazer (único ponto de integração)

`src/services/tvLogin.ts` já tem a função pronta, `signInWithTvCode(code)`:

```ts
import { signInWithTvCode } from "@/services/tvLogin";

try {
  await signInWithTvCode("1234 5678");   // aceita com ou sem espaço/traço
  // pronto: supabase.auth já tem a sessão (a mesma conta do celular)
} catch (e) {
  // e.message já vem em português: "Código inválido ou expirado…", "Muitas tentativas…"
}
```

Sem usar o arquivo acima, é só isto:

```
POST {SUPABASE_URL}/functions/v1/tv-login
Headers: apikey: {ANON_KEY}   Authorization: Bearer {ANON_KEY}   Content-Type: application/json
Body:    { "code": "12345678" }

200 → { "session": { "access_token": "...", "refresh_token": "...", ... } }   → supabase.auth.setSession(...)
400 → { "error": "Código inválido ou expirado. Gere um novo no celular." }
429 → { "error": "Muitas tentativas. Aguarde alguns minutos e tente de novo." }
```

Dicas para a tela da TV: campo numérico de 8 dígitos (o controle remoto tem teclado numérico), mostrar o erro devolvido, e depois de entrar ir direto para a escolha de perfil.

## Segurança (já feita no banco)
- Só o **hash** do código fica guardado; o código vale 10 minutos e é de uso único; gerar um novo invalida o anterior.
- Limite de tentativas: 10 erros por IP em 10 minutos (e 300 erros por minuto no total) → resposta 429.
- Só contas **com e-mail** podem gerar código (login por e-mail ou Google).
- O celular pode gerar no máximo 10 códigos por hora.

## Download do app da TV no site
O dono cola o link (GitHub) em **Admin → Resumo → App da Smart TV** (`sql/smart-tv.sql`). O site mostra a seção **Smart TV** com os passos, o botão **Baixar para Smart TV** e **Copiar link** (útil para digitar no app *Downloader* da TV). Sem link, mostra "em breve".

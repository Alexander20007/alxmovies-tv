-- ============================================================================
-- ALXmovies — BLOQUEIO DE DNS (DOMÍNIOS)
-- Rode DEPOIS de: admin-painel.sql e api-endpoints.sql. Pode rodar de novo sem problema.
--
-- O dono bloqueia domínios em Admin → 🚫 Bloqueios → "Domínios (DNS)". Bloquear exemplo.com bloqueia também todos os
-- subdomínios (cdn.exemplo.com, a.b.exemplo.com…), como um DNS de verdade. O app deixa de carregar imagens, vídeos, downloads e APIs desses
-- domínios (no Android: WebView, player, salas, baixador e verificador de canais).
-- Proteções: não deixa bloquear o Supabase, o site, nem o domínio de uma API de filmes/canais em uso.
-- ============================================================================
create table if not exists public.dns_blocks (
  id         bigint generated always as identity primary key,
  host       text not null unique,
  reason     text,
  created_at timestamptz not null default now(),
  created_by uuid default auth.uid()
);
alter table public.dns_blocks enable row level security;   -- sem policies: só as funções abaixo mexem

-- "https://CDN.Exemplo.com:443/a?b" -> "cdn.exemplo.com"
create or replace function public._norm_host(p text) returns text language plpgsql immutable as $$
declare v text := lower(btrim(coalesce(p, '')));
begin
  v := regexp_replace(v, '^[a-z][a-z0-9+.-]*://', '');
  v := regexp_replace(v, '[/?#].*$', '');
  v := regexp_replace(v, '^[^@]*@', '');
  v := regexp_replace(v, ':[0-9]+$', '');
  v := regexp_replace(v, '^\*\.', '');
  v := regexp_replace(v, '\.+$', '');
  return v;
end $$;

-- O app lê a lista (qualquer pessoa, mesmo sem login).
create or replace function public.get_blocked_hosts() returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(host order by host), '[]'::jsonb) from public.dns_blocks;
$$;

create or replace function public.admin_dns_blocks()
returns table (id bigint, host text, reason text, created_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  perform public._require_owner();
  return query select b.id, b.host, b.reason, b.created_at from public.dns_blocks b order by b.created_at desc;
end $$;

create or replace function public.admin_add_dns_block(p_host text, p_reason text default null)
returns void language plpgsql security definer set search_path = public as $$
declare
  h text := public._norm_host(p_host);
  prot text[] := array['supabase.co', 'supabase.com', 'onqxflwfkexitipylixc.supabase.co', 'alxmovies.netlify.app'];
  r record;
begin
  perform public._require_owner();
  if h = '' or length(h) > 253 then raise exception 'Digite um domínio. Exemplo: anuncios.exemplo.com'; end if;
  if h !~ '^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$' then
    raise exception 'Domínio inválido. Use só letras, números, hífen e pontos (ex.: exemplo.com). Nomes com acento: use a forma xn--…';
  end if;
  if exists (select 1 from unnest(prot) x where x = h or x like '%.' || h) then
    raise exception 'Este domínio é essencial para o app funcionar (Supabase ou o site) e não pode ser bloqueado.';
  end if;
  select e.label into r from public.api_endpoints e
   where regexp_replace(e.url, '^https?://([^/:]+).*$', '\1') = h or regexp_replace(e.url, '^https?://([^/:]+).*$', '\1') like '%.' || h limit 1;
  if found then raise exception 'Este domínio é usado pela API "%". Troque a API em Admin → APIs antes de bloquear.', r.label; end if;
  insert into public.dns_blocks (host, reason) values (h, nullif(btrim(coalesce(p_reason, '')), ''))
    on conflict (host) do update set reason = excluded.reason;
  perform public._audit('dns_add', null, jsonb_build_object('host', h));
end $$;

create or replace function public.admin_remove_dns_block(p_id bigint)
returns void language plpgsql security definer set search_path = public as $$
declare r record;
begin
  perform public._require_owner();
  delete from public.dns_blocks where id = p_id returning host into r;
  if found then perform public._audit('dns_remove', null, jsonb_build_object('host', r.host)); end if;
end $$;

-- Trocar uma API para um domínio que está bloqueado travaria filmes/canais: recusa.
create or replace function public.admin_set_api_endpoint(p_key text, p_url text)
returns void language plpgsql security definer set search_path = public as $$
declare v text := regexp_replace(btrim(coalesce(p_url, '')), '/+$', ''); hh text;
begin
  perform public._require_owner();
  if not exists (select 1 from public.api_endpoints where key = p_key) then raise exception 'API desconhecida.'; end if;
  if v !~ '^https://[^\s]+$' or length(v) > 300 then raise exception 'O endereço precisa começar com https:// e não ter espaços.'; end if;
  hh := regexp_replace(v, '^https://([^/:]+).*$', '\1');
  if exists (select 1 from public.dns_blocks b where hh = b.host or hh like '%.' || b.host) then
    raise exception 'Esse endereço está em um domínio bloqueado (Admin → Bloqueios → Domínios). Desbloqueie antes de usar.';
  end if;
  update public.api_endpoints set url = v, updated_at = now() where key = p_key;
  perform public._audit('api_editada', null, jsonb_build_object('api', p_key));
end $$;

revoke execute on function public.admin_dns_blocks(), public.admin_add_dns_block(text, text), public.admin_remove_dns_block(bigint),
  public.admin_set_api_endpoint(text, text) from public, anon;
grant  execute on function public.admin_dns_blocks(), public.admin_add_dns_block(text, text), public.admin_remove_dns_block(bigint),
  public.admin_set_api_endpoint(text, text) to authenticated;
grant  execute on function public.get_blocked_hosts() to anon, authenticated;

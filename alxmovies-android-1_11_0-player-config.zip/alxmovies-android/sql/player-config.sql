-- ============================================================================
-- ALXmovies — CONFIGURAÇÃO REMOTA DO PLAYER (guardada no Supabase)
-- Rode DEPOIS de: admin-painel.sql e api-endpoints.sql. Pode rodar de novo sem problema (não sobrescreve o que já está salvo).
--
-- O que é: como o player busca os servidores, qual proxy usa em cada servidor, qual Referer manda, e os ajustes do
-- ExoPlayer (tempos, User-Agent, buffer, headers). O app lê isto ao abrir (e a cada ~5 min ao assistir) e guarda uma cópia
-- no aparelho. O dono edita em Admin → "🎛 Player". Mudou o player? Troque aqui — ninguém precisa atualizar o app.
-- (Os ENDEREÇOS das APIs continuam em Admin → 🔌 APIs.)
-- ============================================================================
create table if not exists public.player_config (
  id         int primary key default 1 check (id = 1),   -- uma única linha
  config     jsonb not null,
  version    int not null default 1,
  updated_at timestamptz not null default now()
);
alter table public.player_config enable row level security;   -- sem policies: só as funções abaixo mexem

-- Configuração inicial = o fluxo novo do HTML de teste (lista /api/servers → /api/stream?servidor= → proxy; VIP no /api/proxy/vip)
insert into public.player_config (id, config) values (1, $json$
{
  "v": 1,
  "flow": {
    "serversPath": "/api/servers",
    "streamPath": "/api/stream",
    "serverParam": "servidor",
    "listServers": true,
    "budgetMode": "all",
    "priorityServer": "",
    "autoTryMax": 3,
    "slowAfterMs": 6000,
    "giveUpMs": 90000
  },
  "proxy": {
    "defaultMode": "default",
    "paths": { "default": "/api/proxy", "vip": "/api/proxy/vip" },
    "urlParam": "url",
    "refererParam": "referer",
    "defaultReferer": "https://v2.watchplay.shop/",
    "useEmbedReferer": true,
    "rules": [ { "match": "vip", "proxy": "vip" } ]
  },
  "fallback": { "enabled": true, "afterMs": 8000, "giveUpMs": 60000 },
  "rooms": { "mainServer": "", "heartbeatMs": 10000, "pingWhenPaused": true, "hostGraceMs": 8000, "claimHostAfterMs": 15000, "driftToleranceSec": 2.5, "driftNoticeSec": 3, "tryOtherServers": true, "loadTimeoutMs": 45000 },
  "exo": {
    "connectTimeoutMs": 15000,
    "readTimeoutMs": 25000,
    "userAgent": "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36",
    "sendOrigin": true,
    "headers": {},
    "minBufferMs": 50000,
    "maxBufferMs": 50000,
    "bufferForPlaybackMs": 2500,
    "bufferForPlaybackAfterRebufferMs": 5000
  }
}
$json$::jsonb)
on conflict (id) do nothing;

-- Quem já tinha rodado a versão anterior: acrescenta só o bloco "rooms" (não mexe no resto)
update public.player_config
   set config = config || jsonb_build_object('rooms', '{"heartbeatMs":10000,"pingWhenPaused":true,"hostGraceMs":8000,"claimHostAfterMs":15000,"driftToleranceSec":2.5,"driftNoticeSec":3,"tryOtherServers":true,"loadTimeoutMs":45000}'::jsonb)
 where id = 1 and not (config ? 'rooms');

-- O app lê (qualquer pessoa, mesmo sem login).
create or replace function public.get_player_config()
returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce(config, '{}'::jsonb) || jsonb_build_object('rev', version) from public.player_config where id = 1;
$$;

-- O painel lê (só o dono).
create or replace function public.admin_player_config()
returns table (config jsonb, version int, updated_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  perform public._require_owner();
  return query select c.config, c.version, c.updated_at from public.player_config c where c.id = 1;
end $$;

-- O painel salva (só o dono). O app ainda confere cada campo e ignora o que for inválido.
create or replace function public.admin_set_player_config(p_config jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public._require_owner();
  if p_config is null or jsonb_typeof(p_config) <> 'object' then raise exception 'A configuração precisa ser um objeto JSON.'; end if;
  if length(p_config::text) > 20000 then raise exception 'Configuração grande demais.'; end if;
  insert into public.player_config (id, config, version, updated_at) values (1, p_config, 1, now())
  on conflict (id) do update set config = excluded.config, version = public.player_config.version + 1, updated_at = now();
  perform public._audit('player_editado', null, jsonb_build_object('rev', (select version from public.player_config where id = 1)));
end $$;

revoke execute on function public.admin_player_config()               from public, anon;
revoke execute on function public.admin_set_player_config(jsonb)      from public, anon;
grant  execute on function public.get_player_config()                 to anon, authenticated;
grant  execute on function public.admin_player_config()               to authenticated;
grant  execute on function public.admin_set_player_config(jsonb)      to authenticated;

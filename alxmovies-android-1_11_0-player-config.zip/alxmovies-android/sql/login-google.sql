-- ============================================================================
-- ALXmovies — LOGIN COM GOOGLE (configuração no painel)
-- Rode DEPOIS de: admin-painel.sql e site-downloads.sql (usa a tabela site_settings). Pode rodar de novo sem problema.
--
-- Guarda o "ID do cliente Web" do Google (o mesmo que você colocou no Supabase) e se o botão "Entrar com Google" está ligado.
-- O ID do cliente não é secreto: o app precisa dele para abrir a janela de contas do Google. O dono edita em Admin → 🔌 APIs.
-- ============================================================================
create or replace function public.get_google_login() returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare cfg jsonb;
begin
  cfg := coalesce((select nullif(value, '')::jsonb from public.site_settings where key = 'google_login'), '{}'::jsonb);
  return jsonb_build_object('enabled', coalesce((cfg->>'enabled')::boolean, false), 'web_client_id', coalesce(cfg->>'web_client_id', ''));
end $$;

create or replace function public.admin_google_login() returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  perform public._require_owner();
  return public.get_google_login();
end $$;

create or replace function public.admin_set_google_login(p_enabled boolean, p_web_client_id text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v text := btrim(coalesce(p_web_client_id, ''));
begin
  perform public._require_owner();
  if v <> '' and v !~ '^[0-9]{6,}-[a-z0-9_-]+\.apps\.googleusercontent\.com$' then
    raise exception 'ID de cliente inválido. Ele termina com .apps.googleusercontent.com (use o cliente do tipo "Aplicativo da Web").';
  end if;
  if coalesce(p_enabled, false) and v = '' then raise exception 'Cole o ID do cliente Web antes de ligar o login com Google.'; end if;
  insert into public.site_settings (key, value, updated_at)
    values ('google_login', jsonb_build_object('enabled', coalesce(p_enabled, false), 'web_client_id', v)::text, now())
    on conflict (key) do update set value = excluded.value, updated_at = now();
  perform public._audit('google_login_edit', null, jsonb_build_object('ligado', coalesce(p_enabled, false)));
  return public.get_google_login();
end $$;

revoke execute on function public.admin_google_login(), public.admin_set_google_login(boolean, text) from public, anon;
grant  execute on function public.admin_google_login(), public.admin_set_google_login(boolean, text) to authenticated;
grant  execute on function public.get_google_login() to anon, authenticated;

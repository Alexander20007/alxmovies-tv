-- ============================================================================
-- ALXmovies — APP DA SMART TV (link de download + código de login)
-- Rode DEPOIS de: admin-painel.sql e site-downloads.sql (usa site_settings). Pode rodar de novo sem problema.
--
-- 1) LINK DO APP DA TV: o dono cola o link de download (GitHub) em Admin → Resumo → "App da Smart TV". O site mostra o botão para todos.
-- 2) CÓDIGO DE LOGIN: o app do celular (logado) gera um código de 8 números (válido por 10 min, uso único) em "foto de perfil → Entrar na Smart TV".
--    O app da TV não tem campo de e-mail/senha: a pessoa digita o código e a função de borda "tv-login" troca o código por uma sessão.
-- ============================================================================

-- ---------- 1) link do app da TV ----------
create or replace function public.get_tv_app() returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare cfg jsonb;
begin
  cfg := coalesce((select nullif(value, '')::jsonb from public.site_settings where key = 'tv_app'), '{}'::jsonb);
  return jsonb_build_object('url', coalesce(cfg->>'url', ''), 'version', coalesce(cfg->>'version', ''), 'note', coalesce(cfg->>'note', ''));
end $$;

create or replace function public.admin_tv_app() returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  perform public._require_owner();
  return public.get_tv_app();
end $$;

create or replace function public.admin_set_tv_app(p_url text, p_version text default '', p_note text default '') returns jsonb
language plpgsql security definer set search_path = public as $$
declare u text := btrim(coalesce(p_url, '')); v text := left(btrim(coalesce(p_version, '')), 30); n text := left(btrim(coalesce(p_note, '')), 200);
begin
  perform public._require_owner();
  if u <> '' and (u !~ '^https://[^\s]+$' or length(u) > 400) then
    raise exception 'O link precisa começar com https:// e não ter espaços. Exemplo: https://github.com/SEU-USUARIO/SEU-REPO/releases/latest/download/ALXmovies-TV.apk';
  end if;
  insert into public.site_settings (key, value, updated_at)
    values ('tv_app', jsonb_build_object('url', u, 'version', v, 'note', n)::text, now())
    on conflict (key) do update set value = excluded.value, updated_at = now();
  perform public._audit('tv_app_edit', null, jsonb_build_object('tem_link', u <> ''));
  return public.get_tv_app();
end $$;

-- ---------- 2) código de login da TV ----------
create table if not exists public.tv_login_codes (
  id         bigint generated always as identity primary key,
  user_id    uuid not null references auth.users(id) on delete cascade,
  code_hash  text not null unique,           -- só o hash do código é guardado
  created_at timestamptz not null default now(),
  expires_at timestamptz not null,
  used_at    timestamptz
);
create index if not exists tv_login_codes_user_idx on public.tv_login_codes (user_id, created_at desc);
alter table public.tv_login_codes enable row level security;   -- sem policies: só as funções abaixo mexem

create table if not exists public.tv_login_attempts (
  id bigint generated always as identity primary key,
  ip text not null,
  at  timestamptz not null default now()
);
create index if not exists tv_login_attempts_ip_idx on public.tv_login_attempts (ip, at);
alter table public.tv_login_attempts enable row level security;

-- O celular (logado) pede um código novo. Os códigos anteriores ainda não usados deixam de valer.
create or replace function public.create_tv_login_code() returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); code text; h text; recent int; tries int := 0; v_exp timestamptz := now() + interval '10 minutes';
begin
  if uid is null then raise exception 'Entre na sua conta primeiro.'; end if;
  if coalesce((auth.jwt()->>'is_anonymous')::boolean, false) then raise exception 'Este recurso precisa de uma conta com e-mail.'; end if;
  if not exists (select 1 from auth.users u where u.id = uid and coalesce(u.email, '') <> '') then raise exception 'Este recurso precisa de uma conta com e-mail.'; end if;

  delete from public.tv_login_codes where expires_at < now() - interval '1 day';
  select count(*) into recent from public.tv_login_codes where user_id = uid and created_at > now() - interval '1 hour';
  if recent >= 10 then raise exception 'Você gerou muitos códigos. Aguarde alguns minutos e tente de novo.'; end if;
  update public.tv_login_codes set used_at = now() where user_id = uid and used_at is null;

  loop
    -- 8 dígitos sorteados com gerador seguro (gen_random_uuid): só os dígitos do uuid, que saem uniformes de 0 a 9
    code := left(regexp_replace(gen_random_uuid()::text || gen_random_uuid()::text, '[^0-9]', '', 'g'), 8);
    continue when length(code) < 8;
    h := encode(sha256(convert_to(code, 'utf8')), 'hex');
    begin
      insert into public.tv_login_codes (user_id, code_hash, expires_at) values (uid, h, v_exp);
      exit;
    exception when unique_violation then
      tries := tries + 1;
      if tries > 5 then raise exception 'Não foi possível gerar o código. Tente de novo.'; end if;
    end;
  end loop;
  return jsonb_build_object('code', code, 'expires_at', v_exp);
end $$;

-- Só a função de borda "tv-login" (service role) chama isto. Confere o código, gasta (uso único) e devolve o dono dele.
-- Limite contra adivinhação: 10 erros por IP em 10 minutos e 300 erros no total por minuto.
create or replace function public.tv_login_redeem(p_code text, p_ip text) returns uuid
language plpgsql security definer set search_path = public as $$
declare h text; uid uuid; v_ip text := left(coalesce(nullif(btrim(p_ip), ''), '?'), 64); fails int; fails_all int;
begin
  delete from public.tv_login_attempts where at < now() - interval '1 day';
  select count(*) into fails from public.tv_login_attempts a where a.ip = v_ip and a.at > now() - interval '10 minutes';
  select count(*) into fails_all from public.tv_login_attempts a where a.at > now() - interval '1 minute';
  if fails >= 10 or fails_all >= 300 then raise exception 'rate_limited'; end if;
  h := encode(sha256(convert_to(regexp_replace(coalesce(p_code, ''), '\D', '', 'g'), 'utf8')), 'hex');
  update public.tv_login_codes c set used_at = now() where c.code_hash = h and c.used_at is null and c.expires_at > now() returning c.user_id into uid;
  if uid is null then
    insert into public.tv_login_attempts (ip) values (v_ip);
    return null;
  end if;
  return uid;
end $$;

revoke execute on function public.admin_tv_app(), public.admin_set_tv_app(text, text, text), public.create_tv_login_code(), public.tv_login_redeem(text, text) from public, anon;
revoke execute on function public.tv_login_redeem(text, text) from authenticated;
grant  execute on function public.admin_tv_app(), public.admin_set_tv_app(text, text, text), public.create_tv_login_code() to authenticated;
grant  execute on function public.tv_login_redeem(text, text) to service_role;
grant  execute on function public.get_tv_app() to anon, authenticated;

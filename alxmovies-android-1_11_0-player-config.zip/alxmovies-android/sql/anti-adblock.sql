-- ============================================================================
-- ALXmovies — ANTI-ADBLOCK (DNS que bloqueia anúncios: AdGuard, NextDNS…)
-- Rode DEPOIS de: admin-painel.sql e site-downloads.sql (usa a tabela site_settings). Pode rodar de novo sem problema.
--
-- O app Android olha o DNS do aparelho (DNS privado, servidores de DNS e um teste de resolução de domínios de anúncios) e, se achar
-- um bloqueador de anúncios, AVISA ou BLOQUEIA o uso. Tudo é configurado em Admin → 🛡 Anti-AdBlock.
-- Já vem DESLIGADO: o dono liga no painel quando quiser. O dono nunca é afetado.
-- ============================================================================
create or replace function public._dns_guard_default() returns jsonb language sql immutable as $$
  select '{
    "enabled": false, "mode": "warn",
    "check_private_dns": true, "check_ips": true, "check_probe": true, "probe_min": 3,
    "providers": ["adguard-dns.com","adguard.com","nextdns.io","controld.com","cleanbrowsing.org","adblock.dns.mullvad.net","ahadns.net","noads.libredns.gr","blahdns.com","dnswarden.com"],
    "ips": ["94.140.14.14","94.140.15.15","94.140.14.15","94.140.15.16","2a10:50c0::ad1:ff","2a10:50c0::ad2:ff"],
    "test_hosts": ["doubleclick.net","pagead2.googlesyndication.com","googleadservices.com","adservice.google.com","securepubads.g.doubleclick.net"],
    "message": "O ALXmovies é gratuito graças aos anúncios. Detectamos um DNS ou aplicativo que bloqueia anúncios neste aparelho. Desative-o para continuar."
  }'::jsonb;
$$;

-- Valida e limpa uma lista de domínios ('domain') ou de IPs/intervalos ('ip').
create or replace function public._clean_list(p jsonb, p_kind text) returns text[] language plpgsql immutable as $$
declare e text; n text; res text[] := '{}'; parts text[]; k int;
begin
  if p is null or jsonb_typeof(p) <> 'array' then return '{}'; end if;
  if jsonb_array_length(p) > 100 then raise exception 'Lista grande demais (máximo 100 itens).'; end if;
  for e in select jsonb_array_elements_text(p) loop
    if p_kind = 'domain' then
      n := public._norm_host(e);
      if n = '' then continue; end if;
      if n !~ '^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$' then raise exception 'Domínio inválido: %', e; end if;
    else
      n := lower(btrim(e));
      if n = '' then continue; end if;
      if n ~ '^\d{1,3}(\.\d{1,3}){3}(/\d{1,2})?$' then
        parts := regexp_split_to_array(split_part(n, '/', 1), '\.');
        foreach k in array array[parts[1]::int, parts[2]::int, parts[3]::int, parts[4]::int] loop
          if k > 255 then raise exception 'IP inválido: %', e; end if;
        end loop;
        if position('/' in n) > 0 and split_part(n, '/', 2)::int > 32 then raise exception 'IP inválido: %', e; end if;
      elsif n ~ '^[0-9a-f:]{2,45}$' and position(':' in n) > 0 then
        null;
      else
        raise exception 'IP inválido: %', e;
      end if;
    end if;
    if not (n = any(res)) then res := res || n; end if;
  end loop;
  return res;
end $$;

-- O app lê a configuração. O dono é isento (enabled sempre false para ele).
create or replace function public.get_dns_guard() returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare cfg jsonb;
begin
  cfg := public._dns_guard_default() || coalesce((select nullif(value, '')::jsonb from public.site_settings where key = 'dns_guard'), '{}'::jsonb);
  if public.is_app_admin() then cfg := jsonb_set(cfg, '{enabled}', 'false'::jsonb); end if;
  return cfg;
end $$;

-- O painel lê a configuração real (só o dono).
create or replace function public.admin_dns_guard() returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  perform public._require_owner();
  return public._dns_guard_default() || coalesce((select nullif(value, '')::jsonb from public.site_settings where key = 'dns_guard'), '{}'::jsonb);
end $$;

-- O painel salva a configuração (só o dono). Valida tudo.
create or replace function public.admin_set_dns_guard(p_cfg jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare c jsonb; m text; pm int; res jsonb;
begin
  perform public._require_owner();
  c := public._dns_guard_default() || coalesce(p_cfg, '{}'::jsonb);
  m := c->>'mode';
  if m is null or m not in ('warn', 'block') then raise exception 'Modo inválido.'; end if;
  begin pm := (c->>'probe_min')::int; exception when others then raise exception 'Mínimo de domínios de teste inválido.'; end;
  if pm < 1 or pm > 10 then raise exception 'O mínimo de domínios de teste deve ficar entre 1 e 10.'; end if;
  res := jsonb_build_object(
    'enabled', coalesce((c->>'enabled')::boolean, false),
    'mode', m,
    'check_private_dns', coalesce((c->>'check_private_dns')::boolean, true),
    'check_ips', coalesce((c->>'check_ips')::boolean, true),
    'check_probe', coalesce((c->>'check_probe')::boolean, true),
    'probe_min', pm,
    'providers', to_jsonb(public._clean_list(c->'providers', 'domain')),
    'ips', to_jsonb(public._clean_list(c->'ips', 'ip')),
    'test_hosts', to_jsonb(public._clean_list(c->'test_hosts', 'domain')),
    'message', left(btrim(coalesce(c->>'message', '')), 400)
  );
  insert into public.site_settings (key, value, updated_at) values ('dns_guard', res::text, now())
    on conflict (key) do update set value = excluded.value, updated_at = now();
  perform public._audit('dns_guard_edit', null, jsonb_build_object('ligado', res->'enabled', 'modo', m));
  return res;
end $$;

revoke execute on function public.admin_dns_guard(), public.admin_set_dns_guard(jsonb) from public, anon;
grant  execute on function public.admin_dns_guard(), public.admin_set_dns_guard(jsonb) to authenticated;
grant  execute on function public.get_dns_guard() to anon, authenticated;

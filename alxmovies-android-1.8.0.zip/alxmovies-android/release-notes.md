## Novo
- Salas: se você já baixou o filme ou episódio, a sala toca o arquivo do seu celular e não gasta internet com o vídeo (play, pause e posição continuam sincronizados com a sala)
- Downloads: botão de configurações (Wi-Fi, velocidade, qualidade e uso nas salas)
- Downloads: botão "Sala" para criar uma sala já com o vídeo baixado
- Lista de salas: selo "Baixado" e atalho com os seus downloads ao criar uma sala
## Melhorado
- Tela de Downloads redesenhada: resumo de armazenamento, abas Baixando e Prontos, cartões novos

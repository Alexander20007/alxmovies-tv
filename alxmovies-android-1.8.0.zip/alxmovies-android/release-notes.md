## Novo
- Mensagens: nova conversa oficial "ALXmovies ✔" com avisos e novidades enviados pela equipe
- Salas: se você já baixou o filme ou episódio, a sala toca o arquivo do seu celular e não gasta internet com o vídeo
- Downloads: botão de configurações (Wi-Fi, velocidade, qualidade e uso nas salas)
- Downloads: botão "Sala" para criar uma sala já com o vídeo baixado
- Lista de salas: selo "Baixado" e atalho com os seus downloads ao criar uma sala
## Melhorado
- Tela de Downloads redesenhada: resumo de armazenamento, abas Baixando e Prontos, cartões novos
- Sala mais limpa: só vídeo, chat e controles; o resto ficou em Definições
- O app informa a versão e o aparelho para a equipe poder avisar sobre atualizações (nada do que você assiste ou conversa é enviado)

import { supabase } from "@/lib/supabase";

export interface OfficialMessage {
  id: number; title: string; body: string; url: string | null; kind: "aviso" | "atualizacao" | "plano" | "suporte";
  created_at: string; read_at: string | null;
}

/** Mensagens oficiais do ALXmovies para esta conta (pedem o sql/admin-painel.sql no Supabase). */
export async function fetchOfficialMessages(): Promise<OfficialMessage[]> {
  const { data, error } = await supabase.rpc("my_admin_messages", { p_limit: 60 });
  if (error) throw error;
  return (data ?? []) as OfficialMessage[];
}
export async function officialUnread(): Promise<number> {
  const { data, error } = await supabase.rpc("my_admin_unread");
  if (error) return 0;
  return Number(data) || 0;
}
export async function markOfficialRead(): Promise<void> {
  await supabase.rpc("mark_admin_messages_read");
}

import { useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import { reportAppInfo } from "@/lib/appInfo";

/** Não renderiza nada: manda a versão do app para o servidor quando abre o app e quando volta do segundo plano. */
export function AppInfoReporter() {
  const { user } = useAuth();
  const uid = user?.id;
  useEffect(() => {
    if (!uid) return;
    void reportAppInfo(uid);
    const onVis = () => { if (document.visibilityState === "visible") void reportAppInfo(uid); };
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, [uid]);
  return null;
}

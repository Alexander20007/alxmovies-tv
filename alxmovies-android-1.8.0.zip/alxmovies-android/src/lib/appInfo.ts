import { App } from "@capacitor/app";
import { isNative } from "./native";
import { supabase } from "./supabase";

const KEY = "alx.appinfo";
const EVERY_MS = 6 * 3600_000;

/** Lê "Android 13" e o modelo do aparelho do texto que o próprio sistema já informa ao navegador. Nada pessoal. */
function readDevice() {
  const ua = navigator.userAgent || "";
  const m = /Android\s([\d.]+);\s*([^;)]+)/i.exec(ua);
  const model = m?.[2]?.replace(/\sBuild\/.*/i, "").trim();
  return { os: m ? `Android ${m[1]}` : "Android", model: model && model.length > 1 ? model : null };
}

/**
 * Avisa o servidor da versão do app em uso (no máximo uma vez a cada 6 horas, ou quando a conta/versão muda).
 * Só vão 4 dados: versão, sistema, modelo do aparelho e plataforma. O que a pessoa assiste e as conversas NUNCA são enviados.
 */
export async function reportAppInfo(userId: string): Promise<void> {
  if (!isNative) return;
  try {
    const { version } = await App.getInfo();
    let last: { uid?: string; v?: string; at?: number } = {};
    try { last = JSON.parse(localStorage.getItem(KEY) || "{}"); } catch { /* ignora */ }
    if (last.uid === userId && last.v === version && Date.now() - (last.at ?? 0) < EVERY_MS) return;
    const d = readDevice();
    const { error } = await supabase.rpc("report_app_info", { p_version: version, p_platform: "android", p_os: d.os, p_model: d.model });
    if (!error) localStorage.setItem(KEY, JSON.stringify({ uid: userId, v: version, at: Date.now() }));
  } catch { /* melhor esforço: o SQL pode ainda não ter sido instalado */ }
}

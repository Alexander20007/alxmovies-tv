import { useQuery, useQueryClient } from "@tanstack/react-query";
import { adminCloseRoom, adminRooms } from "@/services/admin";
import { ago, Section } from "./ui";

export function RoomsTab() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["admin-rooms"], queryFn: adminRooms, refetchInterval: 30_000, retry: false });
  return (
    <Section title="Salas ativas agora" right={<button type="button" className="wb-btn" onClick={() => void q.refetch()}>Atualizar</button>}>
      <p className="wb-dim ao-foot">Salas privadas não mostram o que estão assistindo.</p>
      {q.isError && <p className="wb-form-err">{(q.error as Error).message}</p>}
      {q.data && !q.data.length && <p className="wb-dim">Nenhuma sala ativa.</p>}
      <div className="ao-list">
        {(q.data ?? []).map((r) => (
          <div key={r.id} className="ao-row">
            <div><b>{r.title}{r.is_private && <i className="ao-tag">privada</i>}{r.is_playing && <i className="ao-tag green">assistindo</i>}</b>
              <span>{r.what ?? "—"}</span><small>Anfitrião: {r.host_name} · {r.members} {r.members === 1 ? "pessoa" : "pessoas"} · criada há {ago(r.created_at)}</small></div>
            <button type="button" className="wb-btn wb-out" onClick={async () => { if (!window.confirm("Encerrar esta sala?")) return; await adminCloseRoom(r.id); void qc.invalidateQueries({ queryKey: ["admin-rooms"] }); }}>Encerrar</button>
          </div>
        ))}
      </div>
    </Section>
  );
}

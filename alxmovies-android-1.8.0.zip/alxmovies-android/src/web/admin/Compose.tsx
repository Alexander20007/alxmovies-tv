import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { adminAudienceCount, adminSendMessage, type Audience, type MsgKind } from "@/services/admin";
import { Note } from "./ui";

const KINDS: { v: MsgKind; label: string }[] = [
  { v: "aviso", label: "Aviso" }, { v: "atualizacao", label: "Atualização" }, { v: "plano", label: "Plano" }, { v: "suporte", label: "Suporte" },
];

/** Formulário de mensagem oficial (vai para Mensagens → ALXmovies no app). Mostra quantas pessoas vão receber antes de enviar. */
export function Compose({ audience, initial, onSent, compact }: {
  audience: Audience | null; initial?: { title?: string; body?: string; kind?: MsgKind }; onSent?: () => void; compact?: boolean;
}) {
  const qc = useQueryClient();
  const [title, setTitle] = useState(initial?.title ?? "");
  const [body, setBody] = useState(initial?.body ?? "");
  const [url, setUrl] = useState("");
  const [kind, setKind] = useState<MsgKind>(initial?.kind ?? "aviso");
  const [push, setPush] = useState(true);
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState<{ ok: boolean; text: string } | null>(null);

  const count = useQuery({
    queryKey: ["aud-count", audience], enabled: !!audience, retry: false,
    queryFn: () => adminAudienceCount(audience!),
  });

  async function send() {
    if (!audience || busy) return;
    if (!title.trim() || !body.trim()) return setNote({ ok: false, text: "Escreva o título e a mensagem." });
    if (url.trim() && !/^https:\/\//i.test(url.trim())) return setNote({ ok: false, text: "O link precisa começar com https://" });
    const n = count.data ?? 0;
    if (!window.confirm(`Enviar para ${n} ${n === 1 ? "pessoa" : "pessoas"}?`)) return;
    setBusy(true); setNote(null);
    try {
      const r = await adminSendMessage(audience, title.trim(), body.trim(), url, kind, push);
      setNote({ ok: true, text: `Enviada para ${r.sent} ${r.sent === 1 ? "pessoa" : "pessoas"}${r.push ? " (com notificação)" : ""}.` });
      setTitle(""); setBody(""); setUrl("");
      void qc.invalidateQueries({ queryKey: ["admin-history"] });
      onSent?.();
    } catch (e) { setNote({ ok: false, text: e instanceof Error ? e.message : "Não foi possível enviar." }); }
    finally { setBusy(false); }
  }

  return (
    <div className="ao-form">
      <div className="ao-grid2">
        <label>Título<input value={title} maxLength={80} onChange={(e) => setTitle(e.target.value)} placeholder="Ex.: Nova versão disponível" /></label>
        {!compact && (
          <label>Tipo
            <select value={kind} onChange={(e) => setKind(e.target.value as MsgKind)}>{KINDS.map((k) => <option key={k.v} value={k.v}>{k.label}</option>)}</select>
          </label>
        )}
      </div>
      <label>Mensagem<textarea value={body} maxLength={1000} rows={compact ? 3 : 5} onChange={(e) => setBody(e.target.value)} placeholder="Escreva para a pessoa…" /></label>
      <label>Link (opcional)<input value={url} inputMode="url" onChange={(e) => setUrl(e.target.value)} placeholder="https://…" /></label>
      <label className="ao-check"><input type="checkbox" checked={push} onChange={(e) => setPush(e.target.checked)} />Também enviar notificação no celular</label>
      <Note note={note} />
      <div className="ao-send">
        <span className="wb-dim">{audience ? (count.isLoading ? "Contando…" : count.isError ? "—" : `${count.data ?? 0} ${count.data === 1 ? "pessoa recebe" : "pessoas recebem"}`) : "Escolha o público"}</span>
        <button type="button" className="wb-btn primary" disabled={busy || !audience || !count.data} onClick={() => void send()}>{busy ? "Enviando…" : "Enviar mensagem"}</button>
      </div>
    </div>
  );
}

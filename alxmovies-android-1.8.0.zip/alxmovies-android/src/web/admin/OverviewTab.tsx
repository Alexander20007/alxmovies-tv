import { useQuery } from "@tanstack/react-query";
import { adminDashboard } from "@/services/admin";
import { Bars, PLAN_NAME, Section, Stat, verLess } from "./ui";

export function OverviewTab({ go }: { go: (tab: string, preset?: Record<string, string>) => void }) {
  const q = useQuery({ queryKey: ["admin-dashboard"], queryFn: adminDashboard, refetchInterval: 60_000, retry: false });
  const d = q.data;
  if (q.isLoading) return <p className="wb-dim">Carregando…</p>;
  if (q.isError || !d) return <p className="wb-form-err">{(q.error as Error)?.message || "Não foi possível carregar."}</p>;

  const latest = d.by_version.map((v) => v.version).sort((a, b) => (verLess(a, b) ? 1 : -1))[0];
  const onLatest = d.by_version.find((v) => v.version === latest)?.n ?? 0;
  const old = d.by_version.filter((v) => latest && verLess(v.version, latest)).reduce((s, v) => s + v.n, 0);

  return (
    <>
      <div className="ao-stats">
        <Stat label="Contas" value={d.users_total} hint={`${d.guests} convidados`} />
        <Stat label="Novas (7 dias)" value={d.new_7d} hint={`${d.new_24h} nas últimas 24 h`} tone="green" />
        <Stat label="Ativos hoje" value={d.active_24h} hint={`${d.active_7d} na semana · ${d.active_30d} no mês`} />
        <Stat label="Salas agora" value={d.rooms_active} hint={`${d.rooms_playing} assistindo`} />
        <Stat label="Downloads no mês" value={d.downloads_month} />
        <Stat label="Aparelhos com push" value={d.push_devices} />
      </div>

      {(d.proposals > 0 || old > 0) && (
        <div className="ao-todo">
          {d.proposals > 0 && <button type="button" onClick={() => go("equipe")}>📝 {d.proposals} {d.proposals === 1 ? "sugestão de aviso espera" : "sugestões de aviso esperam"} sua aprovação</button>}
          {old > 0 && latest && <button type="button" onClick={() => go("mensagens", { preset: "update", version: latest })}>⬆️ {old} {old === 1 ? "conta usa" : "contas usam"} versão mais antiga que {latest} — avisar para atualizar</button>}
        </div>
      )}

      <div className="ao-cols">
        <Section title="Versões do app" right={<small className="wb-dim">{d.reporting} contas informaram</small>}>
          <Bars rows={d.by_version.map((v) => ({ label: v.version, n: v.n }))} />
          {latest && <p className="wb-dim ao-foot">{Math.round((onLatest / Math.max(1, d.reporting)) * 100)}% já estão na versão mais nova ({latest}).</p>}
        </Section>
        <Section title="Planos">
          <Bars rows={d.by_plan.map((p) => ({ label: PLAN_NAME[p.plan] ?? p.plan, n: p.n }))} />
        </Section>
        <Section title="Plataformas">
          <Bars rows={d.by_platform.map((p) => ({ label: p.platform === "android" ? "Android" : "Site", n: p.n }))} />
        </Section>
      </div>

      <div className="ao-stats small">
        <Stat label="Admins na equipe" value={d.staff} />
        <Stat label="Códigos sem uso" value={d.codes_open} />
        <Stat label="Mensagens oficiais não lidas" value={d.messages_unread} />
      </div>
      <p className="wb-dim ao-foot">Privacidade: este painel mostra só dados da conta e do aparelho. O que cada pessoa assiste, favoritos e conversas ficam só com ela.</p>
    </>
  );
}

import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { adminHistory, adminRecall, type Audience } from "@/services/admin";
import { Compose } from "./Compose";
import { ago, fmtDateTime, PLAN_IDS, PLAN_NAME, Section } from "./ui";

type AudType = Audience["type"];
const AUDS: { v: AudType; label: string }[] = [
  { v: "all", label: "Todos os usuários" }, { v: "version_below", label: "Versão do app abaixo de…" }, { v: "version_is", label: "Exatamente a versão…" },
  { v: "plan", label: "Quem tem o plano…" }, { v: "platform", label: "Plataforma…" }, { v: "inactive", label: "Sem abrir o app há… dias" },
  { v: "new", label: "Contas novas (últimos… dias)" }, { v: "staff", label: "Equipe de admins" },
];

const TEMPLATES = [
  { id: "update", label: "⬆️ Nova versão", kind: "atualizacao" as const, title: "Nova versão disponível", body: "Atualize o ALXmovies para ter as novidades e correções mais recentes. Toque em “Atualizar” quando o app avisar ou baixe a versão nova pelo site." },
  { id: "back", label: "👋 Voltar a usar", kind: "aviso" as const, title: "Sentimos a sua falta", body: "Tem filme e série novos esperando por você no ALXmovies. Que tal assistir junto com os amigos numa sala?" },
  { id: "plan", label: "⭐ Plano ativado", kind: "plano" as const, title: "Seu plano foi ativado", body: "Seu plano já está ativo. Abra o app e confira o limite de downloads em Plano e assinatura." },
  { id: "maint", label: "🛠 Manutenção", kind: "aviso" as const, title: "Manutenção rápida", body: "Vamos fazer uma manutenção e o app pode ficar instável por alguns minutos. Obrigado pela paciência!" },
];

export function MessagesTab({ preset }: { preset?: Record<string, string> }) {
  const qc = useQueryClient();
  const [type, setType] = useState<AudType>(preset?.preset === "update" ? "version_below" : "all");
  const [version, setVersion] = useState(preset?.version ?? "");
  const [value, setValue] = useState("free");
  const [platform, setPlatform] = useState("android");
  const [days, setDays] = useState("14");
  const [tpl, setTpl] = useState<(typeof TEMPLATES)[number] | null>(preset?.preset === "update" ? TEMPLATES[0] : null);
  const [formKey, setFormKey] = useState(0);
  useEffect(() => { setFormKey((k) => k + 1); }, [tpl]);

  const aud: Audience | null =
    type === "all" ? { type } : type === "staff" ? { type }
    : type === "version_below" || type === "version_is" ? (/^\d+(\.\d+){0,3}$/.test(version.trim()) ? { type, version: version.trim() } : null)
    : type === "plan" ? { type, value } : type === "platform" ? { type, value: platform }
    : { type: type as "inactive" | "new", days: Math.max(1, parseInt(days, 10) || 14) };

  const hist = useQuery({ queryKey: ["admin-history"], queryFn: adminHistory, retry: false });

  return (
    <>
      <Section title="Nova mensagem oficial">
        <p className="wb-dim ao-foot">Chega em <b>Mensagens → ALXmovies ✔</b> no app, com notificação se você quiser. Só admin dono envia.</p>
        <div className="ao-chips">
          {TEMPLATES.map((t) => <button key={t.id} type="button" className={`ao-chip${tpl?.id === t.id ? " on" : ""}`} onClick={() => setTpl(tpl?.id === t.id ? null : t)}>{t.label}</button>)}
        </div>
        <div className="ao-form">
          <div className="ao-grid2">
            <label>Para quem
              <select value={type} onChange={(e) => setType(e.target.value as AudType)}>{AUDS.map((a) => <option key={a.v} value={a.v}>{a.label}</option>)}</select>
            </label>
            {(type === "version_below" || type === "version_is") && <label>Versão<input value={version} onChange={(e) => setVersion(e.target.value)} placeholder="1.8.0" inputMode="decimal" /></label>}
            {type === "plan" && <label>Plano<select value={value} onChange={(e) => setValue(e.target.value)}>{PLAN_IDS.map((p) => <option key={p} value={p}>{PLAN_NAME[p]}</option>)}</select></label>}
            {type === "platform" && <label>Plataforma<select value={platform} onChange={(e) => setPlatform(e.target.value)}><option value="android">Android (app)</option><option value="web">Site</option></select></label>}
            {(type === "inactive" || type === "new") && <label>Dias<input value={days} onChange={(e) => setDays(e.target.value)} inputMode="numeric" /></label>}
          </div>
        </div>
        <Compose key={formKey} audience={aud} initial={tpl ? { title: tpl.title, body: tpl.body, kind: tpl.kind } : undefined} />
      </Section>

      <Section title="Enviadas">
        {hist.isLoading && <p className="wb-dim">Carregando…</p>}
        {hist.isError && <p className="wb-form-err">{(hist.error as Error).message}</p>}
        {hist.data && !hist.data.length && <p className="wb-dim">Nenhuma mensagem enviada ainda.</p>}
        <div className="ao-list">
          {(hist.data ?? []).map((h) => (
            <div key={h.batch_id} className="ao-row col">
              <div><b>{h.title}</b><span>{h.body}</span><small>{fmtDateTime(h.created_at)} ({ago(h.created_at)}) · {h.recipients} {h.recipients === 1 ? "pessoa" : "pessoas"} · {h.read_count} leram</small></div>
              <div className="wb-row">
                <button type="button" className="wb-btn wb-out" onClick={async () => {
                  if (!window.confirm("Apagar esta mensagem para todas as pessoas que a receberam?")) return;
                  await adminRecall(h.batch_id); void qc.invalidateQueries({ queryKey: ["admin-history"] });
                }}>Apagar para todos</button>
              </div>
            </div>
          ))}
        </div>
      </Section>
    </>
  );
}

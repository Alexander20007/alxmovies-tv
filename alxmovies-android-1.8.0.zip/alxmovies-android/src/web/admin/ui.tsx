import { useEffect, useState, type ReactNode } from "react";

export const fmtDate = (iso?: string | null) => (iso ? new Date(iso).toLocaleDateString("pt-BR") : "—");
export const fmtDateTime = (iso?: string | null) => (iso ? new Date(iso).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", year: "2-digit", hour: "2-digit", minute: "2-digit" }) : "—");

export function ago(iso?: string | null): string {
  if (!iso) return "nunca";
  const s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 90) return "agora";
  if (s < 3600) return `${Math.round(s / 60)} min`;
  if (s < 86400) return `${Math.round(s / 3600)} h`;
  if (s < 86400 * 60) return `${Math.round(s / 86400)} d`;
  return `${Math.round(s / 86400 / 30)} meses`;
}

/** true se a versão `a` é menor que `b` (1.7.3 < 1.8.0). */
export function verLess(a: string | null | undefined, b: string): boolean {
  const x = (a ?? "").split(".").map((n) => parseInt(n, 10) || 0), y = b.split(".").map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(x.length, y.length, 3); i++) { const d = (x[i] ?? 0) - (y[i] ?? 0); if (d !== 0) return d < 0; }
  return false;
}

export function useDebounced<T>(value: T, ms = 400): T {
  const [v, setV] = useState(value);
  useEffect(() => { const t = setTimeout(() => setV(value), ms); return () => clearTimeout(t); }, [value, ms]);
  return v;
}

export function Stat({ label, value, hint, tone }: { label: string; value: ReactNode; hint?: string; tone?: "red" | "green" }) {
  return (
    <div className={`ao-stat${tone ? ` ${tone}` : ""}`}>
      <small>{label}</small><b>{value}</b>{hint && <em>{hint}</em>}
    </div>
  );
}

export function Bars({ rows, total }: { rows: { label: string; n: number }[]; total?: number }) {
  const max = Math.max(1, ...rows.map((r) => r.n)), sum = total ?? rows.reduce((s, r) => s + r.n, 0);
  if (!rows.length) return <p className="wb-dim">Sem dados ainda.</p>;
  return (
    <div className="ao-bars">
      {rows.map((r) => (
        <div key={r.label} className="ao-bar">
          <span>{r.label}</span>
          <i><u style={{ width: `${Math.max(3, (r.n / max) * 100)}%` }} /></i>
          <b>{r.n}{sum > 0 ? <small> {Math.round((r.n / sum) * 100)}%</small> : null}</b>
        </div>
      ))}
    </div>
  );
}

export function Note({ note }: { note: { ok: boolean; text: string } | null }) {
  return note ? <p className={note.ok ? "wb-form-ok" : "wb-form-err"} role="status">{note.text}</p> : null;
}

export function Section({ title, right, children }: { title: string; right?: ReactNode; children: ReactNode }) {
  return (
    <section className="ao-sec">
      <header><h3>{title}</h3>{right}</header>
      {children}
    </section>
  );
}

export const PLAN_NAME: Record<string, string> = { free: "Grátis", apoiador: "Apoiador", premium: "Premium", familia: "Família" };
export const PLAN_IDS = ["free", "apoiador", "premium", "familia"] as const;

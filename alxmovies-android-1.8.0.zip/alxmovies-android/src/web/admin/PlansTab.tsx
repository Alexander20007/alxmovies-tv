import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { adminPlanUpdate } from "@/services/admin";
import { listPlans, type PlanInfo } from "@/services/plans";
import { Note, Section } from "./ui";

function PlanRow({ p, onSaved }: { p: PlanInfo; onSaved: () => void }) {
  const [name, setName] = useState(p.name); const [dl, setDl] = useState(String(p.downloads_per_month));
  const [ads, setAds] = useState(p.show_ads); const [price, setPrice] = useState(p.price_brl == null ? "" : String(p.price_brl));
  const [note, setNote] = useState<{ ok: boolean; text: string } | null>(null);
  async function save() {
    try { await adminPlanUpdate(p.id, name, parseInt(dl, 10) || 0, ads, price.trim() ? Number(price.replace(",", ".")) : null); setNote({ ok: true, text: "Salvo." }); onSaved(); }
    catch (e) { setNote({ ok: false, text: e instanceof Error ? e.message : "Não foi possível salvar." }); }
  }
  return (
    <div className="ao-plan-row">
      <h4>{p.id}</h4>
      <div className="ao-grid2">
        <label>Nome<input value={name} maxLength={30} onChange={(e) => setName(e.target.value)} /></label>
        <label>Downloads por mês<input value={dl} inputMode="numeric" onChange={(e) => setDl(e.target.value)} /></label>
        <label>Preço (R$)<input value={price} inputMode="decimal" placeholder="em breve" onChange={(e) => setPrice(e.target.value)} /></label>
        <label className="ao-check"><input type="checkbox" checked={ads} onChange={(e) => setAds(e.target.checked)} />Mostra anúncios</label>
      </div>
      <Note note={note} />
      <button type="button" className="wb-btn primary" onClick={() => void save()}>Salvar {p.id}</button>
    </div>
  );
}

export function PlansTab() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["admin-plans"], queryFn: listPlans });
  return (
    <Section title="Planos do app">
      <p className="wb-dim ao-foot">O app lê estes valores direto do servidor: ao salvar, vale para todo mundo na próxima vez que abrir.</p>
      {q.isLoading && <p className="wb-dim">Carregando…</p>}
      {(q.data ?? []).map((p) => <PlanRow key={`${p.id}${p.downloads_per_month}${p.price_brl}`} p={p} onSaved={() => void qc.invalidateQueries({ queryKey: ["admin-plans"] })} />)}
    </Section>
  );
}

import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { adminCodeRevoke, adminCodes, adminCodesCreate } from "@/services/admin";
import { fmtDate, Note, PLAN_IDS, PLAN_NAME, Section } from "./ui";

export function CodesTab() {
  const qc = useQueryClient();
  const list = useQuery({ queryKey: ["admin-codes"], queryFn: adminCodes, retry: false });
  const [plan, setPlan] = useState("premium"); const [days, setDays] = useState("7"); const [bonus, setBonus] = useState("0");
  const [qty, setQty] = useState("1"); const [valid, setValid] = useState("30");
  const [made, setMade] = useState<string[]>([]); const [note, setNote] = useState<{ ok: boolean; text: string } | null>(null); const [busy, setBusy] = useState(false);

  async function create() {
    setBusy(true); setNote(null);
    try {
      const r = await adminCodesCreate({ plan: Number(days) > 0 ? plan : null, days: parseInt(days, 10) || 0, bonus: parseInt(bonus, 10) || 0, qty: parseInt(qty, 10) || 1, validDays: parseInt(valid, 10) || 30 });
      setMade(r.codes); setNote({ ok: true, text: `${r.codes.length} ${r.codes.length === 1 ? "código criado" : "códigos criados"}: ${r.label}.` });
      void qc.invalidateQueries({ queryKey: ["admin-codes"] }); void qc.invalidateQueries({ queryKey: ["admin-dashboard"] });
    } catch (e) { setNote({ ok: false, text: e instanceof Error ? e.message : "Não foi possível criar." }); }
    finally { setBusy(false); }
  }
  const copy = (t: string) => void navigator.clipboard?.writeText(t);

  return (
    <>
      <Section title="Gerar códigos de prêmio">
        <p className="wb-dim ao-foot">Cada código vale uma vez. A pessoa digita em Minha conta → Resgatar código, no site (alxmovies.netlify.app/conta).</p>
        <div className="ao-form">
          <div className="ao-grid2">
            <label>Plano<select value={plan} onChange={(e) => setPlan(e.target.value)}>{PLAN_IDS.filter((p) => p !== "free").map((p) => <option key={p} value={p}>{PLAN_NAME[p]}</option>)}</select></label>
            <label>Dias do plano (0 = só downloads)<input value={days} onChange={(e) => setDays(e.target.value)} inputMode="numeric" /></label>
            <label>Downloads extras<input value={bonus} onChange={(e) => setBonus(e.target.value)} inputMode="numeric" /></label>
            <label>Quantos códigos<input value={qty} onChange={(e) => setQty(e.target.value)} inputMode="numeric" /></label>
            <label>Vale por (dias)<input value={valid} onChange={(e) => setValid(e.target.value)} inputMode="numeric" /></label>
          </div>
          <Note note={note} />
          <button type="button" className="wb-btn primary" disabled={busy} onClick={() => void create()}>{busy ? "Gerando…" : "Gerar"}</button>
        </div>
        {made.length > 0 && (
          <div className="ao-codes">
            {made.map((c) => <button key={c} type="button" onClick={() => copy(c)} title="Copiar">{c}</button>)}
            <button type="button" className="wb-btn" onClick={() => copy(made.join("\n"))}>Copiar todos</button>
          </div>
        )}
      </Section>

      <Section title="Códigos recentes">
        {list.isError && <p className="wb-form-err">{(list.error as Error).message}</p>}
        <div className="ao-list">
          {(list.data ?? []).map((c) => {
            const used = !!c.redeemed_by, expired = !used && new Date(c.expires_at) < new Date();
            return (
              <div key={c.code} className="ao-row">
                <div><b>{c.code}</b><span>{c.prize_label}</span>
                  <small>{used ? `Usado por ${c.redeemed_name ?? "—"} em ${fmtDate(c.redeemed_at)}` : expired ? `Venceu em ${fmtDate(c.expires_at)}` : `Vale até ${fmtDate(c.expires_at)}`}</small></div>
                {!used && <button type="button" className="wb-btn wb-out" onClick={async () => { await adminCodeRevoke(c.code); void qc.invalidateQueries({ queryKey: ["admin-codes"] }); }}>Apagar</button>}
              </div>
            );
          })}
          {list.data && !list.data.length && <p className="wb-dim">Nenhum código ainda.</p>}
        </div>
      </Section>
    </>
  );
}

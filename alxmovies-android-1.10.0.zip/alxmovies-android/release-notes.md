## Novo
- Anúncios agora pelo Appodeal, com controle total da equipe: fontes, tipos de anúncio e frequência ajustáveis sem atualizar o app
- Planos: salas com limites por plano (entrar, criar, pessoas por sala) e filme baixado na sala só nos planos liberados
- Salas: filmes e séries escolhidos pela equipe que aparecem só nas salas ("Só nas salas" ao criar uma sala)
- Canais ao vivo: categorias exclusivas de certos planos (aparecem com cadeado)
- Mensagens: conversa oficial "ALXmovies ✔" com avisos da equipe
- Salas: se você baixou o filme, a sala toca o arquivo do celular e não gasta internet com o vídeo
- Downloads: tela nova com configurações (Wi-Fi, velocidade, qualidade e uso nas salas)
## Melhorado
- Sala mais limpa: só vídeo, chat e controles; o resto ficou em Definições
- Avisos claros quando um limite do plano é atingido, com atalho para ver os planos
- O app informa a versão e o aparelho para a equipe poder avisar sobre atualizações (nada do que você assiste ou conversa é enviado)

import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { adminAdsGet, adminAdsSetProvider, adminAdsSetSettings, type AdProviderRow, type AdSettingsRow } from "@/services/admin";
import { Note, Section } from "./ui";

function Switch({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label: string }) {
  return <button type="button" role="switch" aria-checked={on} aria-label={label} className={`ao-switch${on ? " on" : ""}`} onClick={() => onChange(!on)}><i /></button>;
}

function ProviderCard({ p, onSaved }: { p: AdProviderRow; onSaved: () => void }) {
  const [enabled, setEnabled] = useState(p.enabled);
  const [st, setSt] = useState<Record<string, unknown>>(p.settings ?? {});
  const [note, setNote] = useState<{ ok: boolean; text: string } | null>(null);
  const str = (k: string) => String(st[k] ?? "");
  const set = (k: string, v: unknown) => setSt((o) => ({ ...o, [k]: v }));
  const fields: { k: string; label: string; ph?: string }[] =
    p.id === "appodeal" ? [{ k: "app_key", label: "App Key do Appodeal", ph: "e34f80ba…" }]
    : p.id === "adsense" ? [{ k: "client", label: "ID do publisher (ca-pub-…)", ph: "ca-pub-1234567890" }]
    : p.id === "adsterra" ? [{ k: "script_url", label: "Endereço do script (https://…)" }, { k: "popunder_url", label: "Endereço do popunder ao dar play (https://…)" }]
    : [];

  async function save() {
    setNote(null);
    try { await adminAdsSetProvider(p.id, enabled, p.priority, st); setNote({ ok: true, text: "Salvo." }); onSaved(); }
    catch (e) { setNote({ ok: false, text: e instanceof Error ? e.message : "Não foi possível salvar." }); }
  }

  return (
    <div className={`ao-prov${p.available ? "" : " off"}`}>
      <div className="ao-prov-head">
        <div><b>{p.name}</b><small>{p.platform === "android" ? "App Android" : "Site"}{!p.available ? " · fora desta versão" : ""}</small></div>
        <Switch on={enabled} onChange={setEnabled} label={`${p.name} ligado`} />
      </div>
      {p.note && <p className="wb-dim ao-foot">{p.note}</p>}
      {p.available && (
        <>
          {fields.map((f) => (
            <label key={f.k} className="ao-field">{f.label}<input value={str(f.k)} placeholder={f.ph} autoCapitalize="off" spellCheck={false} onChange={(e) => set(f.k, e.target.value.trim())} /></label>
          ))}
          {p.id === "appodeal" && (
            <label className="ao-check"><input type="checkbox" checked={st.test_mode === true} onChange={(e) => set("test_mode", e.target.checked)} />Modo teste (anúncios de teste, sem receita — não use em produção)</label>
          )}
          <Note note={note} />
          <button type="button" className="wb-btn primary" onClick={() => void save()}>Salvar {p.name}</button>
        </>
      )}
    </div>
  );
}

export function AdsTab() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["admin-ads"], queryFn: adminAdsGet, retry: false });
  const [s, setS] = useState<AdSettingsRow | null>(null);
  const [note, setNote] = useState<{ ok: boolean; text: string } | null>(null);
  useEffect(() => { if (q.data) setS(q.data.settings); }, [q.data]);
  const refresh = () => void qc.invalidateQueries({ queryKey: ["admin-ads"] });

  if (q.isLoading) return <p className="wb-dim">Carregando…</p>;
  if (q.isError || !q.data || !s) return <p className="wb-form-err">{(q.error as Error)?.message || "Não foi possível carregar."}</p>;
  const patch = (p: Partial<AdSettingsRow>) => setS({ ...s, ...p });
  const pct = (n: number) => String(Math.round(n * 100));

  async function save() {
    setNote(null);
    try { await adminAdsSetSettings(s!); setNote({ ok: true, text: "Regras salvas. O app aplica em até 5 minutos." }); refresh(); }
    catch (e) { setNote({ ok: false, text: e instanceof Error ? e.message : "Não foi possível salvar." }); }
  }

  const android = q.data.providers.filter((p) => p.platform === "android");
  const web = q.data.providers.filter((p) => p.platform === "web");

  return (
    <>
      <Section title="Regras gerais">
        <div className="ao-prov">
          <div className="ao-prov-head"><div><b>Anúncios ligados</b><small>Chave geral: desliga TODOS os anúncios (app e site)</small></div><Switch on={s.master_enabled} onChange={(v) => patch({ master_enabled: v })} label="Anúncios ligados" /></div>
          <div className="ao-prov-head"><div><b>Admins e dono também veem anúncios</b><small>Hoje a equipe tem Premium (sem anúncios). Ligue para testar.</small></div><Switch on={s.staff_see_ads} onChange={(v) => patch({ staff_see_ads: v })} label="Equipe vê anúncios" /></div>
        </div>
        <h5 className="ao-sub">Tipos de anúncio (app)</h5>
        <div className="ao-prov">
          <div className="ao-prov-head"><div><b>Tela cheia</b><small>Aparece de vez em quando ao navegar</small></div><Switch on={s.interstitial_enabled} onChange={(v) => patch({ interstitial_enabled: v })} label="Tela cheia" /></div>
          <div className="ao-prov-head"><div><b>Premiado</b><small>A pessoa escolhe assistir para ganhar downloads</small></div><Switch on={s.rewarded_enabled} onChange={(v) => patch({ rewarded_enabled: v })} label="Premiado" /></div>
          <div className="ao-prov-head"><div><b>Banner</b><small>Faixa no rodapé de algumas telas</small></div><Switch on={s.banner_enabled} onChange={(v) => patch({ banner_enabled: v })} label="Banner" /></div>
        </div>
        <h5 className="ao-sub">Frequência da tela cheia</h5>
        <div className="ao-grid2">
          <label className="ao-field">Chance ao abrir um título (%)<input inputMode="numeric" value={pct(s.details_chance)} onChange={(e) => patch({ details_chance: Math.min(1, Math.max(0, (parseInt(e.target.value, 10) || 0) / 100)) })} /></label>
          <label className="ao-field">Chance antes de baixar (%)<input inputMode="numeric" value={pct(s.download_chance)} onChange={(e) => patch({ download_chance: Math.min(1, Math.max(0, (parseInt(e.target.value, 10) || 0) / 100)) })} /></label>
          <label className="ao-field">Intervalo mínimo entre anúncios (segundos)<input inputMode="numeric" value={s.min_gap_seconds} onChange={(e) => patch({ min_gap_seconds: Math.min(86400, Math.max(0, parseInt(e.target.value, 10) || 0)) })} /></label>
          <label className="ao-field">Máximo por abertura do app<input inputMode="numeric" value={s.max_per_session} onChange={(e) => patch({ max_per_session: Math.min(100, Math.max(0, parseInt(e.target.value, 10) || 0)) })} /></label>
        </div>
        <Note note={note} />
        <button type="button" className="wb-btn primary" onClick={() => void save()}>Salvar regras</button>
        <p className="wb-dim ao-foot">Perfil infantil (Kids) nunca vê anúncio, e só o plano Grátis vê. Mudanças valem em até 5 minutos, sem precisar atualizar o app. Trocar a chave ou o modo teste vale na próxima vez que a pessoa abrir o app.</p>
      </Section>

      <Section title="Fontes de anúncio — app Android">
        <div className="ao-provs">{android.map((p) => <ProviderCard key={`${p.id}${p.enabled}${JSON.stringify(p.settings)}`} p={p} onSaved={refresh} />)}</div>
        <p className="wb-dim ao-foot">O Appodeal escolhe automaticamente a rede que paga mais. As redes por trás dele (Start.io, Unity, AppLovin…) e as chaves de cada uma ficam no painel do próprio Appodeal (app.appodeal.com).</p>
      </Section>

      <Section title="Fontes de anúncio — site">
        <div className="ao-provs">{web.map((p) => <ProviderCard key={`${p.id}${p.enabled}${JSON.stringify(p.settings)}`} p={p} onSaved={refresh} />)}</div>
      </Section>
    </>
  );
}

import { useState, type ReactNode } from "react";
import { AccessTab } from "./AccessTab";
import { AdsTab } from "./AdsTab";
import { TeamPerms } from "./TeamPerms";
import { useMyPerms } from "./ui";
import { AuditTab } from "./AuditTab";
import { CodesTab } from "./CodesTab";
import { MessagesTab } from "./MessagesTab";
import { OverviewTab } from "./OverviewTab";
import { PlansTab } from "./PlansTab";
import { RoomsTab } from "./RoomsTab";
import { UsersTab } from "./UsersTab";

const TABS = [
  { id: "resumo", label: "📊 Resumo", perm: "dashboard" }, { id: "usuarios", label: "👥 Usuários", perm: "users" },
  { id: "mensagens", label: "✉️ Mensagens", perm: "messages" }, { id: "planos", label: "⭐ Planos", perm: "plans_edit" },
  { id: "acessos", label: "🔑 Salas e canais", perm: "access" }, { id: "anuncios", label: "📢 Anúncios", perm: "ads" },
  { id: "codigos", label: "🎟 Códigos", perm: "codes" }, { id: "salas", label: "🎬 Salas", perm: "rooms" },
  { id: "equipe", label: "🛡 Equipe", perm: "owner" }, { id: "registro", label: "🧾 Registro", perm: "audit" },
] as const;

/** Painel completo do dono. A aba Equipe recebe as seções já existentes (sugestões de aviso e admins). */
export function OwnerConsole({ team }: { team?: ReactNode }) {
  const me = useMyPerms();
  const tabs = TABS.filter((t) => (t.perm === "owner" ? me.owner : me.can(t.perm)));
  const [tab0, setTab] = useState<string>("");
  const tab = tab0 && tabs.some((t) => t.id === tab0) ? tab0 : tabs[0]?.id ?? "";
  const [preset, setPreset] = useState<Record<string, string> | undefined>();
  const go = (t: string, p?: Record<string, string>) => { setPreset(p); setTab(t); window.scrollTo({ top: 0, behavior: "smooth" }); };

  return (
    <div className="ao">
      {!me.loading && !tabs.length && <p className="wb-dim">Você ainda não tem funções liberadas. Peça ao dono para liberar no painel.</p>}
      <nav className="ao-tabs" aria-label="Seções do painel">
        {tabs.map((t) => <button key={t.id} type="button" className={tab === t.id ? "on" : ""} onClick={() => go(t.id)}>{t.label}</button>)}
      </nav>
      {tab === "resumo" && <OverviewTab go={go} />}
      {tab === "usuarios" && <UsersTab />}
      {tab === "mensagens" && <MessagesTab key={JSON.stringify(preset ?? {})} preset={preset} />}
      {tab === "planos" && <PlansTab />}
      {tab === "anuncios" && <AdsTab />}
      {tab === "acessos" && <AccessTab />}
      {tab === "codigos" && <CodesTab />}
      {tab === "salas" && <RoomsTab />}
      {tab === "equipe" && me.owner && (<>{team}<TeamPerms /></>)}
      {tab === "registro" && <AuditTab />}
    </div>
  );
}

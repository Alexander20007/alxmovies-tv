## Novo
- Planos: salas com limites por plano (quantas salas você entra e cria por mês, e quantas pessoas cabem nas salas que você cria)
- Planos: assistir na sala com o filme baixado agora depende do plano
- Salas: filmes e séries escolhidos pela equipe que aparecem só nas salas ("Só nas salas" ao criar uma sala)
- Canais ao vivo: algumas categorias podem ser exclusivas de certos planos (aparecem com cadeado)
- Planos: a lista de vantagens agora mostra os limites de sala de cada plano
## Melhorado
- Avisos claros quando um limite do plano é atingido, com atalho para ver os planos

import { useState, type ReactNode } from "react";
import { AccessTab } from "./AccessTab";
import { AuditTab } from "./AuditTab";
import { CodesTab } from "./CodesTab";
import { MessagesTab } from "./MessagesTab";
import { OverviewTab } from "./OverviewTab";
import { PlansTab } from "./PlansTab";
import { RoomsTab } from "./RoomsTab";
import { UsersTab } from "./UsersTab";

const TABS = [
  { id: "resumo", label: "📊 Resumo" }, { id: "usuarios", label: "👥 Usuários" }, { id: "mensagens", label: "✉️ Mensagens" },
  { id: "planos", label: "⭐ Planos" }, { id: "acessos", label: "🔑 Salas e canais" }, { id: "codigos", label: "🎟 Códigos" }, { id: "salas", label: "🎬 Salas" },
  { id: "equipe", label: "🛡 Equipe" }, { id: "registro", label: "🧾 Registro" },
] as const;

/** Painel completo do dono. A aba Equipe recebe as seções já existentes (sugestões de aviso e admins). */
export function OwnerConsole({ team }: { team: ReactNode }) {
  const [tab, setTab] = useState<string>("resumo");
  const [preset, setPreset] = useState<Record<string, string> | undefined>();
  const go = (t: string, p?: Record<string, string>) => { setPreset(p); setTab(t); window.scrollTo({ top: 0, behavior: "smooth" }); };

  return (
    <div className="ao">
      <nav className="ao-tabs" aria-label="Seções do painel">
        {TABS.map((t) => <button key={t.id} type="button" className={tab === t.id ? "on" : ""} onClick={() => go(t.id)}>{t.label}</button>)}
      </nav>
      {tab === "resumo" && <OverviewTab go={go} />}
      {tab === "usuarios" && <UsersTab />}
      {tab === "mensagens" && <MessagesTab key={JSON.stringify(preset ?? {})} preset={preset} />}
      {tab === "planos" && <PlansTab />}
      {tab === "acessos" && <AccessTab />}
      {tab === "codigos" && <CodesTab />}
      {tab === "salas" && <RoomsTab />}
      {tab === "equipe" && team}
      {tab === "registro" && <AuditTab />}
    </div>
  );
}

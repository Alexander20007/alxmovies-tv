import { registerPlugin, type PluginListenerHandle } from "@capacitor/core";
import { App } from "@capacitor/app";

/** Última versão publicada em Releases (o workflow cria uma tag v1.0.N a cada build). */
const RELEASE_API = "https://api.github.com/repos/Alexander20007/alxmovies-tv/releases/latest";

export interface DownloadProgress { received: number; total: number; percent: number }

interface AppUpdaterPlugin {
  download(opts: { url: string; size?: number }): Promise<{ path: string }>;
  cancel(): Promise<void>;
  canInstall(): Promise<{ allowed: boolean }>;
  openInstallSettings(): Promise<void>;
  install(): Promise<void>;
  cleanup(): Promise<void>;
  addListener(event: "downloadProgress", cb: (p: DownloadProgress) => void): Promise<PluginListenerHandle>;
}

/** Plugin nativo (criado por scripts/android/patch-android.mjs). */
export const AppUpdater = registerPlugin<AppUpdaterPlugin>("AppUpdater");

export interface UpdateInfo {
  version: string;   // ex.: "1.0.12"
  current: string;   // versão instalada
  url: string;       // link do .apk
  size: number;      // bytes
}

const parse = (v: string) => v.replace(/^v/i, "").split(".").map((n) => parseInt(n, 10) || 0);

/** true se `a` é mais nova que `b`. */
function isNewer(a: string, b: string) {
  const x = parse(a), y = parse(b);
  for (let i = 0; i < Math.max(x.length, y.length); i++) {
    const d = (x[i] ?? 0) - (y[i] ?? 0);
    if (d !== 0) return d > 0;
  }
  return false;
}

/** Consulta o GitHub. Retorna os dados da atualização, ou null se já está na última versão (ou se der erro de rede). */
export async function checkForUpdate(): Promise<UpdateInfo | null> {
  try {
    const [{ version: current }, res] = await Promise.all([
      App.getInfo(),
      fetch(RELEASE_API, { headers: { Accept: "application/vnd.github+json" } }),
    ]);
    if (!res.ok) return null;
    const rel = await res.json() as { tag_name?: string; assets?: { name: string; browser_download_url: string; size: number }[] };
    const tag = rel.tag_name;
    const apk = rel.assets?.find((a) => a.name.toLowerCase().endsWith(".apk"));
    if (!tag || !apk || !isNewer(tag, current)) return null;
    return { version: tag.replace(/^v/i, ""), current, url: apk.browser_download_url, size: apk.size };
  } catch {
    return null; // sem internet / limite da API: tenta de novo na próxima abertura
  }
}

import { registerPlugin } from "@capacitor/core";

export interface NativePlayOptions {
  url: string;
  title: string;
  subtitle?: string;
  startMs?: number;
  startPercent?: number;
  hasNext: boolean;
  server: string;
  source: "main" | "fallback";
  fallbackLabel: string;
  servers: { label: string; ok: boolean }[];
  rate: number;
}
export type NativeReason = "closed" | "ended" | "next" | "server" | "error";
export interface NativePlayResult { reason: NativeReason; positionMs: number; durationMs: number; rate: number; server?: string }

interface AlxPlayerPlugin {
  play(o: NativePlayOptions): Promise<NativePlayResult>;
  addListener(ev: "progress", cb: (p: { positionMs: number; durationMs: number }) => void): Promise<{ remove: () => Promise<void> }>;
}
export const NativePlayer = registerPlugin<AlxPlayerPlugin>("AlxPlayer");

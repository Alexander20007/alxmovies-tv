import { registerPlugin } from "@capacitor/core";
import { isNative } from "./native";

export type ManagerId = "adm" | "1dm" | "other";
export interface ManagerInfo { id: "adm" | "1dm"; name: string; installed: boolean }

interface AlxDownloadPlugin {
  listManagers(): Promise<{ managers: ManagerInfo[] }>;
  open(o: { id: ManagerId; url: string; title?: string; referer?: string }): Promise<void>;
  openStore(o: { id: "adm" | "1dm" }): Promise<void>;
}
const Native = registerPlugin<AlxDownloadPlugin>("AlxDownload");

export const PREF_KEY = "alx.dl.manager";

export async function listManagers(): Promise<ManagerInfo[]> {
  if (!isNative) return [];
  try { return (await Native.listManagers()).managers; }
  catch { return [{ id: "adm", name: "ADM", installed: false }, { id: "1dm", name: "1DM", installed: false }]; }
}

/** Entrega o link ao gerenciador escolhido. Retorna "not_installed" se o app não está no celular. */
export async function openInManager(id: ManagerId, url: string, title?: string, referer?: string): Promise<"ok" | "not_installed" | "error"> {
  try { await Native.open({ id, url, title, referer }); return "ok"; }
  catch (e) { return (e as Error)?.message === "not_installed" ? "not_installed" : "error"; }
}
export const openManagerStore = (id: "adm" | "1dm") => Native.openStore({ id }).catch(() => {});

export function savedManager(): ManagerId | "app" | null {
  try { const v = localStorage.getItem(PREF_KEY); return v === "adm" || v === "1dm" || v === "other" || v === "app" ? v : null; } catch { return null; }
}
export function saveManager(v: ManagerId | "app" | null) {
  try { if (v) localStorage.setItem(PREF_KEY, v); else localStorage.removeItem(PREF_KEY); } catch { /* sem armazenamento */ }
}

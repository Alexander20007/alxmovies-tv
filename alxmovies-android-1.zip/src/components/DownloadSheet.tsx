import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { useBackClose } from "@/hooks/useBackClose";
import { Spinner } from "@/components/Spinner";
import { resolveStream, type StreamRequest } from "@/services/stream";
import { listManagers, openInManager, openManagerStore, type ManagerId, type ManagerInfo } from "@/lib/downloader";

export interface DownloadRequest extends StreamRequest { title: string }

/** Janela "Baixar com…": a pessoa escolhe ADM, 1DM ou outro app; o link do vídeo é preparado e entregue ao app escolhido. */
export function DownloadSheet({ req, onClose }: { req: DownloadRequest | null; onClose: () => void }) {
  useBackClose(!!req, onClose);
  const [managers, setManagers] = useState<ManagerInfo[]>([]);
  const [busy, setBusy] = useState<ManagerId | null>(null);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    if (!req) return;
    setMsg(""); setBusy(null);
    void listManagers().then(setManagers);
  }, [req]);

  if (!req) return null;

  async function pick(id: ManagerId) {
    if (!req || busy) return;
    const m = managers.find((x) => x.id === id);
    if (m && !m.installed) { void openManagerStore(m.id); return; }
    setBusy(id); setMsg("");
    try {
      const r = await resolveStream(req);
      const label = req.type === "tv" && req.season ? `${req.title} T${req.season}E${req.episode}` : req.title;
      const res = await openInManager(id, r.m3u8, label);
      if (res === "ok") onClose();
      else setMsg(res === "not_installed" ? "Esse aplicativo não está instalado." : "Não foi possível abrir o gerenciador.");
    } catch (e) {
      setMsg(e instanceof Error && e.message ? e.message : "Não encontramos o link do vídeo agora. Tente de novo em instantes.");
    }
    setBusy(null);
  }

  const rows: { id: ManagerId; name: string; hint: string; installed: boolean }[] = [
    ...(["adm", "1dm"] as const).map((id) => {
      const m = managers.find((x) => x.id === id);
      return { id, name: id === "adm" ? "ADM" : "1DM", hint: m?.installed === false ? "Não instalado — toque para instalar" : "Advanced Download Manager".replace("Advanced Download Manager", id === "adm" ? "Advanced Download Manager" : "1DM Browser & Downloader"), installed: m?.installed !== false };
    }),
    { id: "other", name: "Outro aplicativo", hint: "Escolher na lista do Android", installed: true },
  ];

  return createPortal(
    <div className="salas-modal" style={{ display: "flex" }} onClick={(e) => e.target === e.currentTarget && !busy && onClose()}>
      <div className="salas-modal-box dl-sheet">
        <button type="button" className="salas-modal-close" onClick={onClose} aria-label="Fechar">×</button>
        <h2>Baixar com…</h2>
        <p className="dl-sub">{req.title}{req.type === "tv" && req.season ? ` · T${req.season} E${req.episode}` : ""}</p>
        <div className="dl-list">
          {rows.map((r) => (
            <button key={r.id} type="button" className={`dl-row${r.installed ? "" : " off"}`} disabled={!!busy} onClick={() => void pick(r.id)}>
              <span className="dl-ico">{r.id === "adm" ? "A" : r.id === "1dm" ? "1" : "⋯"}</span>
              <span className="dl-txt"><b>{r.name}</b><small>{r.hint}</small></span>
              {busy === r.id ? <Spinner size={20} /> : <span className="dl-go">›</span>}
            </button>
          ))}
        </div>
        {busy && <p className="dl-sub">Preparando o link do vídeo…</p>}
        {msg && <p className="salas-erro" role="alert">{msg}</p>}
      </div>
    </div>,
    document.body,
  );
}

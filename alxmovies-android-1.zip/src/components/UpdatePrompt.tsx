import { useCallback, useEffect, useRef, useState } from "react";
import { isNative, onAppResume } from "@/lib/native";
import { useBackClose } from "@/hooks/useBackClose";
import { AppUpdater, checkForUpdate, type UpdateInfo } from "@/lib/updater";

type Phase = "idle" | "available" | "downloading" | "permission" | "installing" | "error";

const mb = (n: number) => (n / 1048576).toFixed(1).replace(".", ",");

/** Verifica atualização ao abrir o app e conduz: aviso → download com progresso → instalador do Android. */
export function UpdatePrompt() {
  const [phase, setPhase] = useState<Phase>("idle");
  const [info, setInfo] = useState<UpdateInfo | null>(null);
  const [progress, setProgress] = useState({ received: 0, percent: 0, total: 0 });
  const [error, setError] = useState("");
  const phaseRef = useRef<Phase>("idle");
  phaseRef.current = phase;

  // Ao abrir o app: limpa APK antigo e procura versão nova.
  useEffect(() => {
    if (!isNative) return;
    let alive = true;
    void AppUpdater.cleanup().catch(() => {});
    void checkForUpdate().then((u) => { if (alive && u) { setInfo(u); setPhase("available"); } });
    return () => { alive = false; };
  }, []);

  const openInstaller = useCallback(async () => {
    try {
      const { allowed } = await AppUpdater.canInstall();
      if (!allowed) { setPhase("permission"); return; }
      setPhase("installing");
      await AppUpdater.install();
    } catch (e) {
      setError((e as Error)?.message || "Não foi possível abrir o instalador.");
      setPhase("error");
    }
  }, []);

  // Voltou das configurações depois de liberar "instalar apps desta fonte": segue direto para o instalador.
  useEffect(() => {
    if (!isNative) return;
    const sub = onAppResume(() => { if (phaseRef.current === "permission") void openInstaller(); });
    return () => { void sub.then((h) => h.remove()); };
  }, [openInstaller]);

  const startDownload = async () => {
    if (!info) return;
    setProgress({ received: 0, percent: 0, total: info.size });
    setPhase("downloading");
    const sub = await AppUpdater.addListener("downloadProgress", (p) => setProgress(p));
    try {
      await AppUpdater.download({ url: info.url, size: info.size });
      await sub.remove();
      await openInstaller();
    } catch (e) {
      await sub.remove();
      const msg = (e as Error)?.message || "";
      if (msg === "cancelled") { setPhase("available"); return; }
      setError(msg || "Falha no download. Verifique sua conexão.");
      setPhase("error");
    }
  };

  const dismiss = () => { if (phaseRef.current !== "downloading") setPhase("idle"); };
  useBackClose(phase !== "idle", dismiss);

  if (!isNative || phase === "idle" || !info) return null;

  const indeterminate = phase === "downloading" && progress.percent < 0;
  const pct = Math.max(0, progress.percent);

  return (
    <div className="upd-backdrop" role="dialog" aria-modal="true" aria-label="Atualização do app">
      <div className="upd-sheet">
        <div className="upd-icon" aria-hidden>⬇</div>

        {phase === "available" && (<>
          <h2>Nova versão disponível</h2>
          <p>O ALXmovies <b>{info.version}</b> está disponível (você está na {info.current}).{info.size ? ` Download de ${mb(info.size)} MB.` : ""}</p>
          <div className="upd-actions">
            <button type="button" className="upd-btn upd-text" onClick={dismiss}>Agora não</button>
            <button type="button" className="upd-btn upd-filled" onClick={startDownload}>Atualizar agora</button>
          </div>
        </>)}

        {phase === "downloading" && (<>
          <h2>Baixando atualização…</h2>
          <div className={`upd-bar ${indeterminate ? "indeterminate" : ""}`}>
            <div className="upd-bar-fill" style={indeterminate ? undefined : { width: `${pct}%` }} />
          </div>
          <p className="upd-sub">
            {indeterminate ? `${mb(progress.received)} MB` : `${pct}% · ${mb(progress.received)} de ${mb(progress.total)} MB`}
          </p>
          <div className="upd-actions">
            <button type="button" className="upd-btn upd-text" onClick={() => void AppUpdater.cancel()}>Cancelar</button>
          </div>
        </>)}

        {phase === "permission" && (<>
          <h2>Permitir instalação</h2>
          <p>Download concluído! Para instalar, o Android precisa que você permita ao ALXmovies instalar atualizações. Toque em permitir, ative a opção e volte para o app.</p>
          <div className="upd-actions">
            <button type="button" className="upd-btn upd-text" onClick={dismiss}>Depois</button>
            <button type="button" className="upd-btn upd-filled" onClick={() => void AppUpdater.openInstallSettings()}>Permitir</button>
          </div>
        </>)}

        {phase === "installing" && (<>
          <h2>Pronto para instalar</h2>
          <p>Confirme a instalação na tela do Android. O app vai reiniciar quando terminar.</p>
          <div className="upd-actions">
            <button type="button" className="upd-btn upd-text" onClick={dismiss}>Fechar</button>
            <button type="button" className="upd-btn upd-filled" onClick={() => void openInstaller()}>Instalar de novo</button>
          </div>
        </>)}

        {phase === "error" && (<>
          <h2>Não deu certo</h2>
          <p>{error}</p>
          <div className="upd-actions">
            <button type="button" className="upd-btn upd-text" onClick={dismiss}>Fechar</button>
            <button type="button" className="upd-btn upd-filled" onClick={startDownload}>Tentar de novo</button>
          </div>
        </>)}
      </div>
    </div>
  );
}

import { useCallback, useEffect, useRef, useState } from "react";
import { isNative, onAppResume } from "@/lib/native";
import { useBackClose } from "@/hooks/useBackClose";
import { AppUpdater, checkForUpdate, type UpdateInfo } from "@/lib/updater";
import { listManagers, openInManager, openManagerStore, savedManager, saveManager, type ManagerInfo } from "@/lib/downloader";

type Phase = "idle" | "available" | "downloading" | "permission" | "installing" | "external" | "error";
type Method = "app" | "adm" | "1dm" | "other";

const IGNORE_KEY = "alx.update.ignored";
const mb = (n: number) => (n / 1048576).toFixed(1).replace(".", ",");
const getIgnored = () => { try { return localStorage.getItem(IGNORE_KEY); } catch { return null; } };

function Ring({ pct, indeterminate }: { pct: number; indeterminate: boolean }) {
  const r = 70, c = 2 * Math.PI * r;
  return (
    <svg className={`upd-ring${indeterminate ? " spin" : ""}`} viewBox="0 0 160 160" aria-hidden>
      <circle cx="80" cy="80" r={r} className="upd-ring-bg" />
      <circle cx="80" cy="80" r={r} className="upd-ring-fg" strokeDasharray={c} strokeDashoffset={indeterminate ? c * 0.72 : c * (1 - pct / 100)} />
    </svg>
  );
}

/** Tela cheia de atualização: novidades, escolha de como baixar (no app, ADM, 1DM), progresso e instalação. */
export function UpdatePrompt() {
  const [phase, setPhase] = useState<Phase>("idle");
  const [info, setInfo] = useState<UpdateInfo | null>(null);
  const [progress, setProgress] = useState({ received: 0, percent: 0, total: 0 });
  const [error, setError] = useState("");
  const [managers, setManagers] = useState<ManagerInfo[]>([]);
  const [method, setMethod] = useState<Method>("app");
  const [remember, setRemember] = useState(false);
  const [notesOpen, setNotesOpen] = useState(false);
  const phaseRef = useRef<Phase>("idle");
  phaseRef.current = phase;

  useEffect(() => {
    if (!isNative) return;
    let alive = true;
    void AppUpdater.cleanup().catch(() => {});
    void checkForUpdate().then((u) => {
      if (!alive || !u || getIgnored() === u.version) return;
      setInfo(u); setPhase("available");
    });
    void listManagers().then((m) => { if (alive) setManagers(m); });
    const saved = savedManager();
    if (saved) { setMethod(saved); setRemember(true); }
    return () => { alive = false; };
  }, []);

  const openInstaller = useCallback(async () => {
    try {
      const { allowed } = await AppUpdater.canInstall();
      if (!allowed) { setPhase("permission"); return; }
      setPhase("installing");
      await AppUpdater.install();
    } catch (e) {
      setError((e as Error)?.message || "Não foi possível abrir o instalador.");
      setPhase("error");
    }
  }, []);

  useEffect(() => {
    if (!isNative) return;
    const sub = onAppResume(() => { if (phaseRef.current === "permission") void openInstaller(); });
    return () => { void sub.then((h) => h.remove()); };
  }, [openInstaller]);

  const downloadInApp = async () => {
    if (!info) return;
    setProgress({ received: 0, percent: 0, total: info.size });
    setPhase("downloading");
    const sub = await AppUpdater.addListener("downloadProgress", (p) => setProgress(p));
    try {
      await AppUpdater.download({ url: info.url, size: info.size });
      await sub.remove();
      await openInstaller();
    } catch (e) {
      await sub.remove();
      const msg = (e as Error)?.message || "";
      if (msg === "cancelled") { setPhase("available"); return; }
      setError(msg || "Falha no download. Verifique sua conexão.");
      setPhase("error");
    }
  };

  const start = async () => {
    if (!info) return;
    saveManager(remember ? method : null);
    if (method === "app") return downloadInApp();
    const m = managers.find((x) => x.id === method);
    if (m && !m.installed) { void openManagerStore(m.id); return; }
    const res = await openInManager(method, info.url, `ALXmovies ${info.version}.apk`);
    if (res === "ok") setPhase("external");
    else { setError(res === "not_installed" ? "Esse gerenciador não está instalado." : "Não foi possível abrir o gerenciador de downloads."); setPhase("error"); }
  };

  const dismiss = () => { if (phaseRef.current !== "downloading") setPhase("idle"); };
  const ignore = () => { if (info) { try { localStorage.setItem(IGNORE_KEY, info.version); } catch { /* sem armazenamento */ } } setPhase("idle"); };
  useBackClose(phase !== "idle", dismiss);

  if (!isNative || phase === "idle" || !info) return null;

  const indeterminate = phase === "downloading" && progress.percent < 0;
  const pct = Math.max(0, progress.percent);
  const notes = info.notes.replace(/[#*`>_]/g, "").trim();
  const opts: { id: Method; name: string; hint: string }[] = [
    { id: "app", name: "Baixar pelo app", hint: "Mais simples: baixa e já abre o instalador" },
    ...(["adm", "1dm"] as const).map((id) => {
      const m = managers.find((x) => x.id === id);
      return { id, name: id === "adm" ? "ADM" : "1DM", hint: m?.installed === false ? "Não instalado — toque em Baixar para instalar" : "Baixar com o gerenciador de downloads" };
    }),
    { id: "other", name: "Outro aplicativo", hint: "Escolher na lista do Android" },
  ];

  return (
    <div className="upd-full" role="dialog" aria-modal="true" aria-label="Atualização do app">
      <div className="upd-scroll">
        {phase === "available" && (<>
          <div className="upd-hero">
            <div className="upd-badge" aria-hidden>⬆</div>
            <h1>Nova versão disponível</h1>
            <div className="upd-vers"><span>{info.current}</span><i>→</i><b>{info.version}</b></div>
            {info.size > 0 && <small>{mb(info.size)} MB</small>}
          </div>

          {notes && (
            <section className="upd-card">
              <h3>Novidades</h3>
              <p className={`upd-notes${notesOpen ? " open" : ""}`}>{notes}</p>
              {notes.length > 140 && <button type="button" className="upd-link" onClick={() => setNotesOpen((v) => !v)}>{notesOpen ? "Ver menos" : "Ver mais"}</button>}
            </section>
          )}

          <section className="upd-card">
            <h3>Como baixar</h3>
            {opts.map((o) => (
              <label key={o.id} className={`upd-opt${method === o.id ? " on" : ""}`}>
                <input type="radio" name="upd-method" checked={method === o.id} onChange={() => setMethod(o.id)} />
                <span className="upd-dot" />
                <span className="upd-opt-t"><b>{o.name}</b><small>{o.hint}</small></span>
              </label>
            ))}
            <label className="upd-check">
              <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
              <span>Lembrar minha escolha</span>
            </label>
          </section>
        </>)}

        {phase === "downloading" && (
          <div className="upd-center">
            <div className="upd-ring-wrap">
              <Ring pct={pct} indeterminate={indeterminate} />
              <strong>{indeterminate ? "…" : `${pct}%`}</strong>
            </div>
            <h1>Baixando atualização</h1>
            <p>{indeterminate ? `${mb(progress.received)} MB` : `${mb(progress.received)} de ${mb(progress.total)} MB`}</p>
          </div>
        )}

        {phase === "permission" && (
          <div className="upd-center">
            <div className="upd-badge" aria-hidden>🔓</div>
            <h1>Permitir instalação</h1>
            <p>Download concluído! Para instalar, o Android precisa que você permita ao ALXmovies instalar atualizações. Toque em permitir, ative a opção e volte para o app.</p>
          </div>
        )}

        {phase === "installing" && (
          <div className="upd-center">
            <div className="upd-badge" aria-hidden>✓</div>
            <h1>Pronto para instalar</h1>
            <p>Confirme a instalação na tela do Android. O app reinicia quando terminar.</p>
          </div>
        )}

        {phase === "external" && (
          <div className="upd-center">
            <div className="upd-badge" aria-hidden>⬇</div>
            <h1>Download iniciado</h1>
            <p>Termine o download no gerenciador, abra o arquivo baixado e confirme a instalação. Se o Android pedir, permita instalar apps desta fonte.</p>
          </div>
        )}

        {phase === "error" && (
          <div className="upd-center">
            <div className="upd-badge err" aria-hidden>!</div>
            <h1>Não deu certo</h1>
            <p>{error}</p>
          </div>
        )}
      </div>

      <div className="upd-foot">
        {phase === "available" && (<>
          <button type="button" className="upd-btn upd-filled" onClick={() => void start()}>Baixar e atualizar</button>
          <div className="upd-foot-row">
            <button type="button" className="upd-btn upd-text" onClick={dismiss}>Agora não</button>
            <button type="button" className="upd-btn upd-text" onClick={ignore}>Ignorar esta versão</button>
          </div>
        </>)}
        {phase === "downloading" && <button type="button" className="upd-btn upd-tonal" onClick={() => void AppUpdater.cancel()}>Cancelar</button>}
        {phase === "permission" && (<>
          <button type="button" className="upd-btn upd-filled" onClick={() => void AppUpdater.openInstallSettings()}>Permitir</button>
          <button type="button" className="upd-btn upd-text" onClick={dismiss}>Depois</button>
        </>)}
        {phase === "installing" && (<>
          <button type="button" className="upd-btn upd-filled" onClick={() => void openInstaller()}>Instalar de novo</button>
          <button type="button" className="upd-btn upd-text" onClick={dismiss}>Fechar</button>
        </>)}
        {phase === "external" && (<>
          <button type="button" className="upd-btn upd-filled" onClick={() => void AppUpdater.openInstallSettings()}>Permitir instalação</button>
          <button type="button" className="upd-btn upd-text" onClick={dismiss}>Fechar</button>
        </>)}
        {phase === "error" && (<>
          <button type="button" className="upd-btn upd-filled" onClick={() => setPhase("available")}>Tentar de novo</button>
          <button type="button" className="upd-btn upd-text" onClick={dismiss}>Fechar</button>
        </>)}
      </div>
    </div>
  );
}

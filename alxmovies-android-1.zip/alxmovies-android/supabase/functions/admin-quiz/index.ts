// Edge Function "admin-quiz": teste para virar admin.
// Perguntas aleatórias geradas por IA (Gemini, do Google) e CONFERIDAS por uma segunda chamada: só entram as perguntas em que a IA,
// ao responder sem ver o gabarito, chega na mesma resposta. Se a IA estiver fora do ar ou sem chave, completa com um banco de perguntas
// escritas à mão. A correção é feita AQUI, no servidor: as respostas certas nunca vão para o celular/navegador.
//
// Segredos (Supabase → Edge Functions → Secrets):
//   GEMINI_API_KEY  (chave grátis em aistudio.google.com → Get API key)
//   QUIZ_MODEL      (opcional; padrão: tenta gemini-flash-latest e depois gemini-2.5-flash)
// "Verify JWT" pode ficar LIGADO (padrão). Chamado pelo site com a sessão da pessoa.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SB_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const AI_KEY = Deno.env.get("GEMINI_API_KEY") ?? "";
const MODELS = [...new Set([Deno.env.get("QUIZ_MODEL"), "gemini-flash-latest", "gemini-2.5-flash"].filter((m): m is string => !!m))];
const db = createClient(SB_URL, SERVICE, { auth: { persistSession: false } });

const TOTAL = 12;          // perguntas por teste
const PASS = 10;           // acertos para passar (≈83%)
const MINUTES = 20;        // tempo para responder
const MAX_PER_DAY = 3;     // tentativas em 24 h
const COOLDOWN_MIN = 30;   // espera depois de reprovar

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
const json = (b: unknown, status = 200) => new Response(JSON.stringify(b), { status, headers: { ...cors, "Content-Type": "application/json" } });

interface Q { q: string; options: string[]; answer: number }

// ---------------------------------------------------------------- banco de perguntas (reserva)
// Todas as alternativas são plausíveis e de tamanho parecido; a correta aparece em posições variadas (e ainda é embaralhada).
const BANK: Q[] = [
  { q: "Dois usuários se acusam de ofensas e você só recebeu o print de um deles. Qual é a conduta mais justa?", options: ["Punir quem enviou o print, já que trouxe provas", "Pedir o contexto e as provas dos dois lados e olhar o histórico antes de decidir", "Punir os dois igualmente para evitar favorecimento", "Esperar que resolvam sozinhos e só agir se piorar"], answer: 1 },
  { q: "Um amigo seu, também admin, publicou o mesmo link de divulgação várias vezes. O que você faz?", options: ["Conversa em particular e deixa passar desta vez", "Remove as publicações sem avisar ninguém para evitar constrangimento", "Segue o mesmo processo de qualquer pessoa e avisa o dono", "Tira as permissões dele por conta própria"], answer: 2 },
  { q: "Uma criança diz ter 12 anos e pede para liberar conteúdo adulto no perfil dela. A resposta mais adequada é:", options: ["Liberar se ela garantir que os pais permitem", "Pedir um documento para confirmar a idade", "Liberar por uma semana como teste", "Explicar que o perfil infantil segue a classificação indicativa e que mudanças dependem do responsável pela conta"], answer: 3 },
  { q: "Uma mensagem da 'equipe de suporte' pede que usuários instalem um APK de um link externo para 'corrigir o app'. O mais correto é:", options: ["Instalar no seu celular primeiro para testar", "Orientar a instalar só pelo link oficial do site e avisar o dono sobre a mensagem", "Responder que é seguro se alguém conhecido enviou", "Ignorar, pois cada um decide o que instala"], answer: 1 },
  { q: "Um desconhecido envia a você uma planilha com e-mails de usuários 'para ajudar a equipe'. A melhor atitude é:", options: ["Abrir e conferir quais e-mails estão corretos", "Encaminhar aos outros admins para conferirem juntos", "Não abrir nem repassar, e avisar o dono para avaliar um possível vazamento", "Guardar a planilha caso seja útil depois"], answer: 2 },
  { q: "Um usuário punido pergunta quem o denunciou. Como responder?", options: ["Revelar, por transparência", "Dizer só o primeiro nome do denunciante", "Revelar se ele prometer que não vai retaliar", "Manter o sigilo de quem denuncia e explicar o motivo da medida"], answer: 3 },
  { q: "Qual título de aviso comunica melhor uma manutenção programada?", options: ["URGENTE!!! O APP VAI CAIR", "Manutenção hoje às 23h: o app pode ficar instável por cerca de 1 hora", "Atenção: algo vai acontecer no app", "Não usem o app hoje"], answer: 1 },
  { q: "Um usuário diz que sua conta foi invadida. Qual primeira orientação é mais útil e segura?", options: ["Criar outra conta e esquecer a antiga", "Enviar a senha antiga a um admin para investigar", "Trocar a senha por uma longa e única, revisar onde mais usava a mesma senha e avisar o suporte", "Esperar alguns dias para ver se o problema some"], answer: 2 },
  { q: "Alguém escreve um palavrão uma única vez, sem atacar ninguém. Qual resposta é proporcional?", options: ["Banir permanentemente", "Orientar com educação e só advertir se a pessoa repetir", "Ignorar sempre, qualquer que seja o caso", "Expor a pessoa publicamente como exemplo"], answer: 1 },
  { q: "Um usuário pede uma cópia dos dados que o app guarda sobre ele. O que fazer?", options: ["Recusar, pois os dados pertencem ao app", "Enviar a qualquer pessoa que informe o e-mail da conta", "Confirmar que é o dono da conta e encaminhar ao dono do app para atender o pedido", "Cobrar uma taxa pelo trabalho"], answer: 2 },
  { q: "Você prometeu um plano grátis a um conhecido, 'porque é seu amigo'. Qual avaliação é correta?", options: ["Tudo bem, é uma decisão sua como admin", "Não é correto: benefícios seguem regras iguais para todos, e favores pessoais criam injustiça", "É aceitável se for por pouco tempo", "É aceitável se ninguém ficar sabendo"], answer: 1 },
  { q: "Uma publicação traz uma opinião política forte, mas sem ofensas, spam ou incitação. Você deve:", options: ["Apagar, porque discorda da opinião", "Banir o autor para evitar discussões", "Manter, e só agir se houver ofensa, spam ou discurso de ódio", "Responder criticando o autor publicamente"], answer: 2 },
  { q: "Cinco denúncias contra a mesma pessoa chegam de contas criadas no mesmo dia. Qual é o raciocínio mais prudente?", options: ["Punir de imediato, pois são várias denúncias", "Considerar a chance de um ataque combinado e analisar as provas antes de decidir", "Ignorar denúncias de contas novas para sempre", "Divulgar o nome dos denunciantes"], answer: 1 },
  { q: "Quando é mais importante consultar o dono antes de agir?", options: ["Em qualquer mensagem de usuário", "Em ações difíceis de desfazer, como remover uma conta com muitos dados", "Só quando o usuário pedir", "Nunca; admins decidem tudo sozinhos"], answer: 1 },
  { q: "Você recebe um link para o 'painel de admin' e uma mensagem pedindo para fazer login ali. Qual cuidado é essencial?", options: ["Entrar se a página parecer igual à oficial", "Conferir o endereço e abrir o site oficial digitando você mesmo o endereço", "Entrar e trocar a senha logo depois", "Enviar a senha a alguém para checar se é segura"], answer: 1 },
  { q: "Um usuário manda um print pedindo ajuda, e nele aparecem dados de outras pessoas. Qual conduta protege a privacidade?", options: ["Repostar o print para pedir opinião de outros admins", "Usar o print só para o suporte e pedir que ele oculte os dados de terceiros nas próximas vezes", "Guardar o print em uma pasta pessoal por precaução", "Mostrar o print a amigos para entender o problema"], answer: 1 },
  { q: "Uma criança relata ter visto no perfil infantil um filme que parece inadequado. A melhor conduta é:", options: ["Dizer que isso é normal", "Anotar o título e a situação, tirar do alcance se possível e avisar o dono para revisar a classificação", "Pedir à criança que não conte a ninguém", "Pedir a senha do responsável pela conta"], answer: 1 },
  { q: "Um usuário muito conhecido pede para não ser punido por uma infração clara. Qual postura é a certa?", options: ["Dar uma exceção por causa da influência", "Aplicar a mesma regra e o mesmo procedimento que se aplicaria a qualquer pessoa", "Punir com mais rigor para parecer imparcial", "Adiar a decisão até ele esquecer"], answer: 1 },
  { q: "Você apagou um conteúdo por engano. O que fazer?", options: ["Esconder o erro para evitar problemas", "Restaurar se possível, avisar o afetado e o dono, e ajustar o processo para não repetir", "Dizer que foi uma falha do app", "Apagar o histórico de ações"], answer: 1 },
  { q: "Alguém oferece dinheiro para virar admin sem passar pelo teste. Você deve:", options: ["Aceitar, se o valor for justo", "Recusar e avisar o dono: o cargo não se compra e a oferta é um sinal de alerta", "Aceitar e dividir o valor com a equipe", "Cobrar mais e negociar"], answer: 1 },
  { q: "O dono comentou que os planos vão mudar na semana que vem, mas ainda é segredo. Um amigo pergunta se é verdade. O ideal é:", options: ["Contar só a esse amigo, pois ele é de confiança", "Dar uma pista sem confirmar", "Dizer que não pode comentar antes do anúncio oficial", "Postar um enigma sobre o assunto"], answer: 2 },
  { q: "Chega um SMS dizendo ser do 'suporte' e pedindo o código de verificação que acabou de chegar. Qual é a atitude correta?", options: ["Enviar, pois só o suporte conhece esse código", "Nunca compartilhar códigos de verificação com ninguém, mesmo que pareça uma equipe oficial", "Enviar só metade do código", "Enviar e trocar a senha depois"], answer: 1 },
  { q: "Um usuário envia o mesmo link de divulgação para 30 pessoas. Qual é a resposta mais coerente?", options: ["Remover as mensagens, avisar a pessoa e restringir se ela repetir", "Banir na primeira vez, sem aviso", "Ignorar, porque ninguém reclamou", "Responder a todas as mensagens dele"], answer: 0 },
  { q: "Por curiosidade, você quer ler uma conversa privada de dois usuários. O que está certo?", options: ["Ler, afinal admins têm acesso a tudo", "Só acessar dados privados quando for realmente necessário para resolver um caso e dentro do que foi autorizado", "Ler e contar aos amigos só os trechos engraçados", "Ler apenas conversas de pessoas que você não gosta"], answer: 1 },
  { q: "Um usuário exige que outro seja banido 'agora', ameaçando falar mal do app. Qual postura é a melhor?", options: ["Ceder para evitar a má fama", "Manter a calma, verificar os fatos e escalar ao dono se houver ameaça real", "Banir os dois por garantia", "Responder à ameaça com outra ameaça"], answer: 1 },
  { q: "Ao anunciar uma função nova, qual aviso é o mais eficaz?", options: ["Linguagem técnica e detalhada de como foi programada", "Explicar em poucas linhas, em linguagem simples, o que mudou e como isso ajuda quem usa", "Só uma frase: 'Atualizem o app'", "Um texto muito longo com todas as mudanças internas"], answer: 1 },
  { q: "Um usuário apagou os dados do app e perdeu os vídeos que tinha baixado. Qual explicação está correta?", options: ["Os vídeos ficam guardados na área do app no celular, e limpar os dados do app ou desinstalar apaga esses arquivos", "Os vídeos ficam na nuvem e voltam sozinhos", "Os vídeos só são apagados se ele estiver sem internet", "Os vídeos nunca são apagados por nada"], answer: 0 },
  { q: "No plano Grátis, o usuário reclama dos anúncios e do limite de downloads. Qual resposta está de acordo com o app?", options: ["O plano Grátis é ilimitado e sem anúncios", "O plano Grátis tem anúncios e limite mensal; planos pagos ou prêmios oferecem mais downloads e sem anúncios", "Anúncios só aparecem para admins", "O limite de downloads vale apenas para quem usa Wi-Fi"], answer: 1 },
  { q: "Um admin percebe que errou ao advertir alguém injustamente. O melhor caminho é:", options: ["Manter a advertência para não perder autoridade", "Reconhecer o erro, desfazer a medida e pedir desculpas objetivas", "Apagar as mensagens da pessoa", "Culpar outro admin"], answer: 1 },
];

// ---------------------------------------------------------------- utilidades
const shuffle = <T,>(a: T[]): T[] => { const x = a.slice(); for (let i = x.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [x[i], x[j]] = [x[j], x[i]]; } return x; };

/** Embaralha as alternativas (a resposta certa muda de posição) e devolve a nova posição dela. */
function shuffleOptions(q: Q): Q {
  const idx = shuffle([0, 1, 2, 3]);
  return { q: q.q, options: idx.map((i) => q.options[i]), answer: idx.indexOf(q.answer) };
}

function valid(x: any): x is Q {
  return x && typeof x.q === "string" && x.q.length >= 10 && x.q.length <= 400
    && Array.isArray(x.options) && x.options.length === 4 && x.options.every((o: unknown) => typeof o === "string" && o.length > 0 && o.length <= 200)
    && new Set(x.options.map((o: string) => o.trim().toLowerCase())).size === 4
    && Number.isInteger(x.answer) && x.answer >= 0 && x.answer <= 3;
}

/** Chama o Gemini pedindo JSON. Tenta cada modelo da lista até um responder. */
async function gemini(prompt: string, temperature: number): Promise<string> {
  if (!AI_KEY) return "";
  for (const model of MODELS) {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 35000);
    try {
      const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
        method: "POST", signal: ctrl.signal,
        headers: { "x-goog-api-key": AI_KEY, "content-type": "application/json" },
        body: JSON.stringify({
          contents: [{ role: "user", parts: [{ text: prompt }] }],
          generationConfig: { temperature, maxOutputTokens: 8192, responseMimeType: "application/json" },
        }),
      });
      if (!res.ok) { console.error("gemini", model, res.status, (await res.text()).slice(0, 200)); continue; }
      const data = await res.json();
      const text = ((data?.candidates?.[0]?.content?.parts ?? []) as { text?: string }[]).map((p) => p?.text ?? "").join("");
      if (text) return text;
    } catch (e) { console.error("gemini erro", model, String(e)); } finally { clearTimeout(t); }
  }
  return "";
}

function parseArray(text: string): unknown[] {
  try { const v = JSON.parse(text); if (Array.isArray(v)) return v; } catch { /* tenta recortar */ }
  const s = text.indexOf("["), e = text.lastIndexOf("]");
  if (s < 0 || e < s) return [];
  try { const v = JSON.parse(text.slice(s, e + 1)); return Array.isArray(v) ? v : []; } catch { return []; }
}

/** Pede ao Gemini perguntas difíceis; depois o próprio Gemini as responde SEM ver o gabarito e descartamos as que não batem (ambíguas ou erradas). */
async function aiQuestions(): Promise<Q[]> {
  if (!AI_KEY) return [];
  const want = TOTAL + 6; // gera a mais porque algumas serão descartadas na conferência
  const seed = Math.random().toString(36).slice(2, 8);
  const raw = await gemini(
`Crie ${want} perguntas de múltipla escolha, em português do Brasil, para selecionar voluntários que vão ajudar a equipe de um aplicativo de filmes e séries (ALXmovies) com moderação, suporte e comunicação com os usuários.
NÍVEL: MÉDIO A DIFÍCIL. Cada pergunta é uma situação prática ou dilema em que DUAS ou TRÊS alternativas parecem razoáveis e só uma é a MELHOR conduta, por um motivo claro (proporcionalidade, imparcialidade, privacidade, segurança de menores, sigilo, prudência, comunicação).
Temas (misture): julgar denúncias com provas incompletas, conflito de interesses, ataques combinados e falsas denúncias, privacidade e LGPD, perfis infantis e classificação indicativa, golpes/phishing/engenharia social, vazamentos, sigilo de decisões internas, punição proporcional, reconhecer e corrigir erros, comunicação clara de avisos, pressão de usuários, uso responsável de poderes de admin, segurança de contas.
REGRAS OBRIGATÓRIAS:
- Exatamente 4 alternativas por pergunta, todas plausíveis, com TAMANHO PARECIDO e mesmo tom de educação. A correta NÃO pode ser a mais longa, nem a única "cuidadosa", nem a única que usa palavras como "avisar" ou "verificar".
- Nada de "todas as anteriores", "nenhuma das anteriores", nem pegadinhas de palavras. Só uma resposta defensável como a melhor.
- Não repita temas nem situações. Não cite pessoas reais. Distribua a posição da correta entre 0, 1, 2 e 3. Variação: ${seed}.
Responda SOMENTE com JSON, neste formato: [{"q":"pergunta","options":["A","B","C","D"],"answer":0}]  (answer = índice 0 a 3 da alternativa correta)`, 1);
  const cand = (parseArray(raw).filter(valid) as Q[]).slice(0, want);
  if (cand.length < 4) return [];

  // conferência independente: o modelo responde sem ver o gabarito
  const shuffled = cand.map(shuffleOptions);
  const check = await gemini(
`Responda cada pergunta abaixo escolhendo a MELHOR alternativa (índice de 0 a 3). Seja criterioso.
Responda SOMENTE com um array JSON de números, um por pergunta, na mesma ordem. Exemplo: [2,0,1]
${JSON.stringify(shuffled.map((x) => ({ q: x.q, options: x.options })))}`, 0);
  const picks = parseArray(check);
  if (picks.length !== shuffled.length) return [];
  return shuffled.filter((x, i) => picks[i] === x.answer);
}

async function makeQuestions(): Promise<{ list: Q[]; source: string }> {
  const ai = (await aiQuestions()).slice(0, TOTAL);
  const list = ai.slice();
  if (list.length < TOTAL) {
    const used = new Set(list.map((x) => x.q));
    for (const b of shuffle(BANK).map(shuffleOptions)) { if (list.length >= TOTAL) break; if (!used.has(b.q)) list.push(b); }
  }
  return { list: shuffle(list), source: ai.length >= TOTAL ? "ia" : ai.length ? "mista" : "banco" };
}

const publicQuestions = (qs: Q[]) => qs.map((x) => ({ q: x.q, options: x.options }));

// ---------------------------------------------------------------- ações
async function isStaff(uid: string) {
  const { data } = await db.from("app_staff").select("user_id").eq("user_id", uid).maybeSingle();
  return !!data;
}

async function status(uid: string) {
  if (await isStaff(uid)) return { state: "already" };
  const { data: owner } = await db.from("app_admins").select("user_id").eq("user_id", uid).maybeSingle();
  if (owner) return { state: "already" };
  const since = new Date(Date.now() - 24 * 3600 * 1000).toISOString();
  const { data } = await db.from("quiz_attempts").select("created_at, finished_at, passed").eq("user_id", uid).gte("created_at", since).order("created_at", { ascending: false });
  const rows = data ?? [];
  const last = rows[0];
  if (rows.length >= MAX_PER_DAY && !(last && !last.finished_at)) {
    const oldest = new Date(rows[rows.length - 1].created_at).getTime();
    return { state: "limit", retryAt: new Date(oldest + 24 * 3600 * 1000).toISOString() };
  }
  if (last?.finished_at && last.passed === false) {
    const at = new Date(last.finished_at).getTime() + COOLDOWN_MIN * 60000;
    if (at > Date.now()) return { state: "cooldown", retryAt: new Date(at).toISOString() };
  }
  return { state: "ready", total: TOTAL, pass: PASS, minutes: MINUTES, maxPerDay: MAX_PER_DAY, left: MAX_PER_DAY - rows.length };
}

async function start(uid: string) {
  if (await isStaff(uid)) return { state: "already" };
  // tentativa aberta e ainda válida: continua a mesma (sem sortear perguntas novas)
  const { data: open } = await db.from("quiz_attempts").select("*").eq("user_id", uid).is("finished_at", null).gt("expires_at", new Date().toISOString()).order("created_at", { ascending: false }).limit(1).maybeSingle();
  if (open) return { state: "running", attemptId: open.id, expiresAt: open.expires_at, questions: publicQuestions(open.questions as Q[]) };
  const st = await status(uid) as any;
  if (st.state !== "ready") return st;
  // se havia uma tentativa vencida sem envio, ela já conta e é encerrada
  await db.from("quiz_attempts").update({ finished_at: new Date().toISOString(), score: 0, passed: false }).eq("user_id", uid).is("finished_at", null).lte("expires_at", new Date().toISOString());
  const { list, source } = await makeQuestions();
  const expires = new Date(Date.now() + MINUTES * 60000).toISOString();
  const { data, error } = await db.from("quiz_attempts").insert({ user_id: uid, questions: list, expires_at: expires }).select("id").single();
  if (error) throw error;
  console.log("quiz iniciado", uid, source);
  return { state: "running", attemptId: data.id, expiresAt: expires, questions: publicQuestions(list) };
}

async function submit(uid: string, body: any) {
  const { data: at } = await db.from("quiz_attempts").select("*").eq("id", String(body.attemptId ?? "")).eq("user_id", uid).maybeSingle();
  if (!at || at.finished_at) return { state: "invalid" };
  const qs = at.questions as Q[];
  const answers: unknown[] = Array.isArray(body.answers) ? body.answers : [];
  const expired = new Date(at.expires_at).getTime() + 15000 < Date.now();   // 15 s de folga para a internet
  const score = expired ? 0 : qs.reduce((n, q, i) => n + (answers[i] === q.answer ? 1 : 0), 0);
  const passed = !expired && score >= PASS;
  const { data: upd } = await db.from("quiz_attempts").update({ finished_at: new Date().toISOString(), score, passed }).eq("id", at.id).is("finished_at", null).select("id");
  if (!upd?.length) return { state: "invalid" };
  if (expired) return { state: "expired" };
  if (passed) await db.from("app_staff").upsert({ user_id: uid, granted_via: "quiz" }, { onConflict: "user_id", ignoreDuplicates: true });
  return { state: "done", score, total: qs.length, passed, pass: PASS };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const token = (req.headers.get("Authorization") ?? "").replace(/^Bearer\s+/i, "");
    const { data, error } = await db.auth.getUser(token);
    if (error || !data.user || data.user.is_anonymous) return json({ state: "login" });
    const uid = data.user.id;
    const body = await req.json().catch(() => ({}));
    if (body.action === "status") return json(await status(uid));
    if (body.action === "start") return json(await start(uid));
    if (body.action === "submit") return json(await submit(uid, body));
    return json({ state: "invalid" }, 400);
  } catch (e) {
    console.error(e);
    return json({ state: "error" }, 500);
  }
});

## Novo
- Downloads dentro do app: baixe filmes e episódios, acompanhe o progresso na aba Downloads e assista sem internet
- Planos Grátis, Apoiador, Premium e Família, cada um com um limite mensal de downloads
- O plano Grátis tem anúncios; assistindo um anúncio você ganha +1 download
- Roda da Sorte no site: entre na sua conta, gire uma vez por dia e ganhe downloads extras ou um plano por alguns dias
## Melhorado
- A aba Downloads agora fica na barra inferior no lugar da Busca (a busca continua no topo)
- A tela de atualização mostra a lista real de novidades de cada versão
## Corrigido
- Versões numeradas de forma organizada: 1.1.0, 1.1.1, 1.1.2 e assim por diante

## Novo
- Velocidade dos downloads: escolha entre Econômico, Rápido e Máximo na aba Downloads
## Melhorado
- Downloads bem mais rápidos: o app usa várias conexões ao mesmo tempo e reaproveita as conexões abertas
- Se o servidor reclamar de muitas conexões, o app diminui o ritmo sozinho e continua baixando
## Corrigido
- Configuração dos anúncios: o modo de teste agora respeita o que está definido no GitHub

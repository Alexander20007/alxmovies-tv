## Novo
- Modo offline: sem internet o app abre direto nos seus downloads e você assiste o que baixou, como no YouTube
- Avisos da equipe: comunicados importantes aparecem na barra de notificações do celular e na tela Notificações do app
## Melhorado
- A lista de downloads mostra as capas mesmo sem internet
## Corrigido
- O app não fica mais preso carregando quando o Wi-Fi está sem internet

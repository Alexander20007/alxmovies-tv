import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useSearchParams } from "react-router-dom";
import { posterUrl, tmdb } from "@/services/tmdb";
import { DownloadButton, Footer, Nav } from "./Chrome";
import { APP_FINGERPRINT, useRelease } from "./release";

const FEATURES: { icon: string; title: string; text: string }[] = [
  { icon: "🎬", title: "Filmes e séries", text: "Catálogo sempre atualizado, com detalhes, elenco, trailer e a opção de continuar de onde parou." },
  { icon: "▶️", title: "Player nativo", text: "Reprodução fluida com ExoPlayer: qualidade, legendas, velocidade, gestos de brilho e volume e tela flutuante." },
  { icon: "📡", title: "TV ao vivo", text: "Canais com verificação de sinal (no ar ou offline) e programação do que está passando agora e a seguir." },
  { icon: "👥", title: "Salas para assistir junto", text: "Todo mundo vê o mesmo vídeo no mesmo momento, com chat, reações e fila de filmes." },
  { icon: "✨", title: "Laura IA", text: "Uma assistente que recomenda e abre filmes, séries e canais — por texto ou por voz." },
  { icon: "⬇️", title: "Downloads", text: "Baixe para ver depois com o 1DM ou o ADM, direto do app e já com o nome do arquivo." },
  { icon: "🛡️", title: "Perfis e controle parental", text: "Cada pessoa com o seu perfil e a classificação indicativa liberada para cada um." },
  { icon: "💬", title: "Amigos e mensagens", text: "Converse, adicione amigos e receba notificações das conversas na barra do celular." },
  { icon: "⭐", title: "Sua lista e avaliações", text: "Salve o que quer ver, marque como visto e diga o que achou: gostei, amei ou não gostei." },
  { icon: "🔗", title: "Links que abrem o app", text: "Compartilhou um filme, canal ou sala? Quem tem o app abre direto na mesma tela." },
  { icon: "🔔", title: "Avisos de novidades", text: "O app avisa quando existe versão nova e atualiza em poucos toques." },
  { icon: "🎞️", title: "Trailers e informações", text: "Veja o trailer, o elenco e a filmografia de cada pessoa sem sair do app." },
];

const STEPS = [
  { t: "Baixe o arquivo", d: "Toque em “Baixar o app” e aguarde o ALXmovies.apk terminar de baixar." },
  { t: "Abra o arquivo", d: "Abra o download pelo aviso do navegador ou pelo app Arquivos. Se o Android pedir, ative “Permitir desta fonte”." },
  { t: "Instale", d: "Toque em Instalar. O Android pode avisar que o app não veio da Play Store — é normal para apps instalados por APK." },
  { t: "Entre e aproveite", d: "Abra o ALXmovies, crie sua conta ou entre e pronto. As próximas atualizações são avisadas dentro do app." },
];

const FAQ = [
  { q: "O app é gratuito?", a: "Sim. Você baixa e usa o ALXmovies sem pagar nada." },
  { q: "Por que o site não tem os filmes?", a: "O site é só informativo e de download. Tudo o que você assiste — filmes, séries, canais e salas — fica no aplicativo." },
  { q: "Funciona no iPhone?", a: "Por enquanto só em celulares Android. Abra este site no seu Android para baixar." },
  { q: "É seguro instalar?", a: "O APK é assinado com a chave oficial do ALXmovies. Na seção de segurança abaixo você confere a assinatura e compara com o certificado do arquivo." },
  { q: "Como atualizo o app?", a: "O próprio app avisa quando há uma versão nova (também por notificação) e atualiza sem você precisar voltar aqui." },
  { q: "A instalação não abriu, e agora?", a: "Confirme que você permitiu instalar apps desta fonte (Configurações › Segurança ou Apps) e tente abrir o arquivo de novo. Se baixou pela barra de notificações, abra por lá." },
];

const fmtDate = (iso: string) => (iso ? new Date(iso).toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" }) : "");

function PhoneWall() {
  const trending = useQuery({ queryKey: ["web-trending"], queryFn: () => tmdb.trending("movie", "week"), staleTime: 30 * 60_000, retry: 0 });
  const posters = (trending.data?.results ?? []).filter((m) => m.poster_path).slice(0, 18);
  const cols = [0, 1, 2].map((c) => posters.filter((_, i) => i % 3 === c));
  return (
    <div className="wb-phone" aria-hidden>
      <div className="wb-phone-top"><b>ALXMOVIES</b><i /><i /></div>
      <div className="wb-wall">
        {cols.map((col, ci) => (
          <div key={ci} className={`wb-col c${ci}`}>
            {[...col, ...col].map((m, i) => <img key={`${m.id}-${i}`} src={posterUrl(m.poster_path, "w300")} alt="" loading="lazy" />)}
            {!col.length && Array.from({ length: 6 }, (_, i) => <span key={i} className="wb-tile" />)}
          </div>
        ))}
      </div>
      <div className="wb-phone-nav"><i /><i /><i /><i /><i /></div>
    </div>
  );
}

export default function Landing() {
  const { info } = useRelease();
  const [params] = useSearchParams();
  const [open, setOpen] = useState<number | null>(0);
  const [copied, setCopied] = useState(false);
  useEffect(() => { document.title = "ALXmovies — Filmes, séries e TV ao vivo no seu celular"; }, []);

  const copyFp = async () => {
    try { await navigator.clipboard.writeText(APP_FINGERPRINT); setCopied(true); setTimeout(() => setCopied(false), 2000); } catch { /* sem permissão */ }
  };

  return (
    <div className="wb">
      <Nav />
      {params.get("reset") === "ok" && <div className="wb-banner ok">Senha alterada com sucesso! Abra o app do ALXmovies e entre com a nova senha.</div>}

      <section className="wb-hero">
        <div className="wb-glow" aria-hidden />
        <div className="wb-hero-txt">
          <span className="wb-pill">Para Android · Grátis</span>
          <h1>Filmes, séries e <span>TV ao vivo</span> no seu celular</h1>
          <p>Um só app para assistir, salvar sua lista, conversar com amigos e ver junto em salas. Baixe o ALXmovies e comece agora.</p>
          <div className="wb-cta"><DownloadButton big /></div>
          <ul className="wb-meta">
            {info?.version && <li>Versão <b>{info.version}</b></li>}
            {info?.date && <li>Atualizado em <b>{fmtDate(info.date)}</b></li>}
            {info && info.downloads > 0 && <li><b>{info.downloads.toLocaleString("pt-BR")}</b> downloads</li>}
          </ul>
        </div>
        <PhoneWall />
      </section>

      <section className="wb-sec" id="recursos">
        <h2>Tudo o que o app faz por você</h2>
        <p className="wb-sub">O site é só vitrine. A diversão toda acontece no aplicativo.</p>
        <div className="wb-grid">
          {FEATURES.map((f) => (
            <article key={f.title} className="wb-card"><span>{f.icon}</span><h3>{f.title}</h3><p>{f.text}</p></article>
          ))}
        </div>
      </section>

      {info && info.notes.length > 0 && (
        <section className="wb-sec narrow">
          <h2>Novidades da versão {info.version}</h2>
          <ul className="wb-notes">{info.notes.map((n, i) => <li key={i}>{n}</li>)}</ul>
        </section>
      )}

      <section className="wb-sec" id="instalar">
        <h2>Como instalar</h2>
        <p className="wb-sub">Leva menos de um minuto.</p>
        <ol className="wb-steps">
          {STEPS.map((s, i) => <li key={s.t}><span>{i + 1}</span><div><h3>{s.t}</h3><p>{s.d}</p></div></li>)}
        </ol>
        <div className="wb-cta center"><DownloadButton big /></div>
      </section>

      <section className="wb-sec narrow">
        <div className="wb-secure">
          <h2>🔐 Assinatura oficial do app</h2>
          <p>O APK do ALXmovies é assinado com a nossa chave. Se quiser conferir, a impressão digital (SHA-256) do certificado é:</p>
          <code>{APP_FINGERPRINT}</code>
          <button type="button" className="wb-btn" onClick={() => void copyFp()}>{copied ? "Copiado!" : "Copiar assinatura"}</button>
        </div>
      </section>

      <section className="wb-sec narrow" id="faq">
        <h2>Dúvidas frequentes</h2>
        <div className="wb-faq">
          {FAQ.map((f, i) => (
            <div key={f.q} className={`wb-q${open === i ? " open" : ""}`}>
              <button type="button" onClick={() => setOpen(open === i ? null : i)} aria-expanded={open === i}><span>{f.q}</span><i /></button>
              {open === i && <p>{f.a}</p>}
            </div>
          ))}
        </div>
      </section>

      <section className="wb-final">
        <h2>Pronto para assistir?</h2>
        <p>Baixe o ALXmovies e tenha tudo na palma da mão.</p>
        <DownloadButton big />
      </section>
      <Footer />
    </div>
  );
}

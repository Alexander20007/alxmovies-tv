import { lazy, Suspense } from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import Landing from "./Landing";
import ShareLanding from "./ShareLanding";

const Privacy = lazy(() => import("@/pages/Privacy"));
const Cookies = lazy(() => import("@/pages/Cookies"));
const Security = lazy(() => import("@/pages/Security"));
const ResetPassword = lazy(() => import("@/pages/ResetPassword"));

/** Site: só informação e download do app. Sem login e sem player. */
export default function WebApp() {
  return (
    <Suspense fallback={null}>
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/baixar" element={<Navigate to="/" replace />} />
        <Route path="/privacidade" element={<Privacy />} />
        <Route path="/cookies" element={<Cookies />} />
        <Route path="/seguranca" element={<Security />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        {["/details", "/info", "/episodes", "/watch", "/person", "/canal", "/sala", "/salas"].map((p) => <Route key={p} path={p} element={<ShareLanding />} />)}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Suspense>
  );
}

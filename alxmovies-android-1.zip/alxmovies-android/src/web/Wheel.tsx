import { useRef, useState } from "react";
import { supabase } from "@/lib/supabase";

// A ordem tem de ser a mesma do SQL (wheel_spin → seg 0..7). O sorteio é feito no servidor; aqui só se anima.
const SEGMENTS = ["Não foi dessa vez", "+2 downloads", "+5 downloads", "Apoiador 3 dias", "Apoiador 7 dias", "Premium 3 dias", "Premium 7 dias", "Família 7 dias"];
const COLORS = ["#2a2a33", "#7a0710", "#2a2a33", "#a30c17", "#2a2a33", "#c9101c", "#2a2a33", "#e50914"];
const STEP = 360 / SEGMENTS.length;
const KEY_DEV = "alx.wheel.dev", KEY_LAST = "alx.wheel.last";

function deviceId() {
  try {
    let d = localStorage.getItem(KEY_DEV);
    if (!d) { d = (crypto.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`); localStorage.setItem(KEY_DEV, d); }
    return d;
  } catch { return `tmp-${Math.random().toString(36).slice(2)}-${Date.now()}`; }
}

type Result = { prize: string; code: string | null };

export function Wheel() {
  const [rot, setRot] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [res, setRes] = useState<Result | null>(() => { try { return JSON.parse(localStorage.getItem(KEY_LAST) || "null"); } catch { return null; } });
  const [err, setErr] = useState("");
  const [copied, setCopied] = useState(false);
  const turns = useRef(0);

  async function spin() {
    if (spinning) return;
    setErr(""); setSpinning(true);
    const { data, error } = await supabase.rpc("wheel_spin", { p_device: deviceId() });
    const r = data as { ok: boolean; error?: string; segment?: number; prize?: string; code?: string | null } | null;
    if (error || !r) { setErr("Não foi possível girar agora. Tente de novo."); setSpinning(false); return; }
    if (!r.ok) {
      setErr(r.error === "already" ? "Você já girou hoje. Volte amanhã para tentar de novo!" : "Não foi possível girar agora.");
      setSpinning(false); return;
    }
    // o ponteiro fica no topo: leva o CENTRO da fatia sorteada até lá
    turns.current += 1;
    setRot(turns.current * 360 * 5 - (r.segment! * STEP + STEP / 2));
    window.setTimeout(() => {
      const out = { prize: r.prize!, code: r.code ?? null };
      setRes(out); setSpinning(false);
      try { localStorage.setItem(KEY_LAST, JSON.stringify(out)); } catch { /* ignora */ }
    }, 4600);
  }

  const copy = async () => {
    if (!res?.code) return;
    try { await navigator.clipboard.writeText(res.code); setCopied(true); setTimeout(() => setCopied(false), 2000); } catch { /* ignora */ }
  };

  const bg = `conic-gradient(${COLORS.map((c, i) => `${c} ${i * STEP}deg ${(i + 1) * STEP}deg`).join(",")})`;

  return (
    <div className="wb-wheel">
      <div className="wb-wheel-stage">
        <i className="wb-wheel-pin" aria-hidden />
        <div className="wb-wheel-disc" style={{ background: bg, transform: `rotate(${rot}deg)` }}>
          {SEGMENTS.map((s, i) => (
            <span key={s} style={{ transform: `rotate(${i * STEP + STEP / 2}deg) translateY(-112px)` }}><b style={{ transform: "rotate(0deg)" }}>{s}</b></span>
          ))}
        </div>
        <button type="button" className="wb-wheel-btn" onClick={() => void spin()} disabled={spinning}>{spinning ? "…" : "GIRAR"}</button>
      </div>
      {err && <p className="wb-wheel-err">{err}</p>}
      {res && !spinning && (
        <div className="wb-wheel-res">
          <small>Seu prêmio</small>
          <b>{res.prize}</b>
          {res.code ? (
            <>
              <button type="button" className="wb-wheel-code" onClick={() => void copy()}>{res.code}<i>{copied ? "copiado!" : "tocar para copiar"}</i></button>
              <p>No app: menu do perfil → <b>Planos</b> → <b>Tem um código?</b>. O código vale por 7 dias.</p>
            </>
          ) : <p>Tente de novo amanhã!</p>}
        </div>
      )}
      <p className="wb-wheel-fine">1 giro por dia por aparelho. Os prêmios são temporários e podem mudar.</p>
    </div>
  );
}

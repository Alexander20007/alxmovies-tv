// Definido em vite.config.ts: true quando o app deve falar só com o proxy (padrão). O código do caminho "direto" é removido do build.
declare const __USE_PROXY__: boolean;

import { registerPlugin } from "@capacitor/core";
import { isNative } from "./native";

export type ManagerId = "adm" | "1dm" | "other";
export interface ManagerInfo { id: "adm" | "1dm"; name: string; installed: boolean; icon?: string }

export interface OpenOptions { url: string; title?: string; filename?: string; referer?: string; userAgent?: string }

interface AlxDownloadPlugin {
  listManagers(): Promise<{ managers: ManagerInfo[] }>;
  open(o: OpenOptions & { id: ManagerId }): Promise<void>;
  openStore(o: { id: "adm" | "1dm" }): Promise<void>;
  openCast(): Promise<void>;
}
const Native = registerPlugin<AlxDownloadPlugin>("AlxDownload");

export const PREF_KEY = "alx.dl.manager";
export const DOWNLOAD_UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36";

export async function listManagers(): Promise<ManagerInfo[]> {
  if (!isNative) return [];
  try { return (await Native.listManagers()).managers; }
  catch { return [{ id: "adm", name: "ADM", installed: false }, { id: "1dm", name: "1DM", installed: false }]; }
}

/** Nome do arquivo sem caracteres proibidos. O gerenciador coloca a extensão (.ts / .mp4) sozinho. */
export function cleanFileName(s: string) {
  return s.replace(/[:]+/g, " -").replace(/[\\/*?"<>|]+/g, "").replace(/\s+/g, " ").trim().slice(0, 120) || "ALXmovies";
}

/** Entrega o link ao gerenciador escolhido, já com o nome do arquivo. Retorna "not_installed" se o app não está no celular. */
export async function openInManager(id: ManagerId, input: string | OpenOptions, title?: string, referer?: string): Promise<"ok" | "not_installed" | "error"> {
  const o: OpenOptions = typeof input === "string" ? { url: input, title, referer } : input;
  try {
    await Native.open({ id, userAgent: DOWNLOAD_UA, ...o, filename: cleanFileName(o.filename ?? o.title ?? "") });
    return "ok";
  } catch (e) { return (e as Error)?.message === "not_installed" ? "not_installed" : "error"; }
}
export const openManagerStore = (id: "adm" | "1dm") => Native.openStore({ id }).catch(() => {});
export const openCastSettings = () => Native.openCast().catch(() => {});

export function savedManager(): ManagerId | "app" | null {
  try { const v = localStorage.getItem(PREF_KEY); return v === "adm" || v === "1dm" || v === "other" || v === "app" ? v : null; } catch { return null; }
}
export function saveManager(v: ManagerId | "app" | null) {
  try { if (v) localStorage.setItem(PREF_KEY, v); else localStorage.removeItem(PREF_KEY); } catch { /* sem armazenamento */ }
}

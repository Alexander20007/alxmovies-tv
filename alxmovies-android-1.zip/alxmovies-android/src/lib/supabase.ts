import { createClient } from "@supabase/supabase-js";
import { CONFIG } from "./config";
import { DirectRealtimeSocket, registerTokenGetter, sbFetch, warmNonces } from "./proxy";

/** O supabase-js limpa o hash da URL ao processar o link; guardamos antes para a tela de nova senha. */
export const openedViaRecoveryLink = typeof window !== "undefined" && window.location.hash.includes("type=recovery");

export const supabase = createClient(
  CONFIG.SUPABASE_URL,
  CONFIG.SUPABASE_ANON_KEY,
  CONFIG.USE_PROXY ? { global: { fetch: sbFetch }, realtime: { transport: DirectRealtimeSocket as any } } : undefined,
);

if (CONFIG.USE_PROXY) {
  registerTokenGetter(async () => (await supabase.auth.getSession()).data.session?.access_token ?? null);
  supabase.auth.onAuthStateChange((_e, session) => { if (session) warmNonces(); });
}

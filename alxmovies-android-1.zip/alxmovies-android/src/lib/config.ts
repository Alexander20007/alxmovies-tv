const env = import.meta.env;

// ── Proxy (Cloudflare Worker) ─────────────────────────────────────────────────────────────────────────
// Padrão: LIGADO. O app só conhece o endereço do proxy; sem login (JWT) + nonce nada responde.
// Emergência: build com VITE_USE_PROXY=false volta aos endereços diretos (que só existem nesse build).
const USE_PROXY: boolean = __USE_PROXY__;
const PROXY_URL = String(env.VITE_PROXY_URL ?? "https://alx-proxy.alexander221alex.workers.dev").replace(/\/+$/, "");

// Endereços diretos: só no build de emergência (com USE_PROXY = true este objeto vira {} e os textos somem do pacote).
const D: Record<string, string> = USE_PROXY ? {} : {
  SUPABASE: env.VITE_SUPABASE_URL ?? "https://onqxflwfkexitipylixc.supabase.co",
  STREAM: env.VITE_STREAM_BASE_URL ?? "https://alx-api.onrender.com",
  EXTRACTOR: env.VITE_EXTRACTOR_BASE_URL ?? "https://api-alex-jney.onrender.com",
  CHANNELS: env.VITE_CHANNELS_API_URL ?? "https://alx-player.netlify.app/.netlify/functions/canais",
  EPG: env.VITE_EPG_API_URL ?? "https://alx-player.netlify.app/.netlify/functions/programacao",
  RELEASE: "https://api.github.com/repos/Alexander20007/alxmovies-tv/releases/latest",
};
const pick = (viaProxy: string, direct: string | undefined) => (USE_PROXY ? viaProxy : (direct as string));

export const CONFIG = {
  USE_PROXY,
  PROXY_URL,
  SUPABASE_URL: pick(`${PROXY_URL}/sb`, D.SUPABASE),
  SUPABASE_ANON_KEY: env.VITE_SUPABASE_ANON_KEY ?? "sb_publishable_P6xFktXhhIjgC4hVxD6FxA_EbPl-clT",
  /** Base das funções do Supabase chamadas "na mão" (convidado). */
  FUNCTIONS_URL: pick(`${PROXY_URL}/sb-fn`, D.SUPABASE ? `${D.SUPABASE}/functions/v1` : undefined),
  TMDB_FUNCTION_URL: pick(`${PROXY_URL}/sb-fn/bright-handler`, D.SUPABASE ? `${D.SUPABASE}/functions/v1/bright-handler` : undefined),
  GEMINI_FUNCTION_URL: pick(`${PROXY_URL}/sb-fn/smooth-endpoint`, D.SUPABASE ? `${D.SUPABASE}/functions/v1/smooth-endpoint` : undefined),
  TMDB_IMG_BASE: "https://image.tmdb.org/t/p",
  POSTER_SIZE: "w500",
  BACKDROP_SIZE: "w1280",
  /** APIs (pedidos com JWT + nonce) */
  STREAM_BASE_URL: pick(`${PROXY_URL}/alx`, D.STREAM),
  EXTRACTOR_BASE_URL: pick(`${PROXY_URL}/jney`, D.EXTRACTOR),
  /** Links de vídeo (player/1DM não mandam JWT/nonce): rotas de mídia do proxy, só /api/proxy e /proxy. */
  STREAM_MEDIA_URL: pick(`${PROXY_URL}/alxm`, D.STREAM),
  EXTRACTOR_MEDIA_URL: pick(`${PROXY_URL}/jneym`, D.EXTRACTOR),
  CHANNELS_API_URL: pick(`${PROXY_URL}/canais`, D.CHANNELS),
  EPG_API_URL: pick(`${PROXY_URL}/epg`, D.EPG),
  RELEASE_API_URL: pick(`${PROXY_URL}/release`, D.RELEASE),
  GEMINI_MODEL: env.VITE_GEMINI_MODEL ?? "gemini-3.5-flash",
  GUEST_SESSION_MS: 24 * 60 * 60 * 1000,
} as const;

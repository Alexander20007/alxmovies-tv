const env = import.meta.env;

// ── Proxy (Cloudflare Worker). Desligado por padrão: com VITE_USE_PROXY=true o app fala só com o proxy (JWT + nonce).
// Se algo der errado no Worker, desligue a chave e o app volta a usar os endereços diretos. ──
const USE_PROXY = env.VITE_USE_PROXY === "true";
const PROXY_URL = String(env.VITE_PROXY_URL ?? "https://alx-proxy.alexander221alex.workers.dev").replace(/\/+$/, "");

const DIRECT = {
  SUPABASE: env.VITE_SUPABASE_URL ?? "https://onqxflwfkexitipylixc.supabase.co",
  STREAM: env.VITE_STREAM_BASE_URL ?? "https://alx-api.onrender.com",
  EXTRACTOR: env.VITE_EXTRACTOR_BASE_URL ?? "https://api-alex-jney.onrender.com",
  CHANNELS: env.VITE_CHANNELS_API_URL ?? "https://alx-player.netlify.app/.netlify/functions/canais",
  EPG: env.VITE_EPG_API_URL ?? "https://alx-player.netlify.app/.netlify/functions/programacao",
  TMDB_FN: env.VITE_TMDB_FUNCTION_URL ?? "https://onqxflwfkexitipylixc.supabase.co/functions/v1/bright-handler",
  GEMINI_FN: env.VITE_GEMINI_FUNCTION_URL ?? "https://onqxflwfkexitipylixc.supabase.co/functions/v1/smooth-endpoint",
};

export const CONFIG = {
  USE_PROXY,
  PROXY_URL,
  /** Sempre o endereço direto do Supabase: tempo real (websocket), plugin nativo de notificações e funções de convidado. */
  SUPABASE_DIRECT_URL: DIRECT.SUPABASE,
  /** O vídeo (m3u8/segmentos) que o player e o 1DM baixam continua saindo direto da API: não dá para mandar JWT/nonce nesses pedidos. */
  STREAM_DIRECT_URL: DIRECT.STREAM,
  EXTRACTOR_DIRECT_URL: DIRECT.EXTRACTOR,
  SUPABASE_URL: USE_PROXY ? `${PROXY_URL}/sb` : DIRECT.SUPABASE,
  SUPABASE_ANON_KEY: env.VITE_SUPABASE_ANON_KEY ?? "sb_publishable_P6xFktXhhIjgC4hVxD6FxA_EbPl-clT",
  TMDB_FUNCTION_URL: USE_PROXY ? `${PROXY_URL}/sb-fn/bright-handler` : DIRECT.TMDB_FN,
  TMDB_IMG_BASE: "https://image.tmdb.org/t/p",
  POSTER_SIZE: "w500",
  BACKDROP_SIZE: "w1280",
  STREAM_BASE_URL: USE_PROXY ? `${PROXY_URL}/alx` : DIRECT.STREAM,
  EXTRACTOR_BASE_URL: USE_PROXY ? `${PROXY_URL}/jney` : DIRECT.EXTRACTOR,
  CHANNELS_API_URL: USE_PROXY ? `${PROXY_URL}/canais` : DIRECT.CHANNELS,
  EPG_API_URL: USE_PROXY ? `${PROXY_URL}/epg` : DIRECT.EPG,
  GEMINI_FUNCTION_URL: USE_PROXY ? `${PROXY_URL}/sb-fn/smooth-endpoint` : DIRECT.GEMINI_FN,
  GEMINI_MODEL: env.VITE_GEMINI_MODEL ?? "gemini-3.5-flash",
  GUEST_SESSION_MS: 24 * 60 * 60 * 1000,
} as const;

import { useCallback, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useNavigate } from "react-router-dom";
import { useAdsEnabled } from "@/hooks/useAdsEnabled";
import { usePlan } from "@/hooks/usePlan";
import { maybeShowInterstitial, showRewardedAd } from "@/lib/ads";
import { consumeDownload, getMyPlan, grantAdBonus, type MyPlan } from "@/services/plans";
import { useBackClose } from "@/hooks/useBackClose";
import { Spinner } from "@/components/Spinner";
import { Icon } from "@/components/Icon";
import { fetchStream, resolveStream, type StreamRequest, type StreamResult } from "@/services/stream";
import {
  cleanFileName, listManagers, openInManager, openManagerStore, savedManager, saveManager,
  type ManagerId, type ManagerInfo,
} from "@/lib/downloader";

export interface DownloadRequest extends StreamRequest { title: string }

const pad = (n?: number) => String(n ?? 0).padStart(2, "0");
/** Nome do arquivo que o gerenciador vai usar: "Série - T01E03" ou o título do filme. A pessoa não digita nada. */
export const downloadName = (r: DownloadRequest) => (r.type === "tv" && r.season ? `${r.title} - T${pad(r.season)}E${pad(r.episode)}` : r.title);

const AUTO = "__auto__";

/**
 * Folha "Baixar": o link do vídeo já é preparado assim que ela abre; a pessoa escolhe o app (1DM / ADM / outro)
 * e o app abre direto na tela de download com o nome do arquivo preenchido.
 */
export function DownloadSheet({ req, onClose }: { req: DownloadRequest | null; onClose: () => void }) {
  useBackClose(!!req, onClose);
  const [managers, setManagers] = useState<ManagerInfo[]>([]);
  const [stream, setStream] = useState<StreamResult | null>(null);
  const [server, setServer] = useState<string>(AUTO);
  const [loadingLink, setLoadingLink] = useState(false);
  const [busy, setBusy] = useState<ManagerId | null>(null);
  const [msg, setMsg] = useState("");
  const [last, setLast] = useState<ManagerId | null>(null);
  const seq = useRef(0);
  const navigate = useNavigate();
  const adsOn = useAdsEnabled();
  const { refresh: refreshPlan } = usePlan();
  const [limit, setLimit] = useState<MyPlan | null>(null);   // preenchido quando o limite do mês acabou
  const [adBusy, setAdBusy] = useState(false);

  const prepare = useCallback(async (r: DownloadRequest, srv: string) => {
    const my = ++seq.current;
    setLoadingLink(true); setMsg("");
    try {
      const res = srv === AUTO ? await resolveStream(r) : await fetchStream({ ...r, server: srv });
      if (my !== seq.current) return null;
      setStream((old) => (srv === AUTO || !old ? res : { ...res, servers: old.servers.length ? old.servers : res.servers }));
      setLoadingLink(false);
      return res;
    } catch (e) {
      if (my !== seq.current) return null;
      setStream(null); setLoadingLink(false);
      setMsg(e instanceof Error && e.message ? e.message : "Não encontramos o link do vídeo agora. Tente de novo em instantes.");
      return null;
    }
  }, []);

  useEffect(() => {
    if (!req) { seq.current++; return; }
    setMsg(""); setBusy(null); setStream(null); setServer(AUTO); setLimit(null);
    setLast(savedManager() === "adm" || savedManager() === "1dm" ? (savedManager() as ManagerId) : null);
    void listManagers().then(setManagers);
    void prepare(req, AUTO);
  }, [req, prepare]);

  if (!req) return null;
  const name = downloadName(req);
  const sub = req.type === "tv" && req.season ? `${req.title} · T${req.season} E${req.episode}` : req.title;

  /** Garante um link válido (se o da folha expirou ou ainda está carregando, busca de novo). */
  async function ensureLink(): Promise<StreamResult | null> {
    if (stream && !(stream.expiresAt && stream.expiresAt < Date.now() + 30000)) return stream;
    return prepare(req!, server);
  }

  async function pick(id: ManagerId) {
    if (!req || busy) return;
    const m = managers.find((x) => x.id === id);
    if (m && !m.installed) { void openManagerStore(m.id); return; }
    setBusy(id); setMsg("");
    // limite do plano (vale para a conta toda). Se o servidor não responder, não trava quem está baixando.
    try {
      const p = await getMyPlan();
      if (p && p.remaining <= 0) { setBusy(null); setLimit(p); return; }
    } catch { /* segue */ }
    if (adsOn) await maybeShowInterstitial(0.5);   // plano Grátis: às vezes um anúncio antes de baixar
    const s = await ensureLink();
    if (!s) { setBusy(null); return; }
    const res = await openInManager(id, { url: s.m3u8, title: name, filename: name });
    setBusy(null);
    if (res === "ok") {
      try { const c = await consumeDownload(); if (!c.ok) { /* corrida entre aparelhos: já abriu, só atualiza o contador */ } } catch { /* ignora */ }
      refreshPlan();
      saveManager(id); onClose();
    }
    else setMsg(res === "not_installed" ? "Esse aplicativo não está instalado." : "Não foi possível abrir o gerenciador de downloads.");
  }

  async function watchAd() {
    if (adBusy) return;
    setAdBusy(true); setMsg("");
    const r = await showRewardedAd();
    if (r.completed) {
      try {
        const g = await grantAdBonus();
        if (g.ok) { setLimit(null); refreshPlan(); setMsg("Você ganhou +1 download! Escolha o aplicativo."); }
        else setMsg(g.error === "daily_cap" ? "Você já ganhou 3 downloads por anúncio hoje. Volte amanhã ou conheça os planos." : "Não foi possível liberar o download agora.");
      } catch { setMsg("Sem conexão. Tente de novo."); }
    } else {
      setMsg(r.error === "not_ready" ? "O anúncio ainda está carregando. Tente de novo em instantes." : "O anúncio não foi concluído, então o download não foi liberado.");
    }
    setAdBusy(false);
  }

  const servers = stream?.servers.filter((x) => x.ok) ?? [];
  const rows: { id: ManagerId; name: string; hint: string; installed: boolean; icon?: string }[] = [
    ...(["1dm", "adm"] as const).map((id) => {
      const m = managers.find((x) => x.id === id);
      const installed = m?.installed !== false;
      return {
        id, name: id === "adm" ? "ADM Download Manager" : "1DM Download Manager", installed, icon: m?.icon,
        hint: installed ? "Abre direto e começa a baixar" : "Não instalado — toque para instalar",
      };
    }),
  ];

  return createPortal(
    <div className="dl-overlay" onClick={(e) => e.target === e.currentTarget && !busy && onClose()}>
      <div className="dl-card" role="dialog" aria-modal="true" aria-label="Baixar">
        <div className="dl-head">
          <span className="dl-head-ico"><Icon name="download" size={22} strokeWidth={2.4} /></span>
          <div className="dl-head-txt">
            <small>Download</small>
            <h2>Como deseja baixar?</h2>
          </div>
          <button type="button" className="dl-x" onClick={onClose} aria-label="Fechar"><Icon name="close" size={20} /></button>
        </div>

        <div className="dl-what">
          <b>{sub}</b>
          <span>Salvo como <em>{cleanFileName(name)}</em></span>
        </div>

        {servers.length > 1 && (
          <div className="dl-servers" role="group" aria-label="Servidor">
            <span className="dl-servers-lb"><Icon name="server" size={15} /> Servidor</span>
            <div className="dl-chips">
              <button type="button" className={`dl-chip${server === AUTO ? " on" : ""}`} disabled={!!busy}
                onClick={() => { setServer(AUTO); void prepare(req, AUTO); }}>Automático</button>
              {servers.map((s) => (
                <button key={s.label} type="button" className={`dl-chip${server === s.label ? " on" : ""}`} disabled={!!busy}
                  onClick={() => { setServer(s.label); void prepare(req, s.label); }}>{s.label}</button>
              ))}
            </div>
          </div>
        )}

        {limit && (
          <div className="dl-limit" role="alert">
            <b>Limite de downloads do mês atingido</b>
            <span>Plano {limit.name}: {limit.used} de {limit.limit} usados.</span>
            {limit.plan_id === "free" && adsOn && (
              <button type="button" className="btn btn-primary" disabled={adBusy} onClick={() => void watchAd()}>
                {adBusy ? <Spinner size={15} /> : null} Assistir anúncio e ganhar +1 download
              </button>
            )}
            <button type="button" className="btn btn-secondary" onClick={() => { onClose(); navigate("/planos"); }}>Ver planos</button>
          </div>
        )}

        <div className="dl-list">
          {rows.map((r) => (
            <button key={r.id} type="button" className={`dl-row${r.installed ? "" : " off"}`} disabled={!!busy} onClick={() => void pick(r.id)}>
              <span className={`dl-ico dl-ico-${r.id}`}>
                {r.icon ? <img src={r.icon} alt="" /> : <Icon name="download" size={22} />}
              </span>
              <span className="dl-txt">
                <b>{r.name}{last === r.id && r.installed && <i className="dl-tag">Último usado</i>}</b>
                <small>{r.hint}</small>
              </span>
              {busy === r.id ? <Spinner size={20} /> : r.installed ? <Icon name="chevronRight" size={20} /> : <span className="dl-install">Instalar</span>}
            </button>
          ))}
        </div>

        {loadingLink && !msg && <p className="dl-status"><Spinner size={14} /> Preparando o link do vídeo…</p>}
        {msg && (
          <p className="dl-error" role="alert">
            {msg}
            <button type="button" onClick={() => void prepare(req, server)}>Tentar de novo</button>
          </p>
        )}
      </div>
    </div>,
    document.body,
  );
}

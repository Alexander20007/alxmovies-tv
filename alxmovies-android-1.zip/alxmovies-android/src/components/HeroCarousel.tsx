import { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Icon } from "@/components/Icon";
import { backdropUrl } from "@/services/tmdb";
import type { MediaItem } from "@/types";

const INTERVAL = 5500;

/** Destaques da Home: troca sozinho deslizando (e dá para arrastar com o dedo). Toque no play = assistir; toque no resto = detalhes. */
export function HeroCarousel({ items }: { items: MediaItem[] }) {
  const navigate = useNavigate();
  const track = useRef<HTMLDivElement>(null);
  const [index, setIndex] = useState(0);
  const indexRef = useRef(0);
  const pausedUntil = useRef(0);

  const goTo = useCallback((i: number, smooth = true) => {
    const el = track.current;
    if (!el) return;
    el.scrollTo({ left: i * el.clientWidth, behavior: smooth ? "smooth" : "auto" });
  }, []);

  // atualiza a bolinha conforme desliza
  const onScroll = () => {
    const el = track.current;
    if (!el || !el.clientWidth) return;
    const i = Math.round(el.scrollLeft / el.clientWidth);
    if (i !== indexRef.current) { indexRef.current = i; setIndex(i); }
  };

  // passa sozinho; se a pessoa mexer, espera um pouco antes de voltar a passar
  useEffect(() => {
    if (items.length < 2) return;
    const t = setInterval(() => {
      if (document.visibilityState === "hidden" || Date.now() < pausedUntil.current) return;
      goTo((indexRef.current + 1) % items.length);
    }, INTERVAL);
    return () => clearInterval(t);
  }, [items.length, goTo]);

  const pause = () => { pausedUntil.current = Date.now() + 9000; };

  return (
    <section className="hc" aria-roledescription="carrossel" aria-label="Destaques">
      <div ref={track} className="hc-track" onScroll={onScroll} onPointerDown={pause} onTouchStart={pause}>
        {items.map((m, i) => {
          const title = m.title ?? m.name ?? "";
          const bg = backdropUrl(m.backdrop_path, "w1280");
          return (
            <div key={m.id} className="hc-slide" onClick={() => navigate(`/details?id=${m.id}&type=movie`)} role="group" aria-label={`${i + 1} de ${items.length}`}>
              {bg && <img src={bg} alt="" draggable={false} loading={i === 0 ? "eager" : "lazy"} />}
              <div className="hc-shade" />
              <button type="button" className="hc-play" aria-label={`Assistir ${title}`}
                onClick={(e) => { e.stopPropagation(); navigate(`/watch?id=${m.id}&type=movie`); }}>
                <Icon name="play" size={30} />
              </button>
              <div className="hc-info">
                <span className="hc-tag"><Icon name="trending" size={17} strokeWidth={2.6} /> Em alta hoje</span>
                <h2>{title}</h2>
              </div>
            </div>
          );
        })}
      </div>
      {items.length > 1 && (
        <div className="hc-dots" role="tablist" aria-label="Escolher destaque">
          {items.map((m, i) => (
            <button key={m.id} type="button" role="tab" aria-selected={i === index} aria-label={`Destaque ${i + 1}`}
              className={i === index ? "on" : ""} onClick={() => { pause(); goTo(i); }} />
          ))}
        </div>
      )}
    </section>
  );
}

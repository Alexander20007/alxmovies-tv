import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import WebApp from "./web/WebApp";
import "./styles/style.css";
import "./styles/theme.css";
import "./styles/auth.css";
import "./styles/legal.css";
import "./web/web.css";

const queryClient = new QueryClient({ defaultOptions: { queries: { retry: 1, refetchOnWindowFocus: false, staleTime: 5 * 60_000 } } });

// O site antigo registrava um service worker (cache do app). Remove, para ninguém ficar preso na versão velha.
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.getRegistrations().then((rs) => rs.forEach((r) => void r.unregister())).catch(() => {});
  if ("caches" in window) caches.keys().then((ks) => ks.forEach((k) => void caches.delete(k))).catch(() => {});
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <BrowserRouter>
      <QueryClientProvider client={queryClient}>
        <WebApp />
      </QueryClientProvider>
    </BrowserRouter>
  </StrictMode>
);

import { isNative } from "@/lib/native";

// O site (navegador) é só informação e download do app: carrega uma versão leve, sem login nem player.
// O aplicativo carrega o app completo.
if (isNative) void import("./appMain");
else void import("./webMain");

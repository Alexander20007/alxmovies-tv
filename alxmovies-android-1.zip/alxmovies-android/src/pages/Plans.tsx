import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { BusyButton } from "@/components/Spinner";
import { Icon } from "@/components/Icon";
import { NativeBanner } from "@/components/Ads";
import { usePlan } from "@/hooks/usePlan";
import { listPlans, redeemCode, REDEEM_ERRORS, type PlanInfo } from "@/services/plans";

const SITE = "https://alxmovies.netlify.app/#roda";

function price(p: PlanInfo) {
  if (p.id === "free") return "Grátis";
  return p.price_brl != null ? `R$ ${p.price_brl.toFixed(2).replace(".", ",")}/mês` : "Preço em breve";
}

export default function Plans() {
  const navigate = useNavigate();
  const { plan, refresh } = usePlan();
  const plans = useQuery({ queryKey: ["plans"], queryFn: listPlans, staleTime: 10 * 60_000 });
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<{ ok: boolean; text: string } | null>(null);

  async function redeem() {
    if (!code.trim() || busy) return;
    setBusy(true); setStatus(null);
    try {
      const r = await redeemCode(code);
      if (r.ok) { setStatus({ ok: true, text: `Prêmio resgatado: ${r.prize}` }); setCode(""); refresh(); }
      else setStatus({ ok: false, text: REDEEM_ERRORS[r.error ?? ""] ?? "Não foi possível resgatar." });
    } catch { setStatus({ ok: false, text: "Sem conexão. Tente de novo." }); }
    finally { setBusy(false); }
  }

  const left = plan ? `${plan.remaining} de ${plan.limit} downloads restantes neste mês` : "";
  const until = plan?.expires_at ? ` · até ${new Date(plan.expires_at).toLocaleDateString("pt-BR")}` : "";

  return (
    <main className="plans-page">
      <header className="plans-head">
        <button type="button" className="ig-icon-btn" aria-label="Voltar" onClick={() => navigate(-1)}><Icon name="arrowLeft" /></button>
        <h1>Planos</h1>
      </header>

      {plan && (
        <section className="plans-now">
          <small>Seu plano</small>
          <b>{plan.name}{until}</b>
          <span>{left}</span>
        </section>
      )}

      <div className="plans-list">
        {(plans.data ?? []).map((p) => (
          <article key={p.id} className={`plan-card${plan?.plan_id === p.id ? " current" : ""}`}>
            <div className="plan-top"><h2>{p.name}</h2><span className="plan-price">{price(p)}</span></div>
            <ul>{p.perks.map((x) => <li key={x}>{x}</li>)}</ul>
            {plan?.plan_id === p.id && <em className="plan-tag">Plano atual</em>}
          </article>
        ))}
      </div>
      <p className="plans-note">A contratação dos planos chega em breve. Enquanto isso, ganhe um plano na <a href={SITE}>Roda da Sorte do site</a> e resgate o código aqui.</p>

      <section className="plans-redeem">
        <h3>Tem um código?</h3>
        <div className="plans-redeem-row">
          <input value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} placeholder="ALX-XXXX-XXXX" autoCapitalize="characters" autoCorrect="off" spellCheck={false} />
          <BusyButton type="button" className="btn btn-primary" loading={busy} onClick={() => void redeem()}>Resgatar</BusyButton>
        </div>
        {status && <p className={`account-status ${status.ok ? "ok" : "err"}`} style={{ display: "block" }}>{status.text}</p>}
      </section>
      <NativeBanner />
    </main>
  );
}

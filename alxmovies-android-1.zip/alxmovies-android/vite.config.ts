import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";
import path from "node:path";

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), "");
  // Proxy LIGADO por padrão. Só desliga com VITE_USE_PROXY=false (emergência).
  const useProxy = (process.env.VITE_USE_PROXY ?? env.VITE_USE_PROXY) !== "false";
  return {
    plugins: [react()],
    resolve: { alias: { "@": path.resolve(__dirname, "src") } },
    // Constante de build: com o proxy ligado, os endereços diretos nem entram no pacote final.
    define: { __USE_PROXY__: JSON.stringify(useProxy) },
    build: {
      rollupOptions: {
        output: {
          manualChunks: {
            vendor: ["react", "react-dom", "react-router-dom"],
            supabase: ["@supabase/supabase-js"],
          },
        },
      },
    },
  };
});

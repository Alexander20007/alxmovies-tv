// Ajusta o projeto Android que o Capacitor gera (rodado pelo GitHub Actions depois de `cap add android`).
// Não precisa rodar na sua máquina.
import fs from "node:fs";
import path from "node:path";

const androidDir = path.join(process.cwd(), "android");
const manifestPath = path.join(androidDir, "app/src/main/AndroidManifest.xml");
const gradlePath = path.join(androidDir, "app/build.gradle");

if (!fs.existsSync(manifestPath) || !fs.existsSync(gradlePath)) {
  console.error("✗ Projeto Android não encontrado. Rode `npx cap add android` antes.");
  process.exit(1);
}

const log = (msg) => console.log("•", msg);

// ---------- AndroidManifest.xml ----------
let manifest = fs.readFileSync(manifestPath, "utf8");

for (const perm of ["android.permission.INTERNET", "android.permission.ACCESS_NETWORK_STATE", "android.permission.WAKE_LOCK"]) {
  if (!manifest.includes(perm)) {
    manifest = manifest.replace(/<application/, `<uses-permission android:name="${perm}" />\n    <application`);
    log(`permissão ${perm}`);
  }
}
if (!/usesCleartextTraffic/.test(manifest)) {
  manifest = manifest.replace(/<application/, `<application\n        android:usesCleartextTraffic="false"`);
  log("tráfego HTTP sem criptografia bloqueado");
}
// O app é em retrato; o player gira para paisagem sozinho (plugin Screen Orientation).
if (!/android:screenOrientation/.test(manifest)) {
  manifest = manifest.replace(/<activity\b/, `<activity\n            android:screenOrientation="portrait"`);
  log("orientação padrão: retrato");
}
// Evita recarregar a página quando o app muda de tamanho/densidade (ex.: girar a tela)
manifest = manifest.replace(/android:configChanges="([^"]*)"/, (all, v) =>
  v.includes("density") ? all : `android:configChanges="${v}|density"`);
fs.writeFileSync(manifestPath, manifest);

// ---------- app/build.gradle: versão ----------
let gradle = fs.readFileSync(gradlePath, "utf8");
const code = Number(process.env.VERSION_CODE || 1);
const name = process.env.VERSION_NAME || "1.0.0";
gradle = gradle.replace(/versionCode\s*=?\s*\d+/, `versionCode ${code}`);
gradle = gradle.replace(/versionName\s*=?\s*"[^"]*"/, `versionName "${name}"`);
fs.writeFileSync(gradlePath, gradle);
log(`versão ${name} (código ${code})`);


// ---------- Atualização automática dentro do app (plugin nativo "AppUpdater") ----------
// Baixa o APK novo (com progresso) e abre o instalador do Android. O lado React está em src/lib/updater.ts.
{
  const javaRoot = path.join(androidDir, "app/src/main/java");
  const findFile = (dir, name) => {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, e.name);
      if (e.isDirectory()) { const r = findFile(full, name); if (r) return r; }
      else if (e.name === name) return full;
    }
    return null;
  };
  const mainJava = fs.existsSync(javaRoot) ? findFile(javaRoot, "MainActivity.java") : null;
  if (!mainJava) {
    console.error("✗ MainActivity.java não encontrada (atualização automática não instalada).");
    process.exit(1);
  }
  const pkg = /package\s+([\w.]+);/.exec(fs.readFileSync(mainJava, "utf8"))[1];
  const pkgDir = path.dirname(mainJava);

  fs.writeFileSync(path.join(pkgDir, "UpdateFileProvider.java"),
`package ${pkg};

import androidx.core.content.FileProvider;

/** FileProvider próprio do atualizador (não conflita com o do Capacitor). */
public class UpdateFileProvider extends FileProvider {}
`);

  fs.writeFileSync(path.join(pkgDir, "AppUpdaterPlugin.java"),
`package ${pkg};

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import androidx.core.content.FileProvider;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Baixa o APK novo para o cache do app, mostra progresso e chama o instalador do Android. */
@CapacitorPlugin(name = "AppUpdater")
public class AppUpdaterPlugin extends Plugin {
  private volatile boolean cancelled = false;

  private File updatesDir() {
    File d = new File(getContext().getCacheDir(), "updates");
    if (!d.exists()) d.mkdirs();
    return d;
  }

  private void wipe() {
    File[] files = updatesDir().listFiles();
    if (files != null) for (File f : files) f.delete();
  }

  @PluginMethod
  public void download(final PluginCall call) {
    final String url = call.getString("url");
    final long expected = call.getData().optLong("size", 0);
    if (url == null || !url.startsWith("https://")) { call.reject("Endereço de download inválido."); return; }
    cancelled = false;

    new Thread(() -> {
      HttpURLConnection conn = null;
      try {
        wipe();
        File part = new File(updatesDir(), "update.apk.part");
        File out = new File(updatesDir(), "update.apk");

        conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(30000);
        conn.setInstanceFollowRedirects(true);
        conn.setRequestProperty("Accept", "application/octet-stream");
        int code = conn.getResponseCode();
        if (code != 200) throw new Exception("Servidor respondeu " + code);

        long total = conn.getContentLengthLong();
        if (total <= 0) total = expected;
        long received = 0;
        int lastPercent = -1;
        long lastEmit = 0;

        try (InputStream in = conn.getInputStream(); OutputStream os = new FileOutputStream(part)) {
          byte[] buf = new byte[32 * 1024];
          int n;
          while ((n = in.read(buf)) != -1) {
            if (cancelled) { part.delete(); call.reject("cancelled"); return; }
            os.write(buf, 0, n);
            received += n;
            int percent = total > 0 ? (int) (received * 100 / total) : -1;
            long now = System.currentTimeMillis();
            if (percent != lastPercent && now - lastEmit > 120) {
              lastPercent = percent; lastEmit = now;
              JSObject p = new JSObject();
              p.put("received", received);
              p.put("total", total);
              p.put("percent", percent);
              notifyListeners("downloadProgress", p);
            }
          }
        }

        if (total > 0 && received != total) { part.delete(); throw new Exception("Download incompleto."); }
        if (!part.renameTo(out)) throw new Exception("Não foi possível salvar o arquivo.");

        // Segurança: só aceita um APK do próprio ALXmovies.
        PackageInfo info = getContext().getPackageManager().getPackageArchiveInfo(out.getAbsolutePath(), 0);
        if (info == null || !getContext().getPackageName().equals(info.packageName)) {
          out.delete();
          throw new Exception("O arquivo baixado não é um APK válido do ALXmovies.");
        }

        JSObject ret = new JSObject();
        ret.put("path", out.getAbsolutePath());
        call.resolve(ret);
      } catch (Exception e) {
        call.reject(e.getMessage() == null ? "Falha no download." : e.getMessage());
      } finally {
        if (conn != null) conn.disconnect();
      }
    }).start();
  }

  @PluginMethod
  public void cancel(PluginCall call) {
    cancelled = true;
    call.resolve();
  }

  @PluginMethod
  public void canInstall(PluginCall call) {
    boolean ok = Build.VERSION.SDK_INT < Build.VERSION_CODES.O
      || getContext().getPackageManager().canRequestPackageInstalls();
    JSObject ret = new JSObject();
    ret.put("allowed", ok);
    call.resolve(ret);
  }

  @PluginMethod
  public void openInstallSettings(PluginCall call) {
    Intent i = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getContext().getPackageName()));
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    getContext().startActivity(i);
    call.resolve();
  }

  @PluginMethod
  public void install(PluginCall call) {
    File apk = new File(updatesDir(), "update.apk");
    if (!apk.exists()) { call.reject("Arquivo de atualização não encontrado."); return; }
    try {
      Uri uri = FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".updater", apk);
      Intent i = new Intent(Intent.ACTION_VIEW);
      i.setDataAndType(uri, "application/vnd.android.package-archive");
      i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
      getContext().startActivity(i);
      call.resolve();
    } catch (Exception e) {
      call.reject(e.getMessage() == null ? "Não foi possível abrir o instalador." : e.getMessage());
    }
  }

  /** Apaga APKs antigos (chamado quando o app abre). */
  @PluginMethod
  public void cleanup(PluginCall call) {
    wipe();
    call.resolve();
  }
}
`);

  // plugin que informa a altura real da barra de status / navegação (usado pelo CSS: --sat / --sab)
  fs.writeFileSync(path.join(pkgDir, "EdgeInsetsPlugin.java"),
`package ${pkg};

import android.view.View;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** Devolve as margens das barras do sistema (em px de CSS) para o app desenhar por baixo delas (borda a borda). */
@CapacitorPlugin(name = "EdgeInsets")
public class EdgeInsetsPlugin extends Plugin {
  @PluginMethod
  public void get(final PluginCall call) {
    getActivity().runOnUiThread(() -> {
      JSObject ret = new JSObject();
      try {
        View decor = getActivity().getWindow().getDecorView();
        WindowInsetsCompat wi = ViewCompat.getRootWindowInsets(decor);
        float d = getContext().getResources().getDisplayMetrics().density;
        if (wi == null) {
          ret.put("ready", false);
        } else {
          Insets in = wi.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
          ret.put("ready", true);
          ret.put("top", Math.round(in.top / d));
          ret.put("bottom", Math.round(in.bottom / d));
          ret.put("left", Math.round(in.left / d));
          ret.put("right", Math.round(in.right / d));
        }
      } catch (Exception e) {
        ret.put("ready", false);
      }
      call.resolve(ret);
    });
  }
}
`);

  // registra os plugins na MainActivity e liga o modo borda a borda (status bar transparente, desenha por trás)
  fs.writeFileSync(mainJava,
`package ${pkg};

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    registerPlugin(AppUpdaterPlugin.class);
    registerPlugin(EdgeInsetsPlugin.class);
    registerPlugin(AlxNotifyPlugin.class);
    super.onCreate(savedInstanceState);
    enableEdgeToEdge();
  }

  @Override
  public void onResume() {
    super.onResume();
    enableEdgeToEdge();
  }

  /** O app desenha por trás da status bar e da barra de navegação, que ficam transparentes com ícones claros. */
  private void enableEdgeToEdge() {
    Window w = getWindow();
    WindowCompat.setDecorFitsSystemWindows(w, false);
    w.setStatusBarColor(Color.TRANSPARENT);
    w.setNavigationBarColor(Color.TRANSPARENT);
    if (Build.VERSION.SDK_INT >= 29) {
      w.setStatusBarContrastEnforced(false);
      w.setNavigationBarContrastEnforced(false);
    }
    if (Build.VERSION.SDK_INT >= 28) {
      WindowManager.LayoutParams lp = w.getAttributes();
      lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
      w.setAttributes(lp);
    }
    WindowInsetsControllerCompat c = WindowCompat.getInsetsController(w, w.getDecorView());
    c.setAppearanceLightStatusBars(false);
    c.setAppearanceLightNavigationBars(false);
  }
}
`);
  log("modo borda a borda (status bar transparente) + plugin EdgeInsets");


  // ---------- Firebase (push com o app fechado) — só entra se o google-services.json existir (secret GOOGLE_SERVICES_JSON) ----------
  const hasFirebase = fs.existsSync(path.join(androidDir, "app/google-services.json"));
  const tokenMethod = hasFirebase
    ? `  /** Token FCM deste aparelho (o JS registra no Supabase para o servidor poder mandar push). */
  @PluginMethod
  public void getPushToken(final PluginCall call) {
    try {
      com.google.firebase.messaging.FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
        JSObject r = new JSObject();
        r.put("token", task.isSuccessful() && task.getResult() != null ? task.getResult() : "");
        call.resolve(r);
      });
    } catch (Exception e) {
      JSObject r = new JSObject();
      r.put("token", "");
      call.resolve(r);
    }
  }`
    : `  /** Este APK foi compilado sem Firebase: sem push com o app fechado. */
  @PluginMethod
  public void getPushToken(final PluginCall call) {
    JSObject r = new JSObject();
    r.put("token", "");
    call.resolve(r);
  }`;

  // ---------- Notificações do aparelho (mensagens / pedidos de amizade) com resposta direto pela barra ----------
  // Plugin nativo "AlxNotify": o JS manda mostrar a notificação; os botões "Responder", "Aceitar", "Recusar" e
  // "Marcar como lida" são tratados por um BroadcastReceiver que chama o Supabase direto (sem abrir o app).
  const iconDir = path.join(androidDir, "app/src/main/res/drawable");
  fs.mkdirSync(iconDir, { recursive: true });
  fs.writeFileSync(path.join(iconDir, "ic_stat_alx.xml"),
`<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24">
    <path android:fillColor="#FFFFFFFF" android:pathData="M8,5v14l11,-7z"/>
</vector>
`);

  fs.writeFileSync(path.join(pkgDir, "AlxNotifyHelper.java"),
`package ${pkg};

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.service.notification.StatusBarNotification;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.app.Person;
import androidx.core.app.RemoteInput;
import androidx.core.content.ContextCompat;

/** Monta e publica as notificações do ALXmovies (usado pelo plugin e pelo receiver das ações). */
final class AlxNotifyHelper {
  private AlxNotifyHelper() {}

  /** true enquanto o app está na tela (aí o push não mostra nada: o app já mostra por dentro). */
  static volatile boolean appVisible = false;

  /** Evita notificar duas vezes a mesma coisa (tempo real do app + push do Firebase). Guarda as últimas 40 chaves. */
  static synchronized boolean firstTime(Context c, String key) {
    android.content.SharedPreferences sp = c.getSharedPreferences("alx_seen", Context.MODE_PRIVATE);
    String cur = sp.getString("ids", "");
    String[] parts = cur.isEmpty() ? new String[0] : cur.split(",");
    for (String p : parts) if (p.equals(key)) return false;
    StringBuilder sb = new StringBuilder();
    for (int i = Math.max(0, parts.length - 39); i < parts.length; i++) sb.append(parts[i]).append(',');
    sb.append(key);
    sp.edit().putString("ids", sb.toString()).apply();
    return true;
  }

  static final String PREFS = "alx_notify";
  static final String CH_MESSAGES = "alx_messages";
  static final String CH_SOCIAL = "alx_social";
  static final String KEY_REPLY = "alx_reply";
  static final String ACT_REPLY = "alxmovies.notify.REPLY";
  static final String ACT_READ = "alxmovies.notify.READ";
  static final String ACT_ACCEPT = "alxmovies.notify.ACCEPT";
  static final String ACT_DECLINE = "alxmovies.notify.DECLINE";

  static void ensureChannels(Context c) {
    if (Build.VERSION.SDK_INT < 26) return;
    NotificationManager nm = c.getSystemService(NotificationManager.class);
    if (nm == null) return;
    NotificationChannel m = new NotificationChannel(CH_MESSAGES, "Mensagens", NotificationManager.IMPORTANCE_HIGH);
    m.setDescription("Mensagens dos seus amigos");
    NotificationChannel s = new NotificationChannel(CH_SOCIAL, "Pedidos de amizade", NotificationManager.IMPORTANCE_DEFAULT);
    s.setDescription("Pedidos de amizade novos e aceitos");
    nm.createNotificationChannel(m);
    nm.createNotificationChannel(s);
  }

  static int idFor(String key) { return key.hashCode() & 0x7fffffff; }

  private static int smallIcon(Context c) {
    int id = c.getResources().getIdentifier("ic_stat_alx", "drawable", c.getPackageName());
    return id != 0 ? id : c.getApplicationInfo().icon;
  }

  private static boolean canPost(Context c) {
    if (Build.VERSION.SDK_INT >= 33
        && ContextCompat.checkSelfPermission(c, "android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) return false;
    return NotificationManagerCompat.from(c).areNotificationsEnabled();
  }

  @SuppressLint("MissingPermission")
  private static void post(Context c, int nid, Notification n) {
    if (!canPost(c)) return;
    try { NotificationManagerCompat.from(c).notify(nid, n); } catch (SecurityException ignored) {}
  }

  private static Notification active(Context c, int nid) {
    if (Build.VERSION.SDK_INT < 23) return null;
    try {
      NotificationManager nm = c.getSystemService(NotificationManager.class);
      if (nm == null) return null;
      for (StatusBarNotification sbn : nm.getActiveNotifications()) if (sbn.getId() == nid) return sbn.getNotification();
    } catch (Exception ignored) {}
    return null;
  }

  private static PendingIntent openIntent(Context c, int nid, String kind, String fid) {
    Intent i = new Intent(c, MainActivity.class);
    i.setAction(Intent.ACTION_MAIN);
    i.addCategory(Intent.CATEGORY_LAUNCHER);
    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
    i.putExtra("alx_kind", kind);
    if (fid != null) i.putExtra("alx_fid", fid);
    return PendingIntent.getActivity(c, nid, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
  }

  private static PendingIntent actionIntent(Context c, int nid, String action, String fid, String pid, String name, boolean mutable) {
    Intent i = new Intent(c, AlxNotifyReceiver.class);
    i.setAction(action);
    i.putExtra("nid", nid);
    i.putExtra("fid", fid);
    i.putExtra("pid", pid);
    i.putExtra("name", name);
    int flags = PendingIntent.FLAG_UPDATE_CURRENT;
    if (mutable && Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
    else flags |= PendingIntent.FLAG_IMMUTABLE;
    return PendingIntent.getBroadcast(c, nid, i, flags);
  }

  /** Conversa: acumula as mensagens do mesmo amigo numa notificação só. "incoming" = nova mensagem dele; "mine" = resposta enviada pela barra. */
  static void showMessage(Context c, String fid, String pid, String name, String incoming, long ts, String mine, boolean quiet) {
    ensureChannels(c);
    int nid = idFor("m:" + fid);
    Person me = new Person.Builder().setName("Você").build();
    Person them = new Person.Builder().setName(name == null || name.isEmpty() ? "Amigo" : name).build();

    NotificationCompat.MessagingStyle style = null;
    Notification existing = active(c, nid);
    if (existing != null) style = NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(existing);
    if (style == null) style = new NotificationCompat.MessagingStyle(me);
    if (incoming != null) style.addMessage(incoming, ts, them);
    if (mine != null) style.addMessage(mine, System.currentTimeMillis(), (Person) null);

    int icon = smallIcon(c);
    RemoteInput input = new RemoteInput.Builder(KEY_REPLY).setLabel("Responder a " + them.getName()).build();
    NotificationCompat.Action reply = new NotificationCompat.Action.Builder(icon, "Responder", actionIntent(c, nid, ACT_REPLY, fid, pid, name, true))
      .addRemoteInput(input)
      .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_REPLY)
      .setShowsUserInterface(false)
      .build();
    NotificationCompat.Action read = new NotificationCompat.Action.Builder(icon, "Marcar como lida", actionIntent(c, nid, ACT_READ, fid, pid, name, false))
      .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_MARK_AS_READ)
      .setShowsUserInterface(false)
      .build();

    NotificationCompat.Builder b = new NotificationCompat.Builder(c, CH_MESSAGES)
      .setSmallIcon(icon)
      .setStyle(style)
      .setCategory(NotificationCompat.CATEGORY_MESSAGE)
      .setPriority(NotificationCompat.PRIORITY_HIGH)
      .setAutoCancel(true)
      .setOnlyAlertOnce(quiet)
      .setWhen(mine != null ? System.currentTimeMillis() : ts)
      .setContentIntent(openIntent(c, nid, "message", fid))
      .addAction(reply)
      .addAction(read);
    post(c, nid, b.build());
  }

  /** Pedido de amizade novo (com Aceitar / Recusar) ou "aceitou seu pedido" (só informa). */
  static void showFriendEvent(Context c, String kind, String fid, String pid, String name) {
    ensureChannels(c);
    boolean request = "friend_request".equals(kind);
    int nid = idFor("r:" + fid);
    String who = name == null || name.isEmpty() ? "Alguém" : name;
    int icon = smallIcon(c);
    NotificationCompat.Builder b = new NotificationCompat.Builder(c, CH_SOCIAL)
      .setSmallIcon(icon)
      .setContentTitle(request ? "Novo pedido de amizade" : "Pedido aceito")
      .setContentText(request ? who + " quer ser seu amigo." : who + " aceitou seu pedido de amizade.")
      .setCategory(NotificationCompat.CATEGORY_SOCIAL)
      .setPriority(NotificationCompat.PRIORITY_DEFAULT)
      .setAutoCancel(true)
      .setContentIntent(openIntent(c, nid, kind, fid));
    if (request) {
      b.addAction(new NotificationCompat.Action.Builder(icon, "Aceitar", actionIntent(c, nid, ACT_ACCEPT, fid, pid, name, false)).setShowsUserInterface(false).build());
      b.addAction(new NotificationCompat.Action.Builder(icon, "Recusar", actionIntent(c, nid, ACT_DECLINE, fid, pid, name, false)).setShowsUserInterface(false).build());
    }
    post(c, nid, b.build());
  }

  /** Resultado de uma ação (enviado, erro, aceito…) no lugar da notificação original. */
  static void showInfo(Context c, int nid, String channel, String title, String text, String kind, String fid) {
    ensureChannels(c);
    NotificationCompat.Builder b = new NotificationCompat.Builder(c, channel)
      .setSmallIcon(smallIcon(c))
      .setContentTitle(title)
      .setContentText(text)
      .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
      .setAutoCancel(true)
      .setOnlyAlertOnce(true)
      .setTimeoutAfter(15000)
      .setContentIntent(openIntent(c, nid, kind, fid));
    post(c, nid, b.build());
  }

  static void cancel(Context c, int nid) { NotificationManagerCompat.from(c).cancel(nid); }
  static void cancelAll(Context c) { NotificationManagerCompat.from(c).cancelAll(); }
}
`);

  fs.writeFileSync(path.join(pkgDir, "AlxNotifyReceiver.java"),
`package ${pkg};

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.core.app.RemoteInput;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;

/** Trata os botões da notificação (responder, aceitar, recusar, marcar como lida) falando direto com o Supabase. */
public class AlxNotifyReceiver extends BroadcastReceiver {
  @Override
  public void onReceive(final Context ctx, final Intent intent) {
    final String action = intent.getAction();
    if (action == null) return;
    String typed = null;
    if (AlxNotifyHelper.ACT_REPLY.equals(action)) {
      Bundle r = RemoteInput.getResultsFromIntent(intent);
      CharSequence cs = r == null ? null : r.getCharSequence(AlxNotifyHelper.KEY_REPLY);
      typed = cs == null ? "" : cs.toString().trim();
    }
    final String text = typed;
    final PendingResult pending = goAsync();
    new Thread(() -> {
      try { handle(ctx.getApplicationContext(), intent, action, text); }
      catch (Exception ignored) {}
      finally { pending.finish(); }
    }).start();
  }

  private static int rpc(SharedPreferences sp, String fn, JSONObject body) throws Exception {
    HttpURLConnection c = (HttpURLConnection) new URL(sp.getString("url", "") + "/rest/v1/rpc/" + fn).openConnection();
    try {
      c.setRequestMethod("POST");
      c.setConnectTimeout(6000);
      c.setReadTimeout(8000);
      c.setDoOutput(true);
      c.setRequestProperty("Content-Type", "application/json");
      c.setRequestProperty("apikey", sp.getString("key", ""));
      c.setRequestProperty("Authorization", "Bearer " + sp.getString("token", ""));
      try (OutputStream os = c.getOutputStream()) { os.write(body.toString().getBytes("UTF-8")); }
      return c.getResponseCode();
    } finally { c.disconnect(); }
  }

  private void handle(Context ctx, Intent in, String action, String text) throws Exception {
    SharedPreferences sp = ctx.getSharedPreferences(AlxNotifyHelper.PREFS, Context.MODE_PRIVATE);
    int nid = in.getIntExtra("nid", 0);
    String fid = in.getStringExtra("fid");
    String pid = in.getStringExtra("pid");
    String name = in.getStringExtra("name");
    boolean reply = AlxNotifyHelper.ACT_REPLY.equals(action);
    String channel = reply || AlxNotifyHelper.ACT_READ.equals(action) ? AlxNotifyHelper.CH_MESSAGES : AlxNotifyHelper.CH_SOCIAL;
    String kind = reply || AlxNotifyHelper.ACT_READ.equals(action) ? "message" : "friend_request";

    if (reply && (text == null || text.isEmpty())) {
      AlxNotifyHelper.showMessage(ctx, fid, pid, name, null, System.currentTimeMillis(), null, true);
      return;
    }
    boolean ready = !sp.getString("url", "").isEmpty() && !sp.getString("token", "").isEmpty() && pid != null && fid != null;
    if (!ready) {
      AlxNotifyHelper.showInfo(ctx, nid, channel, "Abra o ALXmovies", reply ? "Sua resposta não foi enviada: entre no app e tente de novo." : "Entre no app para continuar.", kind, fid);
      return;
    }

    int code;
    try {
      JSONObject b = new JSONObject();
      b.put("p_profile_id", pid);
      b.put("p_friendship_id", fid);
      if (reply) {
        b.put("p_body", text);
        b.put("p_kind", "text");
        code = rpc(sp, "social_send_message", b);
      } else if (AlxNotifyHelper.ACT_READ.equals(action)) {
        code = rpc(sp, "social_mark_read", b);
      } else {
        b.put("p_accept", AlxNotifyHelper.ACT_ACCEPT.equals(action));
        code = rpc(sp, "social_respond_request", b);
      }
    } catch (Exception e) {
      code = -1;
    }
    boolean ok = code >= 200 && code < 300;

    if (reply) {
      if (ok) AlxNotifyHelper.showMessage(ctx, fid, pid, name, null, System.currentTimeMillis(), text, true);
      else AlxNotifyHelper.showInfo(ctx, nid, channel, "Não foi possível enviar",
        (code == 401 ? "Sessão expirada — abra o app. " : "Sem conexão. ") + "Sua resposta: \\"" + text + "\\"", "message", fid);
    } else if (AlxNotifyHelper.ACT_READ.equals(action)) {
      AlxNotifyHelper.cancel(ctx, nid);
    } else if (ok) {
      boolean accepted = AlxNotifyHelper.ACT_ACCEPT.equals(action);
      if (accepted) AlxNotifyHelper.showInfo(ctx, nid, channel, "Pedido aceito", "Agora você e " + (name == null ? "seu novo amigo" : name) + " são amigos.", "friend_accepted", fid);
      else AlxNotifyHelper.cancel(ctx, nid);
    } else {
      AlxNotifyHelper.showInfo(ctx, nid, channel, "Não foi possível responder", code == 401 ? "Sessão expirada — abra o app." : "Sem conexão. Tente de novo pelo app.", "friend_request", fid);
    }
  }
}
`);

  fs.writeFileSync(path.join(pkgDir, "AlxNotifyPlugin.java"),
`package ${pkg};

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import androidx.core.app.NotificationManagerCompat;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

/** Ponte JS ↔ notificações do Android (ver src/lib/deviceNotify.ts). */
@CapacitorPlugin(
  name = "AlxNotify",
  permissions = { @Permission(strings = { "android.permission.POST_NOTIFICATIONS" }, alias = "notifications") }
)
public class AlxNotifyPlugin extends Plugin {
  @Override
  public void load() {
    AlxNotifyHelper.ensureChannels(getContext());
    handleTap(getActivity() == null ? null : getActivity().getIntent());
  }

  @Override
  protected void handleOnNewIntent(Intent intent) {
    super.handleOnNewIntent(intent);
    handleTap(intent);
  }

  @Override
  protected void handleOnResume() { super.handleOnResume(); AlxNotifyHelper.appVisible = true; }

  @Override
  protected void handleOnPause() { super.handleOnPause(); AlxNotifyHelper.appVisible = false; }

  /** O usuário tocou na notificação: avisa o JS para abrir a tela certa (guarda o aviso até alguém escutar). */
  private void handleTap(Intent i) {
    if (i == null) return;
    String kind = i.getStringExtra("alx_kind");
    if (kind == null) return;
    JSObject o = new JSObject();
    o.put("kind", kind);
    String fid = i.getStringExtra("alx_fid");
    if (fid != null) o.put("fid", fid);
    i.removeExtra("alx_kind");
    i.removeExtra("alx_fid");
    notifyListeners("tap", o, true);
  }

  private void resolveStatus(PluginCall call) {
    JSObject r = new JSObject();
    r.put("granted", NotificationManagerCompat.from(getContext()).areNotificationsEnabled());
    call.resolve(r);
  }

  @PluginMethod
  public void requestPermission(PluginCall call) {
    if (Build.VERSION.SDK_INT < 33 || getPermissionState("notifications") == PermissionState.GRANTED) { resolveStatus(call); return; }
    requestPermissionForAlias("notifications", call, "permissionResult");
  }

  @PermissionCallback
  private void permissionResult(PluginCall call) { resolveStatus(call); }

  @PluginMethod
  public void status(PluginCall call) { resolveStatus(call); }

  /** Guarda o login para os botões da notificação poderem responder sem abrir o app. */
  @PluginMethod
  public void setSession(PluginCall call) {
    SharedPreferences.Editor e = getContext().getSharedPreferences(AlxNotifyHelper.PREFS, Context.MODE_PRIVATE).edit();
    e.putString("url", call.getString("url", ""));
    e.putString("key", call.getString("key", ""));
    e.putString("token", call.getString("token", ""));
    e.apply();
    call.resolve();
  }

  @PluginMethod
  public void clearSession(PluginCall call) {
    getContext().getSharedPreferences(AlxNotifyHelper.PREFS, Context.MODE_PRIVATE).edit().clear().apply();
    AlxNotifyHelper.cancelAll(getContext());
    call.resolve();
  }

  @PluginMethod
  public void showMessage(PluginCall call) {
    String fid = call.getString("fid");
    String pid = call.getString("pid");
    if (fid == null || pid == null) { call.reject("fid/pid ausentes"); return; }
    long ts = call.getData().optLong("ts", System.currentTimeMillis());
    String mid = call.getString("mid");
    if (mid != null && !AlxNotifyHelper.firstTime(getContext(), "m:" + mid)) { call.resolve(); return; }
    AlxNotifyHelper.showMessage(getContext(), fid, pid, call.getString("name", ""), call.getString("text", ""), ts, null, false);
    call.resolve();
  }

  @PluginMethod
  public void showFriendEvent(PluginCall call) {
    String fid = call.getString("fid");
    String pid = call.getString("pid");
    if (fid == null || pid == null) { call.reject("fid/pid ausentes"); return; }
    String nid = call.getString("nid");
    if (nid != null && !AlxNotifyHelper.firstTime(getContext(), "n:" + nid)) { call.resolve(); return; }
    AlxNotifyHelper.showFriendEvent(getContext(), call.getString("kind", "friend_request"), fid, pid, call.getString("name", ""));
    call.resolve();
  }

${tokenMethod}

  @PluginMethod
  public void cancelAll(PluginCall call) {
    AlxNotifyHelper.cancelAll(getContext());
    call.resolve();
  }
}
`);

  if (hasFirebase) {
    fs.writeFileSync(path.join(pkgDir, "AlxFirebaseService.java"),
`package ${pkg};

import android.content.Context;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import java.util.Map;

/** Recebe o push (só dados) do servidor e monta a mesma notificação com botão de responder. */
public class AlxFirebaseService extends FirebaseMessagingService {
  @Override
  public void onMessageReceived(RemoteMessage msg) {
    Map<String, String> d = msg.getData();
    if (d == null || AlxNotifyHelper.appVisible) return; // com o app na tela, ele mesmo mostra
    Context c = getApplicationContext();
    String type = d.get("type");
    String fid = d.get("fid");
    String pid = d.get("pid");
    if (type == null || fid == null || fid.isEmpty() || pid == null) return;
    String name = d.get("name");

    if ("message".equals(type)) {
      String mid = d.get("mid");
      if (mid != null && !AlxNotifyHelper.firstTime(c, "m:" + mid)) return;
      long ts = System.currentTimeMillis();
      try { ts = Long.parseLong(d.get("ts")); } catch (Exception ignored) {}
      AlxNotifyHelper.showMessage(c, fid, pid, name, d.get("text") == null ? "" : d.get("text"), ts, null, false);
    } else if ("friend_request".equals(type) || "friend_accepted".equals(type)) {
      String nid = d.get("nid");
      if (nid != null && !AlxNotifyHelper.firstTime(c, "n:" + nid)) return;
      AlxNotifyHelper.showFriendEvent(c, type, fid, pid, name);
    }
  }
}
`);
    log("serviço do Firebase (push com o app fechado)");

    let g = fs.readFileSync(gradlePath, "utf8");
    if (!g.includes("firebase-messaging")) {
      g += "\ndependencies {\n    implementation 'com.google.firebase:firebase-messaging:24.1.0'\n}\n";
      fs.writeFileSync(gradlePath, g);
      log("dependência firebase-messaging");
    }
  } else {
    log("sem google-services.json: APK sem push do Firebase (só notificações com o app aberto/em segundo plano)");
  }

  // caminhos que o FileProvider pode compartilhar
  const xmlDir = path.join(androidDir, "app/src/main/res/xml");
  fs.mkdirSync(xmlDir, { recursive: true });
  fs.writeFileSync(path.join(xmlDir, "updater_paths.xml"),
`<?xml version="1.0" encoding="utf-8"?>
<paths>
    <cache-path name="updates" path="updates/" />
</paths>
`);

  // manifesto: permissão de instalar + provider
  let mf = fs.readFileSync(manifestPath, "utf8");
  if (!mf.includes("REQUEST_INSTALL_PACKAGES")) {
    mf = mf.replace(/<application/, `<uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES" />\n    <application`);
    log("permissão de instalar atualizações");
  }
  if (!mf.includes("android.permission.POST_NOTIFICATIONS")) {
    mf = mf.replace(/<application/, `<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />\n    <application`);
    log("permissão de notificações");
  }
  if (!mf.includes("AlxNotifyReceiver")) {
    mf = mf.replace(/<\/application>/, `    <receiver android:name="${pkg}.AlxNotifyReceiver" android:exported="false" />\n    </application>`);
    log("receiver das notificações");
  }
  if (hasFirebase && !mf.includes("AlxFirebaseService")) {
    mf = mf.replace(/<\/application>/, `    <service android:name="${pkg}.AlxFirebaseService" android:exported="false">
            <intent-filter><action android:name="com.google.firebase.MESSAGING_EVENT" /></intent-filter>
        </service>
    </application>`);
    log("serviço do Firebase no manifesto");
  }
  if (!mf.includes("UpdateFileProvider")) {
    mf = mf.replace(/<\/application>/, `    <provider
            android:name="${pkg}.UpdateFileProvider"
            android:authorities="\${applicationId}.updater"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data android:name="android.support.FILE_PROVIDER_PATHS" android:resource="@xml/updater_paths" />
        </provider>
    </application>`);
    log("provider do atualizador");
  }
  fs.writeFileSync(manifestPath, mf);
  log("plugin AppUpdater instalado");
}

console.log("✓ Projeto Android ajustado.");

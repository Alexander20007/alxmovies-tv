// Ajusta o projeto Android que o Capacitor gera (rodado pelo GitHub Actions depois de `cap add android`).
// Não precisa rodar na sua máquina.
import fs from "node:fs";
import path from "node:path";

const androidDir = path.join(process.cwd(), "android");
const manifestPath = path.join(androidDir, "app/src/main/AndroidManifest.xml");
const gradlePath = path.join(androidDir, "app/build.gradle");

if (!fs.existsSync(manifestPath) || !fs.existsSync(gradlePath)) {
  console.error("✗ Projeto Android não encontrado. Rode `npx cap add android` antes.");
  process.exit(1);
}

const log = (msg) => console.log("•", msg);

// ---------- AndroidManifest.xml ----------
let manifest = fs.readFileSync(manifestPath, "utf8");

for (const perm of ["android.permission.INTERNET", "android.permission.ACCESS_NETWORK_STATE", "android.permission.WAKE_LOCK"]) {
  if (!manifest.includes(perm)) {
    manifest = manifest.replace(/<application/, `<uses-permission android:name="${perm}" />\n    <application`);
    log(`permissão ${perm}`);
  }
}
if (!/usesCleartextTraffic/.test(manifest)) {
  manifest = manifest.replace(/<application/, `<application\n        android:usesCleartextTraffic="false"`);
  log("tráfego HTTP sem criptografia bloqueado");
}
// O app é em retrato; o player gira para paisagem sozinho (plugin Screen Orientation).
if (!/android:screenOrientation/.test(manifest)) {
  manifest = manifest.replace(/<activity\b/, `<activity\n            android:screenOrientation="portrait"`);
  log("orientação padrão: retrato");
}
// Evita recarregar a página quando o app muda de tamanho/densidade (ex.: girar a tela)
manifest = manifest.replace(/android:configChanges="([^"]*)"/, (all, v) =>
  v.includes("density") ? all : `android:configChanges="${v}|density"`);
fs.writeFileSync(manifestPath, manifest);

// ---------- app/build.gradle: versão ----------
let gradle = fs.readFileSync(gradlePath, "utf8");
const code = Number(process.env.VERSION_CODE || 1);
const name = process.env.VERSION_NAME || "1.0.0";
gradle = gradle.replace(/versionCode\s*=?\s*\d+/, `versionCode ${code}`);
gradle = gradle.replace(/versionName\s*=?\s*"[^"]*"/, `versionName "${name}"`);
fs.writeFileSync(gradlePath, gradle);
log(`versão ${name} (código ${code})`);


// ---------- Atualização automática dentro do app (plugin nativo "AppUpdater") ----------
// Baixa o APK novo (com progresso) e abre o instalador do Android. O lado React está em src/lib/updater.ts.
{
  const javaRoot = path.join(androidDir, "app/src/main/java");
  const findFile = (dir, name) => {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, e.name);
      if (e.isDirectory()) { const r = findFile(full, name); if (r) return r; }
      else if (e.name === name) return full;
    }
    return null;
  };
  const mainJava = fs.existsSync(javaRoot) ? findFile(javaRoot, "MainActivity.java") : null;
  if (!mainJava) {
    console.error("✗ MainActivity.java não encontrada (atualização automática não instalada).");
    process.exit(1);
  }
  const pkg = /package\s+([\w.]+);/.exec(fs.readFileSync(mainJava, "utf8"))[1];
  const pkgDir = path.dirname(mainJava);

  fs.writeFileSync(path.join(pkgDir, "UpdateFileProvider.java"),
`package ${pkg};

import androidx.core.content.FileProvider;

/** FileProvider próprio do atualizador (não conflita com o do Capacitor). */
public class UpdateFileProvider extends FileProvider {}
`);

  fs.writeFileSync(path.join(pkgDir, "AppUpdaterPlugin.java"),
`package ${pkg};

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import androidx.core.content.FileProvider;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Baixa o APK novo para o cache do app, mostra progresso e chama o instalador do Android. */
@CapacitorPlugin(name = "AppUpdater")
public class AppUpdaterPlugin extends Plugin {
  private volatile boolean cancelled = false;

  private File updatesDir() {
    File d = new File(getContext().getCacheDir(), "updates");
    if (!d.exists()) d.mkdirs();
    return d;
  }

  private void wipe() {
    File[] files = updatesDir().listFiles();
    if (files != null) for (File f : files) f.delete();
  }

  @PluginMethod
  public void download(final PluginCall call) {
    final String url = call.getString("url");
    final long expected = call.getData().optLong("size", 0);
    if (url == null || !url.startsWith("https://")) { call.reject("Endereço de download inválido."); return; }
    cancelled = false;

    new Thread(() -> {
      HttpURLConnection conn = null;
      try {
        wipe();
        File part = new File(updatesDir(), "update.apk.part");
        File out = new File(updatesDir(), "update.apk");

        conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(30000);
        conn.setInstanceFollowRedirects(true);
        conn.setRequestProperty("Accept", "application/octet-stream");
        int code = conn.getResponseCode();
        if (code != 200) throw new Exception("Servidor respondeu " + code);

        long total = conn.getContentLengthLong();
        if (total <= 0) total = expected;
        long received = 0;
        int lastPercent = -1;
        long lastEmit = 0;

        try (InputStream in = conn.getInputStream(); OutputStream os = new FileOutputStream(part)) {
          byte[] buf = new byte[32 * 1024];
          int n;
          while ((n = in.read(buf)) != -1) {
            if (cancelled) { part.delete(); call.reject("cancelled"); return; }
            os.write(buf, 0, n);
            received += n;
            int percent = total > 0 ? (int) (received * 100 / total) : -1;
            long now = System.currentTimeMillis();
            if (percent != lastPercent && now - lastEmit > 120) {
              lastPercent = percent; lastEmit = now;
              JSObject p = new JSObject();
              p.put("received", received);
              p.put("total", total);
              p.put("percent", percent);
              notifyListeners("downloadProgress", p);
            }
          }
        }

        if (total > 0 && received != total) { part.delete(); throw new Exception("Download incompleto."); }
        if (!part.renameTo(out)) throw new Exception("Não foi possível salvar o arquivo.");

        // Segurança: só aceita um APK do próprio ALXmovies.
        PackageInfo info = getContext().getPackageManager().getPackageArchiveInfo(out.getAbsolutePath(), 0);
        if (info == null || !getContext().getPackageName().equals(info.packageName)) {
          out.delete();
          throw new Exception("O arquivo baixado não é um APK válido do ALXmovies.");
        }

        JSObject ret = new JSObject();
        ret.put("path", out.getAbsolutePath());
        call.resolve(ret);
      } catch (Exception e) {
        call.reject(e.getMessage() == null ? "Falha no download." : e.getMessage());
      } finally {
        if (conn != null) conn.disconnect();
      }
    }).start();
  }

  @PluginMethod
  public void cancel(PluginCall call) {
    cancelled = true;
    call.resolve();
  }

  @PluginMethod
  public void canInstall(PluginCall call) {
    boolean ok = Build.VERSION.SDK_INT < Build.VERSION_CODES.O
      || getContext().getPackageManager().canRequestPackageInstalls();
    JSObject ret = new JSObject();
    ret.put("allowed", ok);
    call.resolve(ret);
  }

  @PluginMethod
  public void openInstallSettings(PluginCall call) {
    Intent i = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getContext().getPackageName()));
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    getContext().startActivity(i);
    call.resolve();
  }

  @PluginMethod
  public void install(PluginCall call) {
    File apk = new File(updatesDir(), "update.apk");
    if (!apk.exists()) { call.reject("Arquivo de atualização não encontrado."); return; }
    try {
      Uri uri = FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".updater", apk);
      Intent i = new Intent(Intent.ACTION_VIEW);
      i.setDataAndType(uri, "application/vnd.android.package-archive");
      i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
      getContext().startActivity(i);
      call.resolve();
    } catch (Exception e) {
      call.reject(e.getMessage() == null ? "Não foi possível abrir o instalador." : e.getMessage());
    }
  }

  /** Apaga APKs antigos (chamado quando o app abre). */
  @PluginMethod
  public void cleanup(PluginCall call) {
    wipe();
    call.resolve();
  }
}
`);

  // registra o plugin na MainActivity
  fs.writeFileSync(mainJava,
`package ${pkg};

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    registerPlugin(AppUpdaterPlugin.class);
    super.onCreate(savedInstanceState);
  }
}
`);

  // caminhos que o FileProvider pode compartilhar
  const xmlDir = path.join(androidDir, "app/src/main/res/xml");
  fs.mkdirSync(xmlDir, { recursive: true });
  fs.writeFileSync(path.join(xmlDir, "updater_paths.xml"),
`<?xml version="1.0" encoding="utf-8"?>
<paths>
    <cache-path name="updates" path="updates/" />
</paths>
`);

  // manifesto: permissão de instalar + provider
  let mf = fs.readFileSync(manifestPath, "utf8");
  if (!mf.includes("REQUEST_INSTALL_PACKAGES")) {
    mf = mf.replace(/<application/, `<uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES" />\n    <application`);
    log("permissão de instalar atualizações");
  }
  if (!mf.includes("UpdateFileProvider")) {
    mf = mf.replace(/<\/application>/, `    <provider
            android:name="${pkg}.UpdateFileProvider"
            android:authorities="\${applicationId}.updater"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data android:name="android.support.FILE_PROVIDER_PATHS" android:resource="@xml/updater_paths" />
        </provider>
    </application>`);
    log("provider do atualizador");
  }
  fs.writeFileSync(manifestPath, mf);
  log("plugin AppUpdater instalado");
}

console.log("✓ Projeto Android ajustado.");

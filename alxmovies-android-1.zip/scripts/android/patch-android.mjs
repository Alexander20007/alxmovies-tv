// Ajusta o projeto Android que o Capacitor gera (rodado pelo GitHub Actions depois de `cap add android`).
// Não precisa rodar na sua máquina.
import fs from "node:fs";
import path from "node:path";

const androidDir = path.join(process.cwd(), "android");
const manifestPath = path.join(androidDir, "app/src/main/AndroidManifest.xml");
const gradlePath = path.join(androidDir, "app/build.gradle");

if (!fs.existsSync(manifestPath) || !fs.existsSync(gradlePath)) {
  console.error("✗ Projeto Android não encontrado. Rode `npx cap add android` antes.");
  process.exit(1);
}

const log = (msg) => console.log("•", msg);

// ---------- AndroidManifest.xml ----------
let manifest = fs.readFileSync(manifestPath, "utf8");

for (const perm of ["android.permission.INTERNET", "android.permission.ACCESS_NETWORK_STATE", "android.permission.WAKE_LOCK"]) {
  if (!manifest.includes(perm)) {
    manifest = manifest.replace(/<application/, `<uses-permission android:name="${perm}" />\n    <application`);
    log(`permissão ${perm}`);
  }
}
if (!/usesCleartextTraffic/.test(manifest)) {
  manifest = manifest.replace(/<application/, `<application\n        android:usesCleartextTraffic="false"`);
  log("tráfego HTTP sem criptografia bloqueado");
}
// O app é em retrato; o player gira para paisagem sozinho (plugin Screen Orientation).
if (!/android:screenOrientation/.test(manifest)) {
  manifest = manifest.replace(/<activity\b/, `<activity\n            android:screenOrientation="portrait"`);
  log("orientação padrão: retrato");
}
// Evita recarregar a página quando o app muda de tamanho/densidade (ex.: girar a tela)
manifest = manifest.replace(/android:configChanges="([^"]*)"/, (all, v) =>
  v.includes("density") ? all : `android:configChanges="${v}|density"`);
fs.writeFileSync(manifestPath, manifest);

// ---------- app/build.gradle: versão ----------
let gradle = fs.readFileSync(gradlePath, "utf8");
const code = Number(process.env.VERSION_CODE || 1);
const name = process.env.VERSION_NAME || "1.0.0";
gradle = gradle.replace(/versionCode\s*=?\s*\d+/, `versionCode ${code}`);
gradle = gradle.replace(/versionName\s*=?\s*"[^"]*"/, `versionName "${name}"`);
fs.writeFileSync(gradlePath, gradle);
log(`versão ${name} (código ${code})`);

console.log("✓ Projeto Android ajustado.");

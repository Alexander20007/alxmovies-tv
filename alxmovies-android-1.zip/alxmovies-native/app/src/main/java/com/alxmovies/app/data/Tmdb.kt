package com.alxmovies.app.data

object Tmdb {
    private suspend fun paged(path: String, params: Map<String, Any?> = emptyMap()): Paged =
        Api.json.decodeFromString<Paged>(Api.tmdb(path, params))

    suspend fun trending(type: String = "movie", window: String = "week"): Paged =
        paged("/trending/$type/$window")

    suspend fun popular(type: String = "movie", page: Int = 1): Paged =
        paged("/$type/popular", mapOf("page" to page))

    suspend fun byGenre(type: String, genreId: Int, page: Int = 1): Paged =
        paged("/discover/$type", mapOf("with_genres" to genreId, "page" to page))

    suspend fun recommendations(type: String, id: Int, page: Int = 1): Paged =
        paged("/$type/$id/recommendations", mapOf("page" to page))

    suspend fun genres(type: String = "movie"): List<Genre> =
        Api.json.decodeFromString<GenreList>(Api.tmdb("/genre/$type/list")).genres
}

suspend fun Tmdb.details(type: String, id: Int): MediaDetails {
    val append = if (type == "movie") "similar,release_dates" else "similar,content_ratings"
    val d = Api.json.decodeFromString<MediaDetails>(Api.tmdb("/$type/$id", mapOf("append_to_response" to append)))
    if (!d.overview.isNullOrBlank()) return d
    // sem sinopse em português: tenta em inglês
    val fb = runCatching {
        Api.json.decodeFromString<MediaDetails>(Api.tmdb("/$type/$id", mapOf("language" to "en-US"))).overview
    }.getOrNull()
    return if (!fb.isNullOrBlank()) d.copy(overview = fb) else d
}

suspend fun Tmdb.season(tvId: Int, season: Int): List<Episode> =
    Api.json.decodeFromString<SeasonDetail>(Api.tmdb("/tv/$tvId/season/$season")).episodes

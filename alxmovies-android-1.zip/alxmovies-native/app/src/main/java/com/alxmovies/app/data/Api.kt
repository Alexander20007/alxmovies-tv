package com.alxmovies.app.data

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class ApiException(message: String, val code: Int = 0) : Exception(message)

@Serializable
private data class AuthUserDto(
    val id: String,
    val email: String? = null,
    @SerialName("is_anonymous") val isAnonymous: Boolean? = false,
)

@Serializable
private data class AuthResp(
    @SerialName("access_token") val accessToken: String? = null,
    @SerialName("refresh_token") val refreshToken: String? = null,
    @SerialName("expires_in") val expiresIn: Long? = null,
    @SerialName("expires_at") val expiresAt: Long? = null,
    val user: AuthUserDto? = null,
)

/** Fala direto com a API REST do Supabase (login + banco) e com a função do TMDB. */
object Api {
    val json = Json {
        ignoreUnknownKeys = true
        coerceInputValues = true
        explicitNulls = false
        isLenient = true
    }

    private val jsonType = "application/json".toMediaType()
    private val refreshLock = Mutex()

    private val client: OkHttpClient = OkHttpClient.Builder()
        .addInterceptor { chain ->
            chain.proceed(chain.request().newBuilder().header("Origin", Config.SITE_ORIGIN).build())
        }
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private fun nowSec() = System.currentTimeMillis() / 1000

    private fun build(
        url: String,
        method: String,
        body: String? = null,
        bearer: String? = null,
        extra: Map<String, String> = emptyMap(),
    ): Request {
        val b = Request.Builder().url(url)
            .header("apikey", Config.SUPABASE_ANON_KEY)
            .header("Authorization", "Bearer " + (bearer ?: Config.SUPABASE_ANON_KEY))
        for ((k, v) in extra) b.header(k, v)
        val rb = if (method == "GET") null else (body ?: "").toRequestBody(jsonType)
        return b.method(method, rb).build()
    }

    /** Chamada de rede que cancela de verdade quando a corrotina é cancelada. */
    private suspend fun exec(req: Request, readTimeoutSec: Long? = null): Pair<Int, String> =
        suspendCancellableCoroutine { cont ->
            val c = if (readTimeoutSec == null) client else client.newBuilder().readTimeout(readTimeoutSec, TimeUnit.SECONDS).build()
            val call = c.newCall(req)
            cont.invokeOnCancellation { call.cancel() }
            call.enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    if (cont.isActive) cont.resumeWithException(ApiException("Sem conexão. Verifique sua internet."))
                }

                override fun onResponse(call: Call, response: Response) {
                    try {
                        val text = response.body?.string() ?: ""
                        val code = response.code
                        if (cont.isActive) cont.resume(code to text)
                    } catch (e: IOException) {
                        if (cont.isActive) cont.resumeWithException(ApiException("Sem conexão. Verifique sua internet."))
                    } finally {
                        response.close()
                    }
                }
            })
        }

    private fun errorOf(code: Int, body: String): ApiException {
        val msg = runCatching {
            val o = json.parseToJsonElement(body).jsonObject
            (o["msg"] ?: o["message"] ?: o["error_description"] ?: o["error"])?.jsonPrimitive?.contentOrNull
        }.getOrNull()
        return ApiException(msg ?: "Erro $code", code)
    }

    // ---------- sessão ----------

    private fun saveSession(r: AuthResp) {
        val s = Graph.session
        s.accessToken = r.accessToken
        s.refreshToken = r.refreshToken
        s.expiresAt = r.expiresAt ?: (nowSec() + (r.expiresIn ?: 3600L))
        s.userId = r.user?.id
        s.email = r.user?.email
        s.isAnonymous = r.user?.isAnonymous ?: false
        s.markLoggedIn()
    }

    private suspend fun refresh(): String? = refreshLock.withLock {
        val s = Graph.session
        if (nowSec() < s.expiresAt - 60) return@withLock s.accessToken
        val rt = s.refreshToken ?: return@withLock null
        val body = buildJsonObject { put("refresh_token", rt) }.toString()
        val (code, text) = exec(build("${Config.SUPABASE_URL}/auth/v1/token?grant_type=refresh_token", "POST", body))
        if (code in 200..299) {
            saveSession(json.decodeFromString<AuthResp>(text))
            s.accessToken
        } else {
            if (code == 400 || code == 401 || code == 403) s.clearAuth()
            null
        }
    }

    private suspend fun validToken(): String {
        val s = Graph.session
        val at = s.accessToken ?: throw ApiException("Usuário não autenticado", 401)
        if (nowSec() < s.expiresAt - 60) return at
        return refresh() ?: at
    }

    // ---------- auth ----------

    suspend fun signIn(email: String, password: String) {
        val body = buildJsonObject { put("email", email); put("password", password) }.toString()
        val (code, text) = exec(build("${Config.SUPABASE_URL}/auth/v1/token?grant_type=password", "POST", body))
        if (code !in 200..299) throw errorOf(code, text)
        saveSession(json.decodeFromString<AuthResp>(text))
        Graph.session.guestStartedAt = 0L
    }

    suspend fun signUp(email: String, password: String, username: String, age: Int, phone: String?) {
        val body = buildJsonObject {
            put("email", email)
            put("password", password)
            putJsonObject("data") {
                put("age", age)
                put("username", username)
                put("phone", phone)
            }
        }.toString()
        val (code, text) = exec(build("${Config.SUPABASE_URL}/auth/v1/signup", "POST", body))
        if (code !in 200..299) throw errorOf(code, text)
    }

    suspend fun signInAsGuest() {
        val (code, text) = exec(build("${Config.SUPABASE_URL}/auth/v1/signup", "POST", """{"data":{}}"""))
        if (code !in 200..299) throw errorOf(code, text)
        val r = json.decodeFromString<AuthResp>(text)
        if (r.accessToken == null) throw ApiException("Anonymous sign-ins are disabled")
        Graph.session.profileId = null
        saveSession(r)
        Graph.session.guestStartedAt = System.currentTimeMillis()
    }

    suspend fun requestPasswordReset(email: String) {
        val redirect = URLEncoder.encode("${Config.SITE_ORIGIN}/reset-password", "UTF-8")
        val body = buildJsonObject { put("email", email) }.toString()
        val (code, text) = exec(build("${Config.SUPABASE_URL}/auth/v1/recover?redirect_to=$redirect", "POST", body))
        if (code !in 200..299) throw errorOf(code, text)
    }

    suspend fun signOut() {
        val s = Graph.session
        val at = s.accessToken
        if (at != null) runCatching { exec(build("${Config.SUPABASE_URL}/auth/v1/logout", "POST", "{}", at)) }
        s.clearAuth()
    }

    // ---------- banco (PostgREST) ----------

    suspend fun rest(method: String, path: String, body: String? = null, returnRep: Boolean = false, prefer: String? = null): String {
        val pv = prefer ?: if (returnRep) "return=representation" else null
        val extra = if (pv != null) mapOf("Prefer" to pv) else emptyMap()
        for (attempt in 0..1) {
            val token = validToken()
            val (code, text) = exec(build("${Config.SUPABASE_URL}/rest/v1/$path", method, body, token, extra))
            if (code in 200..299) return text
            if (code == 401 && attempt == 0) {
                Graph.session.expiresAt = 0L // força renovar o token e tenta de novo
                continue
            }
            throw errorOf(code, text)
        }
        throw ApiException("Falha na requisição")
    }

    // ---------- TMDB (via função do Supabase) ----------

    suspend fun tmdb(path: String, params: Map<String, Any?> = emptyMap()): String {
        val body = buildJsonObject {
            put("path", path.trimStart('/'))
            putJsonObject("params") {
                put("language", "pt-BR")
                for ((k, v) in params) {
                    when (v) {
                        is Int -> put(k, v)
                        is String -> put(k, v)
                        is Boolean -> put(k, v)
                        else -> {}
                    }
                }
            }
        }.toString()
        val (code, text) = exec(build(Config.TMDB_FUNCTION_URL, "POST", body))
        if (code !in 200..299) throw ApiException("Erro TMDB: $code", code)
        return text
    }

    /** GET sem login; devolve (código, corpo) mesmo quando o código não é 2xx. */
    suspend fun getRaw(url: String, readTimeoutSec: Long = 30): Pair<Int, String> =
        exec(Request.Builder().url(url).get().build(), readTimeoutSec)

    suspend fun simpleGet(url: String): String {
        val (code, text) = exec(Request.Builder().url(url).get().build())
        if (code !in 200..299) throw ApiException("Erro $code", code)
        return text
    }
}

package com.alxmovies.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.alxmovies.app.data.Graph
import com.alxmovies.app.ui.details.DetailsScreen
import com.alxmovies.app.ui.home.HomeScreen
import com.alxmovies.app.ui.login.LoginScreen
import com.alxmovies.app.ui.profiles.ProfilesScreen
import com.alxmovies.app.ui.watch.WatchScreen

@Composable
fun AlxNav() {
    val nav = rememberNavController()
    val app: AppViewModel = viewModel()
    val loggedIn by app.loggedIn.collectAsStateWithLifecycle()

    val start = remember {
        val s = Graph.session
        when {
            !s.loggedIn -> "login"
            s.profileId == null -> "profiles"
            else -> "home"
        }
    }

    // Se a sessão cair (logout, token vencido, convidado expirado), volta para o login.
    LaunchedEffect(loggedIn) {
        if (!loggedIn && nav.currentBackStackEntry?.destination?.route != "login") {
            nav.navigate("login") { popUpTo(0) { inclusive = true } }
        }
    }

    NavHost(navController = nav, startDestination = start) {
        composable("login") {
            LoginScreen(app = app, onDone = {
                nav.navigate("profiles") { popUpTo("login") { inclusive = true } }
            })
        }
        composable("profiles") {
            ProfilesScreen(app = app, onEnter = {
                nav.navigate("home") { popUpTo("profiles") { inclusive = true } }
            })
        }
        composable("home") {
            HomeScreen(
                app = app,
                onSwitchProfile = {
                    app.clearProfile()
                    nav.navigate("profiles") { popUpTo("home") { inclusive = true } }
                },
                onOpenDetails = { t, i -> nav.navigate("details/$t/$i") },
                onPlay = { t, i -> nav.navigate("watch/$t/$i?s=-1&e=-1") },
            )
        }
        composable(
            "details/{type}/{id}",
            arguments = listOf(
                navArgument("type") { type = NavType.StringType },
                navArgument("id") { type = NavType.IntType },
            ),
        ) { entry ->
            val t = entry.arguments?.getString("type") ?: "movie"
            val i = entry.arguments?.getInt("id") ?: 0
            DetailsScreen(
                app = app, type = t, id = i,
                onBack = { nav.popBackStack() },
                onPlay = { pt, pid, s, e -> nav.navigate("watch/$pt/$pid?s=${s ?: -1}&e=${e ?: -1}") },
                onOpen = { ot, oid -> nav.navigate("details/$ot/$oid") },
            )
        }
        composable(
            "watch/{type}/{id}?s={s}&e={e}",
            arguments = listOf(
                navArgument("type") { type = NavType.StringType },
                navArgument("id") { type = NavType.IntType },
                navArgument("s") { type = NavType.IntType; defaultValue = -1 },
                navArgument("e") { type = NavType.IntType; defaultValue = -1 },
            ),
        ) { entry ->
            val a = entry.arguments
            WatchScreen(
                app = app,
                type = a?.getString("type") ?: "movie",
                id = a?.getInt("id") ?: 0,
                season = a?.getInt("s") ?: -1,
                episode = a?.getInt("e") ?: -1,
                onClose = { nav.popBackStack() },
            )
        }
    }
}

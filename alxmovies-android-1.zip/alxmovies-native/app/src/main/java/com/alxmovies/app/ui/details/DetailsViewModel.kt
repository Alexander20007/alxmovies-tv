package com.alxmovies.app.ui.details

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.alxmovies.app.data.ContentFilter
import com.alxmovies.app.data.EpRef
import com.alxmovies.app.data.Episode
import com.alxmovies.app.data.Graph
import com.alxmovies.app.data.MediaDetails
import com.alxmovies.app.data.MediaUtil
import com.alxmovies.app.data.Profile
import com.alxmovies.app.data.Repo
import com.alxmovies.app.data.Tmdb
import com.alxmovies.app.data.addFavorite
import com.alxmovies.app.data.details
import com.alxmovies.app.data.isFavorite
import com.alxmovies.app.data.removeFavorite
import com.alxmovies.app.data.season
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class DetailsState(
    val loading: Boolean = true,
    val error: Boolean = false,
    val media: MediaDetails? = null,
    val blocked: Boolean = false,
    val fav: Boolean = false,
    val favBusy: Boolean = false,
    val season: Int = 1,
    val episodes: List<Episode> = emptyList(),
    val episodesLoading: Boolean = false,
    val start: EpRef? = null,
    val last: EpRef? = null,
    val resumeMovie: Boolean = false,
    val message: String? = null,
)

class DetailsViewModel : ViewModel() {
    private val session = Graph.session
    private val _state = MutableStateFlow(DetailsState())
    val state: StateFlow<DetailsState> = _state.asStateFlow()

    private var profile: Profile? = null
    private var type = "movie"
    private var id = 0
    private var loaded = false
    private val seasonCache = mutableMapOf<Int, List<Episode>>()

    fun load(profile: Profile, type: String, id: Int) {
        if (loaded) return
        loaded = true
        this.profile = profile
        this.type = type
        this.id = id
        viewModelScope.launch {
            val m = try {
                Tmdb.details(type, id)
            } catch (e: Exception) {
                _state.update { it.copy(loading = false, error = true) }
                return@launch
            }
            if (!ContentFilter.allowed(m.asItem(), profile)) {
                _state.update { it.copy(loading = false, media = m, blocked = true) }
                return@launch
            }
            val isTv = type == "tv"
            val last = if (isTv) MediaUtil.parseEp(session.pref(MediaUtil.key("lastep", profile.id, "tv", id))) else null
            val first = MediaUtil.seasonsList(m).firstOrNull()
            val start = if (isTv) last ?: EpRef(first?.seasonNumber ?: 1, 1) else null
            val resumeMovie = !isTv &&
                (session.pref(MediaUtil.key("resume", profile.id, type, id))?.toLongOrNull() ?: 0L) > 5L
            _state.update {
                it.copy(
                    loading = false, media = m, start = start, last = last, resumeMovie = resumeMovie,
                    season = start?.season ?: 1,
                )
            }
            runCatching { Repo.isFavorite(profile.id, id, type) }.onSuccess { f -> _state.update { it.copy(fav = f) } }
            if (isTv && start != null) loadSeason(start.season)
        }
    }

    private fun loadSeason(n: Int) {
        val cached = seasonCache[n]
        if (cached != null) {
            _state.update { it.copy(season = n, episodes = cached, episodesLoading = false) }
            return
        }
        _state.update { it.copy(season = n, episodes = emptyList(), episodesLoading = true) }
        viewModelScope.launch {
            val eps = runCatching { Tmdb.season(id, n) }.getOrDefault(emptyList())
            seasonCache[n] = eps
            _state.update { if (it.season == n) it.copy(episodes = eps, episodesLoading = false) else it }
        }
    }

    fun selectSeason(n: Int) = loadSeason(n)

    fun toggleFav() {
        val p = profile ?: return
        val m = _state.value.media ?: return
        if (_state.value.favBusy) return
        val now = _state.value.fav
        _state.update { it.copy(favBusy = true) }
        viewModelScope.launch {
            try {
                if (now) Repo.removeFavorite(p.id, id, type) else Repo.addFavorite(p.id, type, m)
                _state.update { it.copy(fav = !now, favBusy = false) }
            } catch (e: Exception) {
                _state.update { it.copy(favBusy = false, message = "Não foi possível atualizar sua lista: ${e.message ?: "tente de novo"}") }
            }
        }
    }

    fun consumeMessage() { _state.update { it.copy(message = null) } }
}

# ALXmovies nativo (Kotlin + Jetpack Compose)

## Como compilar (pelo celular, igual antes)
1. No repositório do GitHub, **substitua o conteúdo** de `.github/workflows/android-apk.yml` pelo arquivo `android-apk.yml` que veio junto.
2. Suba o arquivo `alxmovies-native.zip` na raiz do repositório (pode apagar o zip antigo).
3. O Actions compila e publica `ALXmovies.apk` em Releases. Mesmo `applicationId` e mesma chave de teste do app antigo: instala por cima.

## Etapa 1 (esta entrega)
- Login, cadastro, recuperar senha e convidado (nova sessão)
- Perfis: escolher, PIN, horário permitido (hora do servidor), criar perfil
- Início: destaques, continuar assistindo, assistidos, "porque você assistiu", em alta, populares e gêneros, com filtro de classificação do perfil

## Etapa 2: Detalhes + Player
- **Detalhes:** banner, classificação indicativa, nota/ano/duração, gêneros, sinopse, favoritar (minha lista), compartilhar, temporadas e episódios (séries), títulos parecidos, bloqueio por classificação do perfil
- **Player:** o mesmo player nativo (Media3/ExoPlayer) do app antigo, em `AlxPlayerActivity.java`: gestos, PiP, velocidade, legendas, qualidade, servidores
- **Fluxo de vídeo** (`data/Stream.kt`): API principal + API reserva, troca de servidor, próximo episódio automático, retoma de onde parou e salva o progresso no Supabase (`ui/watch/WatchViewModel.kt`)

## Próximas etapas
Busca, minha lista, canais ao vivo, salas, amigos/mensagens, Laura IA, notificações, atualizador, gerenciar perfis (foto, edição), código de recuperação de convidado, fileira de aniversário, avaliar/comentar, trailer, baixar.

## Arquivos principais
- `data/Api.kt` – login e banco do Supabase (REST) + TMDB
- `data/Repo.kt`, `data/ContentFilter.kt`, `data/Parental.kt`
- `ui/login`, `ui/profiles`, `ui/home`, `ui/details`, `ui/watch`

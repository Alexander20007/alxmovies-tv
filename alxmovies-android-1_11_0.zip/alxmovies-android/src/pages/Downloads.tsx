import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Icon } from "@/components/Icon";
import { Spinner } from "@/components/Spinner";
import { DownloadSettings } from "@/components/DownloadSettings";
import { useDownloads } from "@/context/DownloadsContext";
import { fmtBytes, fmtDuration, fmtEta, fmtSpeed, posterSrc, roomLinkFor, type DlItem } from "@/lib/downloads";

function statusLine(it: DlItem): string {
  const pct = Math.round(it.progress * 100);
  const size = it.estTotal > 0 ? `${fmtBytes(it.bytes)} de ~${fmtBytes(it.estTotal)}` : fmtBytes(it.bytes);
  switch (it.status) {
    case "downloading": {
      const left = it.estTotal > it.bytes && it.speed > 0 ? fmtEta((it.estTotal - it.bytes) / it.speed) : "";
      return [size, fmtSpeed(it.speed), left && `faltam ${left}`].filter(Boolean).join(" · ");
    }
    case "queued": return it.waitingWifi ? "Aguardando Wi-Fi" : "Na fila";
    case "paused": return `Pausado · ${fmtBytes(it.bytes)}`;
    case "error": return it.error || "Não foi possível baixar.";
    default: return `${pct}%`;
  }
}

const PILL: Record<string, string> = { downloading: "Baixando", queued: "Na fila", paused: "Pausado", error: "Erro" };

function Poster({ it }: { it: DlItem }) {
  const src = posterSrc(it);
  return src
    ? <img className="dlp-poster" src={src} alt="" loading="lazy" onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = "/assets/no-poster.png"; }} />
    : <span className="dlp-poster dlp-poster-ph"><Icon name="film" size={24} /></span>;
}

/** Anel que mostra quanto do espaço disponível os downloads ocupam. */
function Ring({ pct, label }: { pct: number; label: string }) {
  const r = 38, c = 2 * Math.PI * r;
  return (
    <div className="dlp-ring" aria-hidden>
      <svg viewBox="0 0 96 96">
        <circle cx="48" cy="48" r={r} className="bg" />
        <circle cx="48" cy="48" r={r} className="fg" strokeDasharray={c} strokeDashoffset={c * (1 - Math.max(pct, pct > 0 ? 0.04 : 0))} transform="rotate(-90 48 48)" />
      </svg>
      <b>{label}</b>
    </div>
  );
}

export default function DownloadsPage() {
  const d = useDownloads();
  const navigate = useNavigate();
  const [tabPick, setTabPick] = useState<"running" | "done" | null>(null);
  const [settings, setSettings] = useState(false);
  const [confirm, setConfirm] = useState<string | null>(null);
  const [note, setNote] = useState("");
  const [exporting, setExporting] = useState<string | null>(null);
  const [playing, setPlaying] = useState<string | null>(null);

  useEffect(() => { d.refreshStorage(); }, [d.refreshStorage]);   // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (!note) return; const t = setTimeout(() => setNote(""), 5000); return () => clearTimeout(t); }, [note]);

  const { running, done } = useMemo(() => ({
    running: d.items.filter((i) => i.status !== "done"),
    done: d.items.filter((i) => i.status === "done").sort((a, b) => b.finishedAt - a.finishedAt),
  }), [d.items]);

  // abre em "Baixando" se há algo em andamento; senão em "Prontos"
  const tab = tabPick ?? (running.length > 0 ? "running" : "done");
  const speed = running.reduce((s, i) => s + (i.status === "downloading" ? i.speed : 0), 0);
  const doneBytes = done.reduce((s, i) => s + i.bytes, 0);
  const st = d.storage;
  const used = st?.downloadsBytes ?? 0;
  const pct = st && used + st.freeBytes > 0 ? Math.min(1, used / (used + st.freeBytes)) : 0;
  const anyActive = running.some((i) => i.status === "downloading" || i.status === "queued");
  const anyPaused = running.some((i) => i.status === "paused" || i.status === "error");

  async function askRemove(id: string) {
    if (confirm !== id) { setConfirm(id); setTimeout(() => setConfirm((c) => (c === id ? null : c)), 4000); return; }
    setConfirm(null);
    await d.remove(id);
  }
  async function doExport(it: DlItem) {
    setExporting(it.id); setNote("");
    try { const p = await d.exportFile(it.id); setNote(`Salvo em ${p}`); }
    catch (e) { setNote(e instanceof Error && e.message ? e.message : "Não foi possível salvar o arquivo."); }
    setExporting(null);
  }
  async function doPlay(it: DlItem) {
    setPlaying(it.id);
    try { await d.play(it); } catch { setNote("Não foi possível abrir o vídeo. Os arquivos podem ter sido apagados."); }
    setPlaying(null);
  }
  function openRoom(it: DlItem) {
    const link = roomLinkFor(it);
    if (link) navigate(link); else setNote("Não foi possível abrir uma sala com este vídeo.");
  }

  const delBtn = (it: DlItem, label: string) => (
    <button type="button" className={`dlp-ic danger${confirm === it.id ? " on" : ""}`} aria-label={label} onClick={() => void askRemove(it.id)}>
      {confirm === it.id ? <small>Apagar?</small> : <Icon name="trash" size={19} />}
    </button>
  );

  return (
    <main className="dlp">
      <header className="dlp-head">
        <div>
          <h1>Downloads</h1>
          <p>{d.items.length === 0 ? "Assista sem internet, quando quiser" : `${done.length} ${done.length === 1 ? "pronto" : "prontos"}${running.length ? ` · ${running.length} em andamento` : ""}`}</p>
        </div>
        <button type="button" className="dlp-gear" aria-label="Configurações do download" onClick={() => setSettings(true)}><Icon name="settings" size={22} /></button>
      </header>

      <section className="dlp-hero" aria-label="Armazenamento">
        <div className="dlp-hero-top">
          <Ring pct={pct} label={`${Math.round(pct * 100)}%`} />
          <div className="dlp-hero-r">
            <span className="dlp-hero-k">Armazenamento</span>
            <b className="dlp-hero-v">{fmtBytes(used)}<small> usados · {st ? fmtBytes(st.freeBytes) : "—"} livres</small></b>
            <div className="dlp-bar" aria-hidden><i style={{ width: `${Math.max(pct > 0 ? 3 : 0, Math.round(pct * 100))}%` }} /></div>
          </div>
        </div>
        <div className="dlp-stats">
          <div className="dlp-stat s1"><span><Icon name="check" size={15} /></span><b>{done.length}</b><small>{done.length === 1 ? "Salvo" : "Salvos"}{done.length > 0 ? ` · ${fmtBytes(doneBytes)}` : ""}</small></div>
          <div className="dlp-stat s2"><span><Icon name="download" size={15} /></span><b>{running.length}</b><small>Baixando</small></div>
          <div className={`dlp-stat s3${speed > 0 ? " live" : ""}`}><span><Icon name="trending" size={15} /></span><b>{speed > 0 ? fmtSpeed(speed) : "—"}</b><small>{d.wifiOnly ? "Só Wi-Fi" : "Velocidade"}</small></div>
        </div>
      </section>

      <div className="dlp-tabs" role="tablist">
        <button type="button" role="tab" aria-selected={tab === "running"} className={tab === "running" ? "on" : ""} onClick={() => setTabPick("running")}>
          Baixando{running.length > 0 && <b>{running.length}</b>}
        </button>
        <button type="button" role="tab" aria-selected={tab === "done"} className={tab === "done" ? "on" : ""} onClick={() => setTabPick("done")}>
          Prontos{done.length > 0 && <b>{done.length}</b>}
        </button>
      </div>

      {note && <p className="dlp-note" role="status">{note}</p>}

      {tab === "running" && (
        <section>
          {running.length > 0 && (anyActive || anyPaused) && (
            <div className="dlp-sec-row">
              <span>{speed > 0 ? `${fmtSpeed(speed)} no total` : "Em andamento"}</span>
              <button type="button" className="dlp-link" onClick={() => (anyActive ? d.pauseAll() : d.resumeAll())}>
                <Icon name={anyActive ? "pause" : "play"} size={14} />{anyActive ? "Pausar tudo" : "Retomar tudo"}
              </button>
            </div>
          )}
          {running.length === 0 && (
            <div className="dlp-empty">
              <span className="dlp-empty-ico"><Icon name="download" size={34} /></span>
              <b>{done.length > 0 ? "Nada baixando agora" : "Nenhum download ainda"}</b>
              <p>Abra um filme ou episódio e toque em <b>Baixar</b>. Os vídeos ficam aqui e tocam sem internet, até nas salas.</p>
            </div>
          )}
          <div className="dlp-list">
            {running.map((it) => (
              <article key={it.id} className={`dlp-card st-${it.status}`}>
                <div className="dlp-poster-wrap">
                  <Poster it={it} />
                  <span className="dlp-pct">{Math.round(it.progress * 100)}%</span>
                </div>
                <div className="dlp-body">
                  <div className="dlp-title-row">
                    <b className="dlp-title">{it.title}</b>
                    <span className={`dlp-pill ${it.status}`}>{it.status === "queued" && it.waitingWifi ? "Wi-Fi" : PILL[it.status]}</span>
                  </div>
                  <div className={`dlp-prog${it.status === "downloading" ? " live" : ""}`} aria-hidden>
                    <i style={{ width: `${Math.max(2, Math.round(it.progress * 100))}%` }} className={it.status === "error" ? "err" : ""} />
                  </div>
                  <small className={it.status === "error" ? "dlp-err" : ""}>{statusLine(it)}</small>
                </div>
                <div className="dlp-act">
                  {it.status === "downloading" && <button type="button" className="dlp-ic" aria-label="Pausar" onClick={() => d.pause(it.id)}><Icon name="pause" size={20} /></button>}
                  {it.status === "queued" && <button type="button" className="dlp-ic" aria-label="Pausar" onClick={() => d.pause(it.id)}><Spinner size={16} /></button>}
                  {(it.status === "paused" || it.status === "error") && <button type="button" className="dlp-ic go" aria-label="Retomar" onClick={() => void d.resume(it)}><Icon name={it.status === "error" ? "refresh" : "play"} size={20} /></button>}
                  {delBtn(it, "Cancelar download")}
                </div>
              </article>
            ))}
          </div>
        </section>
      )}

      {tab === "done" && (
        <section>
          {done.length === 0 && (
            <div className="dlp-empty">
              <span className="dlp-empty-ico"><Icon name="film" size={34} /></span>
              <b>Nenhum vídeo pronto</b>
              <p>Quando um download terminar, ele aparece aqui para assistir sem internet.</p>
            </div>
          )}
          {done.length > 0 && (
            <div className="dlp-sec-row">
              <span>{done.length} {done.length === 1 ? "vídeo" : "vídeos"} · {fmtBytes(doneBytes)}</span>
              <button type="button" className="dlp-link danger" onClick={() => {
                if (confirm !== "__all__") { setConfirm("__all__"); setTimeout(() => setConfirm((c) => (c === "__all__" ? null : c)), 4000); return; }
                setConfirm(null); void d.removeCompleted();
              }}><Icon name="trash" size={14} />{confirm === "__all__" ? "Toque de novo para apagar tudo" : "Apagar todos"}</button>
            </div>
          )}
          <div className="dlp-list">
            {done.map((it) => (
              <article key={it.id} className="dlp-card st-done">
                <button type="button" className="dlp-poster-wrap play" onClick={() => void doPlay(it)} aria-label={`Assistir ${it.title}`}>
                  <Poster it={it} />
                  <span className="dlp-play">{playing === it.id ? <Spinner size={18} /> : <Icon name="play" size={22} />}</span>
                </button>
                <div className="dlp-body">
                  <b className="dlp-title">{it.title}</b>
                  <div className="dlp-meta">
                    {[fmtBytes(it.bytes), fmtDuration(it.durationSec), it.ext.toUpperCase()].filter(Boolean).map((t) => <span key={t}>{t}</span>)}
                  </div>
                  <div className="dlp-btns">
                    <button type="button" className="main" onClick={() => void doPlay(it)}><Icon name="play" size={15} />Assistir</button>
                    <button type="button" onClick={() => openRoom(it)}><Icon name="users" size={15} />Sala</button>
                    {it.exportable && <button type="button" disabled={exporting === it.id} onClick={() => void doExport(it)}>{exporting === it.id ? "Salvando…" : `.${it.ext}`}</button>}
                  </div>
                </div>
                <div className="dlp-act">{delBtn(it, "Apagar")}</div>
              </article>
            ))}
          </div>
        </section>
      )}

      {done.length > 0 && (
        <p className="dlp-tip"><Icon name="info" size={15} /><span><b>Sala sem gastar internet:</b> toque em “Sala” para criar uma sala com este vídeo. Quem tem o vídeo baixado assiste do próprio celular; os outros continuam usando a internet. “.{done[0].ext}” junta tudo em um arquivo na pasta Downloads/ALXmovies.</span></p>
      )}

      <DownloadSettings open={settings} onClose={() => setSettings(false)} />
    </main>
  );
}

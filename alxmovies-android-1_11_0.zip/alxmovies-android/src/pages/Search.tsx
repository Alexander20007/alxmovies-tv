import { useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { ChannelsBrowser } from "@/components/channels/ChannelsBrowser";
import { Icon } from "@/components/Icon";
import { MediaCard } from "@/components/MediaCard";
import { useProfile } from "@/context/ProfileContext";
import { useDebounce } from "@/hooks/useDebounce";
import { filterForProfile } from "@/lib/contentFilter";
import { mediaKind, type Kind } from "@/lib/mediaKind";
import { tmdb } from "@/services/tmdb";
import type { MediaItem, MediaType } from "@/types";

type TypeFilter = "" | "movie" | "tv" | "channels";
const TYPES: { id: TypeFilter; label: string }[] = [
  { id: "", label: "✨ Tudo" }, { id: "movie", label: "🎬 Filmes" }, { id: "tv", label: "📺 Séries" }, { id: "channels", label: "📡 Canais" },
];
const KIND_CHIPS: { id: Kind; label: string }[] = [
  { id: "filme", label: "🎬 Filmes" }, { id: "serie", label: "📺 Séries" }, { id: "dorama", label: "🎎 Doramas" }, { id: "anime", label: "🎌 Animes" },
  { id: "anim", label: "🧸 Animações" }, { id: "novela", label: "💃 Novelas" }, { id: "reality", label: "🎤 Reality" }, { id: "doc", label: "🎞️ Documentários" },
];
const RECENT_KEY = "alx.recent.searches";
const readRecent = (): string[] => { try { return JSON.parse(localStorage.getItem(RECENT_KEY) ?? "[]"); } catch { return []; } };
const writeRecent = (l: string[]) => { try { localStorage.setItem(RECENT_KEY, JSON.stringify(l.slice(0, 8))); } catch { /* sem armazenamento */ } };

export default function Search() {
  const { activeProfile } = useProfile();
  const [params] = useSearchParams();
  const initialType = ([ "movie", "tv", "channels" ].includes(params.get("type") ?? "") ? params.get("type") : "") as TypeFilter;
  const [term, setTerm] = useState(params.get("q") ?? "");
  const [type, setType] = useState<TypeFilter>(initialType);
  const [genre, setGenre] = useState("");
  const [recent, setRecent] = useState<string[]>(readRecent);
  const [open, setOpen] = useState(() => !!(params.get("q") || params.get("focus")));   // a barra de digitação só aparece quando a pessoa quer digitar
  const [kind, setKind] = useState<Kind | "">("");
  const inputRef = useRef<HTMLInputElement>(null);
  const query = useDebounce(term.trim(), 400);
  const isChannels = type === "channels";

  useEffect(() => { setGenre(""); }, [type]); // gêneros de filme e série são listas diferentes
  useEffect(() => { setKind(""); }, [query, type, genre]);
  useEffect(() => { if (open) { const t = window.setTimeout(() => inputRef.current?.focus(), 60); return () => window.clearTimeout(t); } }, [open]);
  const closeBar = () => { setTerm(""); setOpen(false); };

  const movieGenres = useQuery({ queryKey: ["genres", "movie"], queryFn: () => tmdb.genres("movie"), staleTime: Infinity });
  const tvGenres = useQuery({ queryKey: ["genres", "tv"], queryFn: () => tmdb.genres("tv"), staleTime: Infinity });
  const genreList = (type === "tv" ? tvGenres.data : movieGenres.data)?.genres ?? [];

  const searching = !isChannels && !!(query || genre);
  const results = useQuery({
    queryKey: ["search-page", query, type, genre],
    enabled: !isChannels,
    queryFn: async (): Promise<MediaItem[]> => {
      const mediaType = (type || "") as MediaType | "";
      if (query) {
        const data = await tmdb.search(query, mediaType || "multi");
        let list = data.results.filter((r) => r.media_type !== "person");
        if (genre) list = list.filter((r) => r.genre_ids?.includes(Number(genre)));
        return list;
      }
      if (genre) return (await tmdb.byGenre((mediaType || "movie") as MediaType, Number(genre))).results;
      return (await tmdb.popular((mediaType || "movie") as MediaType)).results; // sem busca: populares
    },
  });

  const items = useMemo(
    () => filterForProfile(results.data ?? [], activeProfile).filter((i) => i.poster_path),
    [results.data, activeProfile],
  );

  const typeOf = (m: MediaItem): MediaType => ((m.media_type === "tv" || (!m.media_type && (type === "tv" || (!m.title && m.name)))) ? "tv" : "movie");
  const kindCount = useMemo(() => {
    const c = new Map<Kind, number>();
    for (const m of items) { const k = mediaKind(m, typeOf(m)).kind; c.set(k, (c.get(k) ?? 0) + 1); }
    return c;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [items, type]);
  const shown = useMemo(() => (kind ? items.filter((m) => mediaKind(m, typeOf(m)).kind === kind) : items),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [items, kind, type]);

  const remember = (t: string) => {
    const v = t.trim();
    if (v.length < 2) return;
    const next = [v, ...readRecent().filter((x) => x.toLowerCase() !== v.toLowerCase())];
    writeRecent(next); setRecent(next.slice(0, 8));
  };
  const clearRecent = () => { writeRecent([]); setRecent([]); };
  const genreName = genreList.find((g) => String(g.id) === genre)?.name;
  const heading = query ? `Resultados para “${query}”` : genre ? genreName ?? "Gênero" : type === "tv" ? "Séries populares" : type === "movie" ? "Filmes populares" : "Populares agora";

  return (
    <div className="sx">
      <div className="sx-top">
        {open ? (
          <div className="sx-field sx-in">
            <button type="button" className="sx-back" aria-label="Fechar a busca" onClick={closeBar}><Icon name="arrowLeft" size={21} /></button>
            <input ref={inputRef} type="search" autoFocus value={term} onChange={(e) => setTerm(e.target.value)} enterKeyHint="search"
              onKeyDown={(e) => { if (e.key === "Enter") { remember(term); (e.target as HTMLInputElement).blur(); } }}
              placeholder={isChannels ? "Buscar canal…" : "Filmes, séries, doramas, animes…"} />
            {term && <button type="button" aria-label="Limpar" onClick={() => { setTerm(""); inputRef.current?.focus(); }}><Icon name="close" size={18} /></button>}
          </div>
        ) : (
          <>
            <div className="sx-ttl"><h1>Descubra</h1><small>Filmes, séries, doramas, animes e canais</small></div>
            <button type="button" className="sx-lupa" aria-label="Pesquisar" onClick={() => setOpen(true)}><Icon name="search" size={23} strokeWidth={2.4} /></button>
          </>
        )}
      </div>

      <div className="sx-chips" role="tablist" aria-label="Tipo">
        {TYPES.map((t) => (
          <button key={t.id || "all"} type="button" role="tab" aria-selected={type === t.id} className={type === t.id ? "on" : ""} onClick={() => setType(t.id)}>{t.label}</button>
        ))}
      </div>

      {!isChannels && genreList.length > 0 && (
        <div className="sx-chips sx-genres" aria-label="Gênero">
          <button type="button" className={!genre ? "on" : ""} onClick={() => setGenre("")}>Todos os gêneros</button>
          {genreList.map((g) => <button key={g.id} type="button" className={genre === String(g.id) ? "on" : ""} onClick={() => setGenre(String(g.id))}>{g.name}</button>)}
        </div>
      )}

      {isChannels ? (
        <ChannelsBrowser inline externalSearch={term} onClearSearch={() => setTerm("")} />
      ) : (
        <>
          {open && !term && !genre && recent.length > 0 && (
            <section className="sx-recent">
              <div><b>Buscas recentes</b><button type="button" onClick={clearRecent}>Limpar</button></div>
              <div className="sx-recent-list">{recent.map((r) => <button key={r} type="button" onClick={() => setTerm(r)}><Icon name="clock" size={15} /> {r}</button>)}</div>
            </section>
          )}

          {results.isSuccess && kindCount.size > 1 && (
            <div className="sx-chips sx-kinds" role="tablist" aria-label="Filtrar por tipo">
              <button type="button" role="tab" aria-selected={!kind} className={!kind ? "on" : ""} onClick={() => setKind("")}>Tudo <i>{items.length}</i></button>
              {KIND_CHIPS.filter((k) => kindCount.has(k.id)).map((k) => (
                <button key={k.id} type="button" role="tab" aria-selected={kind === k.id} className={kind === k.id ? "on" : ""} onClick={() => setKind(k.id)}>{k.label} <i>{kindCount.get(k.id)}</i></button>
              ))}
            </div>
          )}

          <div className="sx-head">
            <h2>{heading}</h2>
            {results.isSuccess && <small>{shown.length} {shown.length === 1 ? "título" : "títulos"}</small>}
          </div>

          {results.isLoading && <div className="sx-grid" aria-label="Buscando…">{Array.from({ length: 9 }, (_, i) => <div key={i} className="sx-skel" style={{ animationDelay: `${(i % 3) * 110}ms` }} />)}</div>}
          {results.isError && <div className="sx-state"><span>⚠️</span><p>Erro ao buscar. Tente novamente.</p></div>}
          {results.isSuccess && !shown.length && (
            <div className="sx-state"><span>🔍</span><p>{searching ? "Nenhum resultado encontrado." : "Nada por aqui."}</p><small>Tente outro nome ou outro gênero.</small></div>
          )}
          <div className="sx-grid" onClick={() => remember(term)}>
            {shown.map((m) => (
              <MediaCard key={`${m.media_type ?? type}-${m.id}`} id={m.id}
                type={typeOf(m)}
                title={m.title ?? m.name} posterPath={m.poster_path} rating={m.vote_average} item={m} />
            ))}
          </div>
        </>
      )}
    </div>
  );
}

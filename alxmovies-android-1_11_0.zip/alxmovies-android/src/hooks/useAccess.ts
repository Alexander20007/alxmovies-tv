import { useQuery } from "@tanstack/react-query";
import { fetchRoomTitles, planAllows, type RoomTitle } from "@/services/access";
import type { MediaType } from "@/types";

/** Títulos que o admin separou para as salas (e quais planos podem usar). Atualiza a cada 5 minutos. */
export function useRoomTitles() {
  const q = useQuery({ queryKey: ["room-titles"], queryFn: fetchRoomTitles, staleTime: 5 * 60_000, retry: 1 });
  const titles: RoomTitle[] = q.data ?? [];
  return {
    titles,
    /** o título é só de sala (some do catálogo normal)? */
    isRoomsOnly: (type: MediaType, id: number) => titles.some((t) => t.rooms_only && t.tmdb_id === id && t.media_type === type),
    find: (type: MediaType, id: number) => titles.find((t) => t.tmdb_id === id && t.media_type === type),
    canUse: (t: RoomTitle, planId: string | null | undefined) => planAllows(t.allowed_plans, planId),
  };
}

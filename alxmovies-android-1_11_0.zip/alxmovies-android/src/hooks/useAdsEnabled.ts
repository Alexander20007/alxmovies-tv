import { useQuery } from "@tanstack/react-query";
import { isNative } from "@/lib/native";
import { getAdConfig } from "@/lib/ads";
import { useAuth } from "@/context/AuthContext";
import { useProfile } from "@/context/ProfileContext";
import { usePlan } from "@/hooks/usePlan";

/** Configuração de anúncios do servidor (painel do admin). Atualiza a cada 5 minutos. */
export function useAdConfig() {
  const { user } = useAuth();
  return useQuery({ queryKey: ["ad-config", user?.id], queryFn: () => getAdConfig(true), staleTime: 5 * 60_000, retry: 1, enabled: isNative && !!user });
}

/** Anúncios do app: só no Android, só quando o servidor manda (plano Grátis, ou admin com "ver anúncios") e nunca em perfil Kids. */
export function useAdsEnabled(): boolean {
  const { showAds } = usePlan();
  const { activeProfile } = useProfile();
  const cfg = useAdConfig();
  const serverSays = cfg.data ? cfg.data.show : showAds;      // sem resposta do servidor: regra antiga (plano)
  return isNative && serverSays && !activeProfile?.is_kids;
}

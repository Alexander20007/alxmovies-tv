import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { adminAccessBlocks, adminAddAccessBlock, adminMyAccess, adminRemoveAccessBlock } from "@/services/admin";
import { Note, Section } from "./ui";

const COUNTRIES: [string, string][] = [
  ["AO", "Angola"], ["MZ", "Moçambique"], ["BR", "Brasil"], ["PT", "Portugal"], ["CV", "Cabo Verde"], ["GW", "Guiné-Bissau"], ["ST", "São Tomé e Príncipe"], ["TL", "Timor-Leste"],
  ["US", "Estados Unidos"], ["GB", "Reino Unido"], ["FR", "França"], ["DE", "Alemanha"], ["ES", "Espanha"], ["IT", "Itália"], ["ZA", "África do Sul"], ["NA", "Namíbia"],
  ["CD", "R. D. Congo"], ["CG", "Congo"], ["ZW", "Zimbábue"], ["ZM", "Zâmbia"], ["NG", "Nigéria"], ["GH", "Gana"], ["KE", "Quênia"], ["EG", "Egito"], ["MA", "Marrocos"],
  ["AR", "Argentina"], ["MX", "México"], ["CO", "Colômbia"], ["CL", "Chile"], ["CA", "Canadá"], ["IN", "Índia"], ["CN", "China"], ["RU", "Rússia"], ["JP", "Japão"], ["TR", "Turquia"],
];
const nameOf = (c: string) => COUNTRIES.find(([k]) => k === c)?.[1];

/** Bloqueio de IP e de país (tabela access_blocks). Só o dono mexe. */
export function BloqueiosTab() {
  const qc = useQueryClient();
  const list = useQuery({ queryKey: ["admin-blocks"], queryFn: adminAccessBlocks, retry: false });
  const mine = useQuery({ queryKey: ["admin-my-access"], queryFn: adminMyAccess, retry: false });
  const [kind, setKind] = useState<"ip" | "country">("country");
  const [value, setValue] = useState("");
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState<{ ok: boolean; text: string } | null>(null);
  const refresh = () => void qc.invalidateQueries({ queryKey: ["admin-blocks"] });

  async function add() {
    setBusy(true); setNote(null);
    try { await adminAddAccessBlock(kind, value, reason); setValue(""); setReason(""); setNote({ ok: true, text: "Bloqueio adicionado. Vale na próxima vez que o app abrir ou voltar do segundo plano." }); refresh(); }
    catch (e) { setNote({ ok: false, text: e instanceof Error ? e.message : "Não foi possível adicionar." }); }
    setBusy(false);
  }
  async function remove(id: number) {
    setBusy(true); setNote(null);
    try { await adminRemoveAccessBlock(id); refresh(); } catch (e) { setNote({ ok: false, text: e instanceof Error ? e.message : "Não foi possível remover." }); }
    setBusy(false);
  }

  if (list.isLoading) return <p className="wb-dim">Carregando…</p>;
  if (list.isError) return <p className="wb-dim">{(list.error as Error).message}</p>;
  const rows = list.data ?? [];

  return (
    <Section title="Bloqueio de IP e país">
      <p className="wb-dim ao-foot">
        {mine.data
          ? <>O servidor vê você como: IP <b>{mine.data.ip ?? "não detectado"}</b> · país <b>{mine.data.country ? `${mine.data.country}${nameOf(mine.data.country) ? ` (${nameOf(mine.data.country)})` : ""}` : "não detectado"}</b>. {(!mine.data.ip || !mine.data.country) && "Se aparecer “não detectado”, o servidor não está recebendo essa informação e o bloqueio correspondente não vai funcionar."}</>
          : "Verificando como o servidor vê você…"}
      </p>
      <p className="wb-dim ao-foot">Você (dono) nunca é bloqueado, e o painel recusa bloquear o seu IP ou país atual. Quem está bloqueado vê “Acesso indisponível” no app e deixa de receber os endereços das APIs de filmes e canais.</p>

      <div className="ao-prov">
        <div className="ao-seg">
          <button type="button" className={kind === "country" ? "on" : ""} onClick={() => { setKind("country"); setValue(""); }}>🌍 País</button>
          <button type="button" className={kind === "ip" ? "on" : ""} onClick={() => { setKind("ip"); setValue(""); }}>🌐 IP</button>
        </div>
        <label className="ao-field">{kind === "country" ? "País (código de 2 letras)" : "IP ou intervalo (ex.: 203.0.113.7 ou 203.0.113.0/24)"}
          <input value={value} list={kind === "country" ? "ao-countries" : undefined} autoCapitalize={kind === "country" ? "characters" : "off"} spellCheck={false} inputMode={kind === "ip" ? "decimal" : "text"}
            maxLength={kind === "country" ? 2 : 60} placeholder={kind === "country" ? "BR" : "203.0.113.7"} onChange={(e) => setValue(kind === "country" ? e.target.value.toUpperCase() : e.target.value.trim())} />
        </label>
        {kind === "country" && <datalist id="ao-countries">{COUNTRIES.map(([c, n]) => <option key={c} value={c}>{n}</option>)}</datalist>}
        <label className="ao-field">Motivo (só você vê)
          <input value={reason} maxLength={120} placeholder="Ex.: abuso, fraude…" onChange={(e) => setReason(e.target.value)} />
        </label>
        <Note note={note} />
        <button type="button" className="wb-btn primary" disabled={busy || !value} onClick={() => void add()}>{busy ? "Salvando…" : "Bloquear"}</button>
      </div>

      <h3 className="ao-sub">Bloqueados agora ({rows.length})</h3>
      {rows.length === 0 && <p className="wb-dim">Nenhum bloqueio ativo.</p>}
      <div className="ao-provs">
        {rows.map((r) => (
          <div key={r.id} className="ao-prov">
            <div className="ao-prov-head">
              <div>
                <b>{r.kind === "country" ? `🌍 ${r.value}${nameOf(r.value) ? ` · ${nameOf(r.value)}` : ""}` : `🌐 ${r.value}`}</b>
                <small>{r.reason ? `${r.reason} · ` : ""}desde {new Date(r.created_at).toLocaleDateString("pt-BR")}</small>
              </div>
              <button type="button" className="wb-btn" disabled={busy} onClick={() => void remove(r.id)}>Desbloquear</button>
            </div>
          </div>
        ))}
      </div>
    </Section>
  );
}

import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { adminApiEndpoints, adminSetApiEndpoint, type ApiEndpointRow } from "@/services/admin";
import { Note, Section } from "./ui";

function ApiRow({ r, onSaved }: { r: ApiEndpointRow; onSaved: () => void }) {
  const [url, setUrl] = useState(r.url);
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState<{ ok: boolean; text: string } | null>(null);
  const dirty = url.trim().replace(/\/+$/, "") !== r.url;

  async function save() {
    setBusy(true); setNote(null);
    try { await adminSetApiEndpoint(r.key, url); setNote({ ok: true, text: "Salvo. Os aparelhos pegam o novo endereço na próxima vez que abrirem o app." }); onSaved(); }
    catch (e) { setNote({ ok: false, text: e instanceof Error ? e.message : "Não foi possível salvar." }); }
    setBusy(false);
  }

  return (
    <div className="ao-prov">
      <div className="ao-prov-head"><div><b>{r.label}</b>{r.note && <small>{r.note}</small>}</div></div>
      <label className="ao-field">Endereço (https://…)
        <input value={url} inputMode="url" autoCapitalize="off" spellCheck={false} onChange={(e) => setUrl(e.target.value.trim())} />
      </label>
      <Note note={note} />
      <button type="button" className="wb-btn primary" disabled={busy || !dirty} onClick={() => void save()}>{busy ? "Salvando…" : "Salvar"}</button>
    </div>
  );
}

/** Endereços das APIs de filmes e canais (tabela api_endpoints). Só o dono mexe. */
export function ApisTab() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["admin-apis"], queryFn: adminApiEndpoints, retry: false });
  if (q.isLoading) return <p className="wb-dim">Carregando…</p>;
  if (q.isError) return <p className="wb-dim">{(q.error as Error).message}</p>;
  return (
    <Section title="APIs de filmes e canais">
      <p className="wb-dim ao-foot">Estes endereços ficam guardados no Supabase, não no código do app. Ao trocar, um endereço errado faz filmes ou canais pararem de carregar: confira antes de salvar.</p>
      <div className="ao-provs">
        {(q.data ?? []).map((r) => <ApiRow key={r.key + r.url} r={r} onSaved={() => void qc.invalidateQueries({ queryKey: ["admin-apis"] })} />)}
      </div>
    </Section>
  );
}

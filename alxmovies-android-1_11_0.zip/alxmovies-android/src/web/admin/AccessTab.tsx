import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { adminChannelRuleSet, adminRoomTitleRemove, adminRoomTitleSave } from "@/services/admin";
import { fetchChannelRules, fetchRoomTitles, type ChannelRule, type RoomTitle } from "@/services/access";
import { getAllCategoriesRaw } from "@/services/channels";
import { posterUrl, tmdb } from "@/services/tmdb";
import { useDebounced, Note, PLAN_IDS, PLAN_NAME, Section } from "./ui";

/** Caixinhas de plano: todas marcadas = liberado para todos (guardado como "sem restrição"). */
function PlanChecks({ value, onChange }: { value: string[] | null; onChange: (v: string[] | null) => void }) {
  const cur = value && value.length ? value : [...PLAN_IDS];
  const toggle = (id: string) => {
    const next = cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id];
    if (next.length === 0) return;                                  // precisa sobrar ao menos um plano
    onChange(next.length === PLAN_IDS.length ? null : next);
  };
  return (
    <div className="ao-chips">
      {PLAN_IDS.map((id) => (
        <button key={id} type="button" className={`ao-chip${cur.includes(id) ? " on" : ""}`} onClick={() => toggle(id)}>{cur.includes(id) ? "✓ " : ""}{PLAN_NAME[id]}</button>
      ))}
    </div>
  );
}

function TitlesSection() {
  const qc = useQueryClient();
  const list = useQuery({ queryKey: ["room-titles"], queryFn: fetchRoomTitles });
  const [term, setTerm] = useState(""); const q = useDebounced(term.trim(), 450);
  const [note, setNote] = useState<{ ok: boolean; text: string } | null>(null);
  const found = useQuery({ queryKey: ["admin-title-search", q], enabled: q.length >= 2, queryFn: () => tmdb.searchAll(q, "multi") });
  const results = (found.data?.results ?? []).filter((r) => r.media_type === "movie" || r.media_type === "tv").slice(0, 8);
  const have = new Set((list.data ?? []).map((t) => `${t.media_type}:${t.tmdb_id}`));
  const refresh = () => { void qc.invalidateQueries({ queryKey: ["room-titles"] }); };
  const run = async (fn: () => Promise<unknown>, ok: string) => {
    setNote(null);
    try { await fn(); setNote({ ok: true, text: ok }); refresh(); } catch (e) { setNote({ ok: false, text: e instanceof Error ? e.message : "Não foi possível salvar." }); }
  };
  const save = (t: RoomTitle, patch: Partial<Pick<RoomTitle, "rooms_only" | "allowed_plans">>) =>
    run(() => adminRoomTitleSave({ tmdbId: t.tmdb_id, type: t.media_type, title: t.title, poster: t.poster_path, roomsOnly: patch.rooms_only ?? t.rooms_only, allowed: patch.allowed_plans === undefined ? t.allowed_plans : patch.allowed_plans }), "Salvo.");

  return (
    <Section title="Filmes e séries das salas">
      <p className="wb-dim ao-foot">Títulos que você escolhe para as salas. Com <b>“Só em salas”</b> ligado, o título some do catálogo normal e só aparece ao criar sala. Desligue para ele voltar ao catálogo. Escolha também quais planos podem usar.</p>
      <div className="ao-form">
        <label>Adicionar título<input type="search" value={term} onChange={(e) => setTerm(e.target.value)} placeholder="Buscar filme ou série…" /></label>
      </div>
      {results.length > 0 && (
        <div className="ao-list">
          {results.map((r) => {
            const type = r.media_type as "movie" | "tv"; const name = (r as { title?: string; name?: string }).title ?? (r as { name?: string }).name ?? "";
            return (
              <div key={`${type}${r.id}`} className="ao-row">
                <div className="ao-titlecell"><img src={posterUrl(r.poster_path ?? null, "w92")} alt="" /><div><b>{name}</b><small>{type === "tv" ? "Série" : "Filme"}</small></div></div>
                <button type="button" className="wb-btn primary" disabled={have.has(`${type}:${r.id}`)}
                  onClick={() => void run(() => adminRoomTitleSave({ tmdbId: r.id, type, title: name, poster: r.poster_path ?? null, roomsOnly: true, allowed: null }), `“${name}” adicionado.`)}>
                  {have.has(`${type}:${r.id}`) ? "Já está" : "Adicionar"}
                </button>
              </div>
            );
          })}
        </div>
      )}
      <Note note={note} />
      <div className="ao-list">
        {(list.data ?? []).map((t) => (
          <div key={t.id} className="ao-row col">
            <div className="ao-titlecell"><img src={posterUrl(t.poster_path, "w92")} alt="" /><div><b>{t.title}</b><small>{t.media_type === "tv" ? "Série" : "Filme"} · {t.rooms_only ? "só em salas" : "também no catálogo"}</small></div></div>
            <label className="ao-check"><input type="checkbox" checked={t.rooms_only} onChange={(e) => void save(t, { rooms_only: e.target.checked })} />Só em salas (some do catálogo normal)</label>
            <div><small className="wb-dim">Planos que podem usar nas salas</small><PlanChecks value={t.allowed_plans} onChange={(v) => void save(t, { allowed_plans: v })} /></div>
            <div className="wb-row"><button type="button" className="wb-btn wb-out" onClick={() => { if (window.confirm(`Tirar “${t.title}” da lista das salas? Ele volta ao catálogo normal.`)) void run(() => adminRoomTitleRemove(t.id), "Removido da lista."); }}>Remover da lista</button></div>
          </div>
        ))}
        {list.data && !list.data.length && <p className="wb-dim">Nenhum título separado ainda.</p>}
      </div>
    </Section>
  );
}

function ChannelsSection() {
  const qc = useQueryClient();
  const cats = useQuery({ queryKey: ["admin-channel-cats"], queryFn: getAllCategoriesRaw, staleTime: 10 * 60_000 });
  const rules = useQuery({ queryKey: ["admin-channel-rules"], queryFn: fetchChannelRules });
  const [filter, setFilter] = useState("");
  const [note, setNote] = useState<{ ok: boolean; text: string } | null>(null);
  const byCat = new Map<string, ChannelRule>((rules.data ?? []).map((r) => [r.category, r]));
  const rows = (cats.data ?? []).filter((c) => c.name && c.name.toLowerCase().includes(filter.trim().toLowerCase()));

  async function set(cat: string, allowed: string[] | null, hidden: boolean) {
    setNote(null);
    try { await adminChannelRuleSet(cat, allowed, hidden); await qc.invalidateQueries({ queryKey: ["admin-channel-rules"] }); }
    catch (e) { setNote({ ok: false, text: e instanceof Error ? e.message : "Não foi possível salvar." }); }
  }
  async function bulk(allowed: string[] | null) {
    if (!rows.length || !window.confirm(`Aplicar a ${rows.length} ${rows.length === 1 ? "categoria" : "categorias"}?`)) return;
    setNote(null);
    try {
      for (const c of rows) await adminChannelRuleSet(c.name!, allowed, false);
      await qc.invalidateQueries({ queryKey: ["admin-channel-rules"] }); setNote({ ok: true, text: "Regras aplicadas." });
    } catch (e) { setNote({ ok: false, text: e instanceof Error ? e.message : "Não foi possível salvar." }); }
  }

  return (
    <Section title="Canais ao vivo por categoria">
      <p className="wb-dim ao-foot">Escolha quais planos veem cada categoria. Quem não tem acesso vê a categoria com cadeado e um convite para o plano; “Ocultar” esconde de todo mundo. As categorias vêm da lista de canais do app.</p>
      <div className="ao-form">
        <input type="search" value={filter} onChange={(e) => setFilter(e.target.value)} placeholder="Filtrar categorias…" />
        <div className="ao-chips">
          <button type="button" className="ao-chip" onClick={() => void bulk(null)}>Liberar todas as listadas</button>
          <button type="button" className="ao-chip" onClick={() => void bulk(["apoiador", "premium", "familia"])}>Só planos pagos (listadas)</button>
          <button type="button" className="ao-chip" onClick={() => void bulk(["premium", "familia"])}>Só Premium e Família (listadas)</button>
        </div>
      </div>
      <Note note={note} />
      {(cats.isLoading || rules.isLoading) && <p className="wb-dim">Carregando categorias…</p>}
      {cats.isError && <p className="wb-form-err">Não foi possível carregar a lista de canais.</p>}
      <div className="ao-list">
        {rows.map((c) => {
          const key = c.name!.toUpperCase(); const r = byCat.get(key);
          return (
            <div key={key} className="ao-row col">
              <div className="ao-catline"><b>{c.name}</b><small>{c.count} canais{r?.hidden ? " · oculta" : r?.allowed_plans ? " · restrita" : ""}</small></div>
              <PlanChecks value={r?.allowed_plans ?? null} onChange={(v) => void set(c.name!, v, !!r?.hidden)} />
              <label className="ao-check"><input type="checkbox" checked={!!r?.hidden} onChange={(e) => void set(c.name!, r?.allowed_plans ?? null, e.target.checked)} />Ocultar para todos</label>
            </div>
          );
        })}
        {cats.data && !rows.length && <p className="wb-dim">Nenhuma categoria encontrada.</p>}
      </div>
    </Section>
  );
}

export function AccessTab() {
  return (<><TitlesSection /><ChannelsSection /></>);
}

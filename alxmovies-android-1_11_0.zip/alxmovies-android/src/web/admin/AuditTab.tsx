import { useQuery } from "@tanstack/react-query";
import { adminAuditFeed } from "@/services/admin";
import { fmtDateTime, Section } from "./ui";

const LABEL: Record<string, string> = {
  plano_ativado: "Plano ativado", plano_removido: "Plano removido", bonus_downloads: "Downloads extras", downloads_zerados: "Downloads zerados",
  conta_suspensa: "Conta suspensa", conta_reativada: "Conta reativada", admin_adicionado: "Admin adicionado", mensagem_enviada: "Mensagem enviada",
  mensagem_apagada: "Mensagem apagada", plano_editado: "Plano editado", downloads_site: "Número de downloads do site", api_editada: "Endereço de API alterado", bloqueio_add: "Bloqueio adicionado", bloqueio_remove: "Bloqueio removido", codigos_criados: "Códigos criados", codigo_apagado: "Código apagado", sala_encerrada: "Sala encerrada", plano_salas_editado: "Limites de sala editados", titulo_sala_salvo: "Título de sala salvo", titulo_sala_removido: "Título de sala removido", canal_categoria_regra: "Regra de categoria de canais", permissoes_admin: "Permissões de admin", anuncio_fonte: "Fonte de anúncio alterada", anuncio_regras: "Regras de anúncio alteradas",
};

export function AuditTab() {
  const q = useQuery({ queryKey: ["admin-audit"], queryFn: adminAuditFeed, retry: false });
  return (
    <Section title="Registro de ações">
      <p className="wb-dim ao-foot">Tudo que é feito neste painel fica anotado aqui.</p>
      {q.isError && <p className="wb-form-err">{(q.error as Error).message}</p>}
      <div className="ao-list">
        {(q.data ?? []).map((a) => (
          <div key={a.id} className="ao-row"><div><b>{LABEL[a.action] ?? a.action}{a.target_name ? ` · ${a.target_name}` : ""}</b>
            <small>por {a.admin_name ?? "—"}</small>
            <small>{fmtDateTime(a.created_at)}{a.details ? ` · ${Object.entries(a.details).filter(([k]) => k !== "lote").map(([k, v]) => `${k}: ${typeof v === "object" ? JSON.stringify(v) : String(v)}`).join(" · ")}` : ""}</small></div></div>
        ))}
        {q.data && !q.data.length && <p className="wb-dim">Nada registrado ainda.</p>}
      </div>
    </Section>
  );
}

import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { adminSetPublicDownloads } from "@/services/admin";
import { getPublicDownloads } from "@/services/siteDownloads";
import { useRelease } from "../release";
import { Note, Section, Stat, useMyPerms } from "./ui";

/** Só o dono vê aqui o número real do GitHub e escolhe o número que aparece no site para todo mundo. */
export function DownloadsCard() {
  const me = useMyPerms();
  const { info } = useRelease();
  const qc = useQueryClient();
  const pub = useQuery({ queryKey: ["site-downloads"], queryFn: getPublicDownloads, retry: false });
  const [val, setVal] = useState("");
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState<{ ok: boolean; text: string } | null>(null);
  useEffect(() => { if (pub.data !== undefined) setVal(pub.data ? String(pub.data) : ""); }, [pub.data]);
  if (!me.owner) return null;

  const save = async () => {
    const n = parseInt(val.replace(/\D/g, "") || "0", 10);
    setBusy(true); setNote(null);
    try {
      await adminSetPublicDownloads(n);
      await qc.invalidateQueries({ queryKey: ["site-downloads"] });
      setNote({ ok: true, text: n > 0 ? `Pronto! O site mostra ${n.toLocaleString("pt-BR")} downloads.` : "Pronto! O número deixou de aparecer no site." });
    } catch (e) { setNote({ ok: false, text: (e as Error).message }); }
    setBusy(false);
  };

  return (
    <Section title="Downloads do app">
      <div className="ao-stats small">
        <Stat label="APK no GitHub (real)" value={(info?.downloads ?? 0).toLocaleString("pt-BR")} hint="só você vê este número" />
        <Stat label="Mostrado no site" value={pub.data ? pub.data.toLocaleString("pt-BR") : "oculto"} hint="visível para todos" tone={pub.data ? "green" : undefined} />
      </div>
      <label className="ao-dl-lab">Número de downloads para mostrar no site
        <input value={val} inputMode="numeric" placeholder="Ex.: 12500 (0 = não mostrar)" onChange={(e) => setVal(e.target.value.replace(/[^\d]/g, ""))} />
      </label>
      <p className="wb-dim ao-foot">Some aqui as outras fontes (Lojas, outros sites…). Aparece na página inicial para qualquer pessoa, mesmo sem login. O número do GitHub não aparece mais para o público.</p>
      <button type="button" className="wb-btn primary" disabled={busy} onClick={() => void save()}>{busy ? "Salvando…" : "Salvar número"}</button>
      <Note note={note} />
    </Section>
  );
}

import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { adminStaffList, adminStaffSetPerms, type StaffMember } from "@/services/admin";
import { Note, PERMS, Section, fmtDate } from "./ui";

function Member({ m, onSaved }: { m: StaffMember; onSaved: () => void }) {
  const [perms, setPerms] = useState<string[]>(m.perms ?? []);
  const [note, setNote] = useState<{ ok: boolean; text: string } | null>(null);
  const dirty = perms.slice().sort().join() !== (m.perms ?? []).slice().sort().join();
  const toggle = (id: string) => setPerms((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));

  async function save() {
    setNote(null);
    try { await adminStaffSetPerms(m.user_id, perms); setNote({ ok: true, text: "Permissões salvas." }); onSaved(); }
    catch (e) { setNote({ ok: false, text: e instanceof Error ? e.message : "Não foi possível salvar." }); }
  }

  return (
    <div className="ao-permrow">
      <header>
        <div><b>{m.username}</b> <small className="wb-dim">admin desde {fmtDate(m.since)} · {perms.length} {perms.length === 1 ? "função liberada" : "funções liberadas"}</small></div>
        <div className="ao-inline">
          <button type="button" className="wb-btn" onClick={() => setPerms(PERMS.map((p) => p.id))}>Marcar tudo</button>
          <button type="button" className="wb-btn" onClick={() => setPerms([])}>Limpar</button>
        </div>
      </header>
      <div className="ao-permgrid">
        {PERMS.map((p) => (
          <label key={p.id} className={perms.includes(p.id) ? "on" : ""}>
            <input type="checkbox" checked={perms.includes(p.id)} onChange={() => toggle(p.id)} />
            <span><b>{p.label}</b><small>{p.hint}</small></span>
          </label>
        ))}
      </div>
      <Note note={note} />
      <button type="button" className="wb-btn primary" disabled={!dirty} onClick={() => void save()}>{dirty ? "Salvar permissões" : "Sem mudanças"}</button>
    </div>
  );
}

/** O dono escolhe, para cada admin, quais funções do painel ele pode usar. Quem não tem nenhuma continua só com as vantagens de admin. */
export function TeamPerms() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["admin-staff-perms"], queryFn: adminStaffList, retry: false });
  return (
    <Section title="Permissões dos admins">
      <p className="wb-dim ao-foot">Cada admin só vê no painel as funções que você liberar aqui. O que fazer com a equipe em si (adicionar, remover, dar permissões) é só do dono.</p>
      {q.isError && <p className="wb-form-err">{(q.error as Error).message}</p>}
      {q.data && !q.data.length && <p className="wb-dim">Ainda não há admins na equipe. Dê o cargo pela aba Usuários (“Tornar admin”).</p>}
      {(q.data ?? []).map((m) => <Member key={`${m.user_id}${(m.perms ?? []).join()}`} m={m} onSaved={() => { void qc.invalidateQueries({ queryKey: ["admin-staff-perms"] }); }} />)}
    </Section>
  );
}

import { useState, type ReactNode } from "react";
import { AccessTab } from "./AccessTab";
import { AdsTab } from "./AdsTab";
import { ApisTab } from "./ApisTab";
import { BloqueiosTab } from "./BloqueiosTab";
import { TeamPerms } from "./TeamPerms";
import { useMyPerms } from "./ui";
import { AuditTab } from "./AuditTab";
import { CodesTab } from "./CodesTab";
import { MessagesTab } from "./MessagesTab";
import { OverviewTab } from "./OverviewTab";
import { PlansTab } from "./PlansTab";
import { RoomsTab } from "./RoomsTab";
import { UsersTab } from "./UsersTab";

type Tab = { id: string; icon: string; label: string; desc: string; perm: string; group: string };

const TABS: Tab[] = [
  { id: "resumo", icon: "📊", label: "Resumo", desc: "Números do app em tempo real: contas, atividade, versões e downloads.", perm: "dashboard", group: "Visão geral" },
  { id: "usuarios", icon: "👥", label: "Usuários", desc: "Procure contas, veja planos e aparelhos e gerencie cada pessoa.", perm: "users", group: "Pessoas" },
  { id: "mensagens", icon: "✉️", label: "Mensagens", desc: "Envie avisos e mensagens oficiais para todos ou para quem você escolher.", perm: "messages", group: "Pessoas" },
  { id: "planos", icon: "⭐", label: "Planos", desc: "Edite o que cada plano oferece: downloads, canais, anúncios e preços.", perm: "plans_edit", group: "Pessoas" },
  { id: "codigos", icon: "🎟", label: "Códigos", desc: "Crie e acompanhe códigos promocionais e de acesso.", perm: "codes", group: "Pessoas" },
  { id: "acessos", icon: "🔑", label: "Salas e canais", desc: "Defina quem pode usar salas e quais categorias de canais cada plano libera.", perm: "access", group: "Conteúdo" },
  { id: "salas", icon: "🎬", label: "Salas", desc: "Acompanhe as salas de assistir junto que estão abertas agora.", perm: "rooms", group: "Conteúdo" },
  { id: "anuncios", icon: "📢", label: "Anúncios", desc: "Configure os provedores de anúncios e onde aparecem.", perm: "ads", group: "Conteúdo" },
  { id: "apis", icon: "🔌", label: "APIs", desc: "Endereços das APIs de filmes e canais, guardados no Supabase.", perm: "owner", group: "Sistema" },
  { id: "bloqueios", icon: "🚫", label: "Bloqueios", desc: "Bloqueie IPs e países para impedir o acesso ao app.", perm: "owner", group: "Sistema" },
  { id: "equipe", icon: "🛡", label: "Equipe", desc: "Admins, permissões e sugestões de aviso para aprovar.", perm: "owner", group: "Sistema" },
  { id: "registro", icon: "🧾", label: "Registro", desc: "Histórico de tudo o que foi alterado no painel.", perm: "audit", group: "Sistema" },
];

/** Painel completo do dono: menu lateral agrupado (vira barra rolável no celular), cabeçalho de comando e a seção escolhida. */
export function OwnerConsole({ team }: { team?: ReactNode }) {
  const me = useMyPerms();
  const tabs = TABS.filter((t) => (t.perm === "owner" ? me.owner : me.can(t.perm)));
  const [tab0, setTab] = useState<string>("");
  const tab = tab0 && tabs.some((t) => t.id === tab0) ? tab0 : tabs[0]?.id ?? "";
  const cur = tabs.find((t) => t.id === tab);
  const [preset, setPreset] = useState<Record<string, string> | undefined>();
  const go = (t: string, p?: Record<string, string>) => { setPreset(p); setTab(t); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const groups = [...new Set(tabs.map((t) => t.group))];
  const today = new Date().toLocaleDateString("pt-BR", { weekday: "long", day: "numeric", month: "long" });

  return (
    <div className="ao">
      {!me.loading && !tabs.length && <p className="wb-dim">Você ainda não tem funções liberadas. Peça ao dono para liberar no painel.</p>}

      {tabs.length > 0 && (
        <header className="ao-hero">
          <div className="ao-hero-aur" aria-hidden="true"><i /><i /></div>
          <div className="ao-hero-txt">
            <span className="ao-live"><u />Painel ao vivo</span>
            <h2>Central de controle</h2>
            <p>{today.charAt(0).toUpperCase() + today.slice(1)}</p>
          </div>
          <span className={`ao-role${me.owner ? " owner" : ""}`}>{me.owner ? "👑 Dono" : "🛡 Admin"}</span>
        </header>
      )}

      <div className="ao-shell">
        <nav className="ao-side" aria-label="Seções do painel">
          {groups.map((g) => (
            <div key={g} className="ao-grp">
              <span className="ao-grp-t">{g}</span>
              {tabs.filter((t) => t.group === g).map((t) => (
                <button key={t.id} type="button" className={tab === t.id ? "on" : ""} aria-current={tab === t.id ? "page" : undefined} onClick={() => go(t.id)}>
                  <i aria-hidden="true">{t.icon}</i><span>{t.label}</span>
                </button>
              ))}
            </div>
          ))}
        </nav>

        <main className="ao-main" key={tab}>
          {cur && <div className="ao-pagehead"><span aria-hidden="true">{cur.icon}</span><div><h3>{cur.label}</h3><p>{cur.desc}</p></div></div>}
          {tab === "resumo" && <OverviewTab go={go} />}
          {tab === "usuarios" && <UsersTab />}
          {tab === "mensagens" && <MessagesTab key={JSON.stringify(preset ?? {})} preset={preset} />}
          {tab === "planos" && <PlansTab />}
          {tab === "anuncios" && <AdsTab />}
          {tab === "acessos" && <AccessTab />}
          {tab === "codigos" && <CodesTab />}
          {tab === "salas" && <RoomsTab />}
          {tab === "apis" && me.owner && <ApisTab />}
          {tab === "bloqueios" && me.owner && <BloqueiosTab />}
          {tab === "equipe" && me.owner && (<>{team}<TeamPerms /></>)}
          {tab === "registro" && <AuditTab />}
        </main>
      </div>
    </div>
  );
}

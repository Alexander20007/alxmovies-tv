import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  adminAddBonus, adminResetDownloads, adminSetNote, adminSetPlan, adminSetSuspended, adminStaffAdd, adminUserDetail, adminUsers, adminDashboard,
  type AdminUser,
} from "@/services/admin";
import { Compose } from "./Compose";
import { ago, fmtDate, fmtDateTime, Note, PLAN_IDS, PLAN_NAME, Section, useDebounced, useMyPerms } from "./ui";

const ACTION: Record<string, string> = {
  plano_ativado: "Plano ativado", plano_removido: "Plano removido", bonus_downloads: "Downloads extras", downloads_zerados: "Downloads zerados",
  conta_suspensa: "Conta suspensa", conta_reativada: "Conta reativada", admin_adicionado: "Colocado na equipe",
};

function Drawer({ id, onClose }: { id: string; onClose: () => void }) {
  const qc = useQueryClient();
  const me = useMyPerms();
  const q = useQuery({ queryKey: ["admin-user", id], queryFn: () => adminUserDetail(id), retry: false });
  const [plan, setPlan] = useState("premium"); const [days, setDays] = useState("30");
  const [bonus, setBonus] = useState("5"); const [note, setNote] = useState(""); const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [showMsg, setShowMsg] = useState(false);
  const d = q.data;
  useEffect(() => { if (d) setNote(d.note); }, [d?.note]); // eslint-disable-line react-hooks/exhaustive-deps

  const refresh = () => { void qc.invalidateQueries({ queryKey: ["admin-user", id] }); void qc.invalidateQueries({ queryKey: ["admin-users"] }); void qc.invalidateQueries({ queryKey: ["admin-dashboard"] }); };
  const run = async (fn: () => Promise<unknown>, ok: string) => {
    setMsg(null);
    try { await fn(); setMsg({ ok: true, text: ok }); refresh(); } catch (e) { setMsg({ ok: false, text: e instanceof Error ? e.message : "Não foi possível concluir." }); }
  };

  return (
    <div className="ao-drawer-bg" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <aside className="ao-drawer" role="dialog" aria-modal="true">
        <header>
          <div><h2>{d?.username ?? "Carregando…"}</h2><small className="wb-dim">{d?.email_masked ?? ""}</small></div>
          <button type="button" className="wb-btn" onClick={onClose}>Fechar</button>
        </header>
        {q.isError && <p className="wb-form-err">{(q.error as Error).message}</p>}
        {d && (
          <>
            <Note note={msg} />
            <div className="ao-tags">
              {d.is_owner && <span className="ao-tag red">Dono</span>}
              {d.is_staff && !d.is_owner && <span className="ao-tag">Admin</span>}
              {d.is_guest && <span className="ao-tag">Convidado</span>}
              {d.suspended && <span className="ao-tag red">Suspensa</span>}
              <span className="ao-tag green">{PLAN_NAME[d.plan_now] ?? d.plan_now}</span>
            </div>

            <Section title="Conta e aparelho">
              <dl className="ao-dl">
                <dt>Criada em</dt><dd>{fmtDate(d.created_at)}</dd>
                <dt>Última vez no app</dt><dd>{d.device ? `${fmtDateTime(d.device.last_seen)} (${ago(d.device.last_seen)})` : d.last_sign_in ? fmtDateTime(d.last_sign_in) : "—"}</dd>
                <dt>Versão do app</dt><dd>{d.device?.app_version ?? "ainda não informou"}</dd>
                <dt>Aparelho</dt><dd>{d.device ? [d.device.os, d.device.model].filter(Boolean).join(" · ") || "—" : "—"}</dd>
                <dt>Aberturas</dt><dd>{d.device?.opens ?? 0}</dd>
                <dt>Perfis</dt><dd>{d.profiles.length ? d.profiles.map((p) => p.name + (p.kids ? " (infantil)" : "")).join(", ") : "—"}</dd>
                <dt>Notificações</dt><dd>{d.push_devices} {d.push_devices === 1 ? "aparelho" : "aparelhos"}</dd>
                <dt>Mensagens oficiais</dt><dd>{d.messages.sent} enviadas · {d.messages.unread} não lidas</dd>
              </dl>
              <p className="wb-dim ao-foot">O que a pessoa assiste, favoritos e conversas não aparecem aqui — são só dela.</p>
            </Section>

            {me.can("plans_give") && <Section title="Plano">
              <p className="wb-dim">{d.plan ? `Plano ${PLAN_NAME[d.plan.plan_id] ?? d.plan.plan_id} (${d.plan.source}) ${d.plan.expires_at ? `até ${fmtDate(d.plan.expires_at)}` : "sem vencimento"}` : "Sem plano pago (Grátis)."}</p>
              <div className="ao-inline">
                <select value={plan} onChange={(e) => setPlan(e.target.value)}>{PLAN_IDS.filter((p) => p !== "free").map((p) => <option key={p} value={p}>{PLAN_NAME[p]}</option>)}</select>
                <input value={days} onChange={(e) => setDays(e.target.value)} inputMode="numeric" aria-label="Dias" placeholder="dias" />
                <button type="button" className="wb-btn primary" onClick={() => void run(() => adminSetPlan(id, plan, parseInt(days, 10) || null), "Plano ativado.")}>Ativar plano</button>
              </div>
              <p className="wb-dim ao-foot">Deixe os dias em 0 para plano sem vencimento. Ativar de novo troca o plano atual.</p>
              <div className="ao-chips">
                {[["premium", 7], ["premium", 30], ["apoiador", 30], ["familia", 30]].map(([p, n]) => (
                  <button key={`${p}${n}`} type="button" className="ao-chip" onClick={() => void run(() => adminSetPlan(id, String(p), Number(n)), `${PLAN_NAME[String(p)]} por ${n} dias ativado.`)}>{PLAN_NAME[String(p)]} {n} d</button>
                ))}
                {d.plan && <button type="button" className="ao-chip danger" onClick={() => { if (window.confirm("Remover o plano pago desta conta?")) void run(() => adminSetPlan(id, "free", null), "Plano removido."); }}>Remover plano</button>}
              </div>
            </Section>}

            {me.can("plans_give") && <Section title="Downloads do mês">
              <p className="wb-dim">Usados: <b>{d.downloads?.used ?? 0}</b> · Extras: <b>{d.downloads?.bonus ?? 0}</b></p>
              <div className="ao-inline">
                <input value={bonus} onChange={(e) => setBonus(e.target.value)} inputMode="numeric" aria-label="Quantidade" />
                <button type="button" className="wb-btn" onClick={() => void run(() => adminAddBonus(id, parseInt(bonus, 10) || 0), "Downloads extras adicionados.")}>Dar extras</button>
                <button type="button" className="wb-btn" onClick={() => void run(() => adminResetDownloads(id), "Contador zerado.")}>Zerar usados</button>
              </div>
            </Section>}

            {me.can("messages") && <Section title="Mensagem para esta pessoa" right={<button type="button" className="wb-btn" onClick={() => setShowMsg((v) => !v)}>{showMsg ? "Esconder" : "Escrever"}</button>}>
              {showMsg && <Compose compact audience={{ type: "user", user_id: id }} onSent={refresh} />}
            </Section>}

            <Section title="Anotação interna">
              <textarea className="ao-ta" rows={3} maxLength={1000} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Só você vê (ex.: pagou o Premium por Pix em 12/11)" />
              <button type="button" className="wb-btn" onClick={() => void run(() => adminSetNote(id, note), "Anotação salva.")}>Salvar anotação</button>
            </Section>

            {!d.is_owner && (
              <Section title="Ações da conta">
                <div className="ao-chips">
                  {me.owner && !d.is_guest && !d.is_staff && <button type="button" className="ao-chip" onClick={() => { if (window.confirm("Colocar esta conta na equipe de admins?")) void run(() => adminStaffAdd(id, false), "Agora é admin."); }}>Tornar admin</button>}
                  {me.can("suspend") && <button type="button" className={`ao-chip ${d.suspended ? "" : "danger"}`} onClick={() => {
                    if (window.confirm(d.suspended ? "Reativar o acesso desta conta?" : "Suspender o acesso desta conta? Ela não conseguirá mais entrar.")) void run(() => adminSetSuspended(id, !d.suspended), d.suspended ? "Conta reativada." : "Conta suspensa.");
                  }}>{d.suspended ? "Reativar conta" : "Suspender conta"}</button>}
                </div>
              </Section>
            )}

            {d.recent.length > 0 && (
              <Section title="Últimas ações do painel">
                <div className="ao-list">{d.recent.map((r, i) => <div key={i} className="ao-row"><div><b>{ACTION[r.action] ?? r.action}</b><small>{fmtDateTime(r.created_at)}</small></div></div>)}</div>
              </Section>
            )}
          </>
        )}
      </aside>
    </div>
  );
}

const PAGE = 25;

export function UsersTab() {
  const [search, setSearch] = useState(""); const s = useDebounced(search);
  const [plan, setPlan] = useState(""); const [platform, setPlatform] = useState(""); const [version, setVersion] = useState("");
  const [only, setOnly] = useState(""); const [inactive, setInactive] = useState(""); const [page, setPage] = useState(0);
  const [open, setOpen] = useState<string | null>(null);
  useEffect(() => { setPage(0); }, [s, plan, platform, version, only, inactive]);

  const dash = useQuery({ queryKey: ["admin-dashboard"], queryFn: adminDashboard, retry: false });
  const q = useQuery({
    queryKey: ["admin-users", s, plan, platform, version, only, inactive, page], retry: false, placeholderData: (p) => p,
    queryFn: () => adminUsers({ search: s, plan, platform, version, only, inactiveDays: inactive ? Number(inactive) : null }, page * PAGE, PAGE),
  });
  const rows: AdminUser[] = q.data ?? [];
  const total = rows[0]?.total_count ?? 0;

  return (
    <>
      <div className="ao-filters">
        <input type="search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar por nome, perfil, ID ou e-mail exato" />
        <select value={plan} onChange={(e) => setPlan(e.target.value)}><option value="">Todos os planos</option>{PLAN_IDS.map((p) => <option key={p} value={p}>{PLAN_NAME[p]}</option>)}</select>
        <select value={version} onChange={(e) => setVersion(e.target.value)}><option value="">Todas as versões</option>{(dash.data?.by_version ?? []).map((v) => <option key={v.version} value={v.version}>{v.version} ({v.n})</option>)}</select>
        <select value={platform} onChange={(e) => setPlatform(e.target.value)}><option value="">App e site</option><option value="android">Android</option><option value="web">Site</option></select>
        <select value={only} onChange={(e) => setOnly(e.target.value)}><option value="">Todas as contas</option><option value="real">Só contas reais</option><option value="guest">Só convidados</option><option value="staff">Equipe</option><option value="suspended">Suspensas</option><option value="no_info">Sem info do app</option></select>
        <select value={inactive} onChange={(e) => setInactive(e.target.value)}><option value="">Qualquer atividade</option><option value="7">Sem abrir há 7 dias</option><option value="14">Sem abrir há 14 dias</option><option value="30">Sem abrir há 30 dias</option><option value="60">Sem abrir há 60 dias</option></select>
      </div>
      {q.isError && <p className="wb-form-err">{(q.error as Error).message}</p>}
      <p className="wb-dim ao-foot">{q.isLoading ? "Carregando…" : `${total} ${total === 1 ? "conta" : "contas"}`}</p>

      <div className="ao-list">
        {rows.map((u) => (
          <button key={u.user_id} type="button" className="ao-user" onClick={() => setOpen(u.user_id)}>
            <span className="ao-av">{u.username.slice(0, 1).toUpperCase()}</span>
            <span className="ao-user-main">
              <b>{u.username}{u.is_staff && <i className="ao-tag">admin</i>}{u.is_guest && <i className="ao-tag">convidado</i>}{u.suspended && <i className="ao-tag red">suspensa</i>}</b>
              <small>{u.email_masked ?? "sem e-mail"} · criada {fmtDate(u.created_at)}</small>
              <small>{u.app_version ? `v${u.app_version}` : "versão desconhecida"}{u.os ? ` · ${u.os}` : ""}{u.model ? ` · ${u.model}` : ""}</small>
            </span>
            <span className="ao-user-side">
              <em className={`ao-plan ${u.plan_id}`}>{PLAN_NAME[u.plan_id] ?? u.plan_id}</em>
              <small>{ago(u.last_seen)}</small>
            </span>
          </button>
        ))}
        {!q.isLoading && !rows.length && !q.isError && <p className="wb-dim">Nenhuma conta com esses filtros.</p>}
      </div>

      {total > PAGE && (
        <div className="ao-pager">
          <button type="button" className="wb-btn" disabled={page === 0} onClick={() => setPage((p) => p - 1)}>← Anterior</button>
          <span className="wb-dim">{page * PAGE + 1}–{Math.min(total, (page + 1) * PAGE)} de {total}</span>
          <button type="button" className="wb-btn" disabled={(page + 1) * PAGE >= total} onClick={() => setPage((p) => p + 1)}>Próxima →</button>
        </div>
      )}
      {open && <Drawer id={open} onClose={() => setOpen(null)} />}
    </>
  );
}

import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { adminPlanFeaturesUpdate, adminPlanUpdate } from "@/services/admin";
import { listPlans, type PlanInfo } from "@/services/plans";
import { Note, Section } from "./ui";

/** Valores sugeridos para começar (o admin ajusta). -1 = ilimitado · 0 = bloqueado. */
const SUGGEST: Record<string, { join: number; create: number; members: number; local: boolean }> = {
  free: { join: 5, create: 1, members: 4, local: false },
  apoiador: { join: 20, create: 5, members: 8, local: true },
  premium: { join: -1, create: 20, members: 20, local: true },
  familia: { join: -1, create: -1, members: 30, local: true },
};

function PlanRow({ p, onSaved }: { p: PlanInfo; onSaved: () => void }) {
  const [name, setName] = useState(p.name); const [dl, setDl] = useState(String(p.downloads_per_month));
  const [ads, setAds] = useState(p.show_ads); const [price, setPrice] = useState(p.price_brl == null ? "" : String(p.price_brl));
  const [join, setJoin] = useState(String(p.rooms_join_per_month ?? -1)); const [create, setCreate] = useState(String(p.rooms_create_per_month ?? -1));
  const [members, setMembers] = useState(String(p.rooms_max_members ?? -1)); const [local, setLocal] = useState(p.rooms_local_playback !== false);
  const [note, setNote] = useState<{ ok: boolean; text: string } | null>(null);
  const num = (v: string) => { const n = parseInt(v, 10); return Number.isFinite(n) ? n : -1; };

  async function save() {
    try {
      await adminPlanUpdate(p.id, name, parseInt(dl, 10) || 0, ads, price.trim() ? Number(price.replace(",", ".")) : null);
      await adminPlanFeaturesUpdate(p.id, num(join), num(create), num(members), local);
      setNote({ ok: true, text: "Salvo." }); onSaved();
    } catch (e) { setNote({ ok: false, text: e instanceof Error ? e.message : "Não foi possível salvar." }); }
  }
  const suggest = () => {
    const s = SUGGEST[p.id]; if (!s) return;
    setJoin(String(s.join)); setCreate(String(s.create)); setMembers(String(s.members)); setLocal(s.local);
  };

  return (
    <div className="ao-plan-row">
      <h4>{p.id}</h4>
      <div className="ao-grid2">
        <label>Nome<input value={name} maxLength={30} onChange={(e) => setName(e.target.value)} /></label>
        <label>Downloads por mês<input value={dl} inputMode="numeric" onChange={(e) => setDl(e.target.value)} /></label>
        <label>Preço (R$)<input value={price} inputMode="decimal" placeholder="em breve" onChange={(e) => setPrice(e.target.value)} /></label>
        <label className="ao-check"><input type="checkbox" checked={ads} onChange={(e) => setAds(e.target.checked)} />Mostra anúncios</label>
      </div>
      <h5 className="ao-sub">Salas</h5>
      <div className="ao-grid2">
        <label>Entrar em salas por mês<input value={join} inputMode="numeric" onChange={(e) => setJoin(e.target.value)} /></label>
        <label>Criar salas por mês<input value={create} inputMode="numeric" onChange={(e) => setCreate(e.target.value)} /></label>
        <label>Máx. de pessoas nas salas que ele cria<input value={members} inputMode="numeric" onChange={(e) => setMembers(e.target.value)} /></label>
        <label className="ao-check"><input type="checkbox" checked={local} onChange={(e) => setLocal(e.target.checked)} />Pode usar o filme baixado na sala</label>
      </div>
      <p className="wb-dim ao-foot">Use <b>-1</b> para ilimitado e <b>0</b> para bloquear. Vale na hora para todo mundo desse plano.</p>
      <Note note={note} />
      <div className="ao-inline">
        <button type="button" className="wb-btn primary" onClick={() => void save()}>Salvar {p.id}</button>
        {SUGGEST[p.id] && <button type="button" className="wb-btn" onClick={suggest}>Preencher com a sugestão</button>}
      </div>
    </div>
  );
}

export function PlansTab() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["admin-plans"], queryFn: listPlans });
  return (
    <Section title="Planos do app">
      <p className="wb-dim ao-foot">O app lê estes valores direto do servidor. Limites de sala valem também para quem ainda usa uma versão antiga do app.</p>
      {q.isLoading && <p className="wb-dim">Carregando…</p>}
      {(q.data ?? []).map((p) => <PlanRow key={`${p.id}|${p.downloads_per_month}|${p.price_brl}|${p.rooms_join_per_month}|${p.rooms_create_per_month}|${p.rooms_max_members}|${p.rooms_local_playback}`} p={p} onSaved={() => void qc.invalidateQueries({ queryKey: ["admin-plans"] })} />)}
    </Section>
  );
}

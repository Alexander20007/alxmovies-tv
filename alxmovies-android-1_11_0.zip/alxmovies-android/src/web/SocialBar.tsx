import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import { isSocialBarLoaded, loadSocialBar } from "@/lib/ads";

/**
 * Social Bar em todas as páginas do site, para todo mundo (visitante, logado ou admin).
 * Exceção de segurança: dentro do painel /admin o script de anúncio NÃO roda, porque um script de terceiros na mesma
 * página poderia ler a sessão do dono. Se alguém entrar no /admin com o script já carregado, a página recarrega limpa.
 */
export function SocialBarLoader() {
  const { pathname } = useLocation();
  const inAdmin = pathname.startsWith("/admin");
  useEffect(() => {
    if (inAdmin) { if (isSocialBarLoaded()) window.location.reload(); return; }
    void loadSocialBar();
  }, [inAdmin]);
  return null;
}

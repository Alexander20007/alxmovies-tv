import { registerPlugin } from "@capacitor/core";
import { CONFIG } from "./config";
import { isNative } from "./native";
import { supabase } from "./supabase";

// ============================================================================
// ANÚNCIOS. Quem manda é o painel do admin (tabelas ad_providers e ad_settings, via get_ad_config):
// liga/desliga cada fonte, chaves, tipos de anúncio e frequência. Se o servidor não responder, usa valores de reserva.
// App Android: Appodeal (plugin nativo "AlxAds"). Site: scripts só para convidados. Perfil Kids nunca vê anúncio.
// ============================================================================
export interface AdProvider { id: string; platform: "android" | "web"; priority: number; settings: Record<string, unknown> }
export interface AdConfig {
  show: boolean; master: boolean;
  settings: { interstitial: boolean; rewarded: boolean; banner: boolean; details_chance: number; download_chance: number; min_gap_seconds: number; max_per_session: number };
  providers: AdProvider[];
}

let cfg: AdConfig | null = null;
let cfgAt = 0;
let cfgLoading: Promise<AdConfig | null> | null = null;

/** Configuração de anúncios do servidor (guardada por 5 min). null = servidor indisponível → valores de reserva. */
export function getAdConfig(force = false): Promise<AdConfig | null> {
  if (!force && cfg && Date.now() - cfgAt < 5 * 60_000) return Promise.resolve(cfg);
  if (!cfgLoading) {
    cfgLoading = Promise.race([
      Promise.resolve(supabase.rpc("get_ad_config")).then(({ data, error }) => {
        if (!error && data) { cfg = data as AdConfig; cfgAt = Date.now(); }
        return cfg;
      }),
      new Promise<AdConfig | null>((r) => setTimeout(() => r(cfg), 4000)),
    ]).catch(() => cfg).finally(() => { cfgLoading = null; });
  }
  return cfgLoading;
}
export const cachedAdConfig = () => cfg;
const provider = (c: AdConfig | null, id: string) => c?.providers.find((p) => p.id === id);

// ---------------------------------------------------------------- SITE (só convidado)
let adsLoaded = false;
let popunderTriggered = false;

function appendScript(src: string, opts: { async?: boolean; crossOrigin?: string } = {}) {
  const s = document.createElement("script");
  s.src = src;
  if (opts.async) s.async = true;
  if (opts.crossOrigin) s.crossOrigin = opts.crossOrigin;
  document.head.appendChild(s);
}

const WEB_FALLBACK = {
  client: "ca-pub-7077223794117969",
  script: "https://pl30985121.profitableratecpmnetwork.com/1f/7b/f9/1f7bf9cd0034b71632dd37aa9bde3e0b.js",
  popunder: "https://pl30985122.profitableratecpmnetwork.com/59/57/05/595705690e8a90c8a2904755219af8f3.js",
};
const httpsOnly = (u: unknown) => (typeof u === "string" && /^https:\/\//i.test(u) ? u : null);

export async function loadAdsForGuest() {
  if (isNative || adsLoaded) return;
  adsLoaded = true;
  const c = await getAdConfig();
  if (c && !c.master) return;
  const sense = c ? provider(c, "adsense") : { settings: { client: WEB_FALLBACK.client } };
  const sterra = c ? provider(c, "adsterra") : { settings: { script_url: WEB_FALLBACK.script } };
  const client = String(sense?.settings.client ?? "");
  if (sense && /^ca-pub-\d+$/.test(client)) appendScript(`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${client}`, { async: true, crossOrigin: "anonymous" });
  const sc = httpsOnly(sterra?.settings.script_url);
  if (sterra && sc) appendScript(sc);
}

export async function triggerPopunderOnPlay() {
  if (isNative || popunderTriggered) return;
  popunderTriggered = true;
  const c = await getAdConfig();
  if (c && !c.master) return;
  const st = c ? provider(c, "adsterra") : { settings: { popunder_url: WEB_FALLBACK.popunder } };
  const u = httpsOnly(st?.settings.popunder_url);
  if (st && u) appendScript(u);
}

// ---- Social Bar (site): faixa discreta no canto, para TODOS os visitantes (logados e admins também) ----
const SOCIALBAR_FALLBACK = "https://bancadeltempoidea.org/14/9027a3e3f404ee39506c6ee18007a471";
let socialBarLoaded = false;
export const isSocialBarLoaded = () => socialBarLoaded;

export async function loadSocialBar() {
  if (isNative || socialBarLoaded) return;
  const c = await getAdConfig();
  if (c && !c.master) return;                                        // chave geral desligada no painel
  const p = c ? provider(c, "socialbar") : { settings: { script_url: SOCIALBAR_FALLBACK } };
  const u = httpsOnly(p?.settings.script_url);
  if (!p || !u || socialBarLoaded) return;                           // fonte desligada no painel
  socialBarLoaded = true;
  const el = document.createElement("script");
  el.src = u;
  el.setAttribute("data-cfasync", "false");
  document.head.appendChild(el);
}

/** O bloco do AdSense pode aparecer? (fonte ligada no painel) */
export async function adsenseClient(): Promise<string | null> {
  const c = await getAdConfig();
  if (!c) return WEB_FALLBACK.client;
  if (!c.master) return null;
  const p = provider(c, "adsense");
  const client = String(p?.settings.client ?? "");
  return p && /^ca-pub-\d+$/.test(client) ? client : null;
}

// ---------------------------------------------------------------- APP ANDROID (Appodeal)
interface AlxAdsPlugin {
  init(o: { appKey: string; testMode: boolean; interstitial: boolean; rewarded: boolean; banner: boolean }): Promise<{ ok: boolean; error?: string }>;
  showInterstitial(): Promise<{ shown: boolean }>;
  showRewarded(): Promise<{ completed: boolean; error?: string }>;
  showBanner(): Promise<{ heightDp: number }>;
  hideBanner(): Promise<void>;
}
const Native = registerPlugin<AlxAdsPlugin>("AlxAds");

let initP: Promise<boolean> | null = null;
export function initAds(): Promise<boolean> {
  if (!isNative) return Promise.resolve(false);
  if (!initP) {
    initP = (async () => {
      const c = await getAdConfig();
      const p = c ? provider(c, "appodeal") : { settings: { app_key: CONFIG.ADS.APPODEAL.APP_KEY, test_mode: CONFIG.ADS.APPODEAL.TEST_MODE } };
      if (!p || (c && !c.master)) return false;               // fonte desligada no painel
      const key = String(p.settings.app_key ?? "");
      if (!key) return false;
      const s = c?.settings ?? { interstitial: true, rewarded: true, banner: true };
      const r = await Native.init({ appKey: key, testMode: p.settings.test_mode === true, interstitial: s.interstitial, rewarded: s.rewarded, banner: s.banner });
      return !!r.ok;
    })().catch(() => false);
    initP.then((ok) => { if (!ok) initP = null; });          // se falhou ou estava desligada, tenta de novo depois
  }
  return initP;
}

/** O app deve mostrar este tipo de anúncio agora? (configuração mais recente do servidor) */
async function allowed(kind: "interstitial" | "rewarded" | "banner"): Promise<AdConfig["settings"] | null> {
  const c = await getAdConfig();
  if (!c) return { interstitial: true, rewarded: true, banner: true, details_chance: 0.3, download_chance: 0.5, min_gap_seconds: 240, max_per_session: 6 };
  if (!c.show || !c.master || !provider(c, "appodeal") || !c.settings[kind]) return null;
  return c.settings;
}

// ----- tela cheia (intersticial): sorteio, com intervalo mínimo e limite por sessão (valores vêm do painel) -----
let lastAt = 0, shownCount = 0, showing = false;

/** Sorteia se mostra um anúncio de tela cheia. `chance`: número 0..1 ou "details"/"download" (usa a chance do painel). Nunca durante vídeo. */
export async function maybeShowInterstitial(chance: number | "details" | "download"): Promise<boolean> {
  if (!isNative || showing) return false;
  const s = await allowed("interstitial");
  if (!s) return false;
  if (shownCount >= s.max_per_session) return false;
  if (Date.now() - lastAt < s.min_gap_seconds * 1000) return false;
  const p = typeof chance === "number" ? chance : chance === "details" ? s.details_chance : s.download_chance;
  if (Math.random() >= p) return false;
  if (!(await initAds())) return false;
  showing = true;
  try {
    const r = await Native.showInterstitial();
    if (r.shown) { lastAt = Date.now(); shownCount++; }
    return r.shown;
  } catch { return false; } finally { showing = false; }
}

/** Anúncio premiado (a pessoa escolhe assistir). completed = assistiu até o fim. */
export async function showRewardedAd(): Promise<{ completed: boolean; error?: string }> {
  if (!(await allowed("rewarded"))) return { completed: false, error: "disabled" };
  if (!(await initAds())) return { completed: false, error: "init" };
  try { const r = await Native.showRewarded(); if (r.completed) lastAt = Date.now(); return r; }
  catch { return { completed: false, error: "fail" }; }
}

// ----- banner (rodapé), só nas telas escolhidas -----
export async function setBanner(on: boolean): Promise<void> {
  if (!isNative) return;
  const root = document.documentElement;
  if (!on) {
    root.dataset.banner = "off"; root.style.setProperty("--ad-h", "0px");
    try { await Native.hideBanner(); } catch { /* ignora */ }
    return;
  }
  if (!(await allowed("banner")) || !(await initAds())) return;
  try {
    const r = await Native.showBanner();
    root.dataset.banner = "on"; root.style.setProperty("--ad-h", `${r.heightDp || 50}px`);
  } catch { /* sem anúncio agora: a tela continua normal */ }
}

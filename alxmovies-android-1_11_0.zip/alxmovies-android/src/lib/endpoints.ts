/**
 * Endereços das APIs de filmes e canais. NÃO ficam no código: vêm da tabela `api_endpoints` do Supabase
 * (o dono troca em Admin → APIs). O app guarda uma cópia no aparelho, então abre rápido e funciona mesmo
 * se o Supabase estiver fora do ar; ao abrir, atualiza a cópia em segundo plano.
 */
const CACHE_KEY = "alx:apis:v1";

function readCache(): Record<string, string> {
  try {
    const o = JSON.parse(localStorage.getItem(CACHE_KEY) || "{}");
    return o && typeof o === "object" ? o : {};
  } catch { return {}; }
}

let map: Record<string, string> = readCache();

/** Endereço atual da API (STREAM, EXTRACTOR, CHANNELS ou EPG). Vazio se ainda não foi carregado. */
export const getEndpoint = (key: string): string => map[key] ?? "";

/** Carrega os endereços. Com cópia salva abre na hora e atualiza em segundo plano; sem cópia (1ª vez) espera até 8 s. */
export function initEndpoints(supabaseUrl: string, anonKey: string): Promise<void> {
  const refresh = fetch(`${supabaseUrl}/rest/v1/rpc/get_api_endpoints`, {
    method: "POST",
    headers: { apikey: anonKey, Authorization: `Bearer ${anonKey}`, "Content-Type": "application/json" },
    body: "{}",
  })
    .then((r) => (r.ok ? r.json() : Promise.reject(new Error(String(r.status)))))
    .then((d: unknown) => {
      if (!d || typeof d !== "object") return;
      const next: Record<string, string> = {};
      for (const [k, v] of Object.entries(d as Record<string, unknown>)) if (typeof v === "string" && /^https:\/\/\S+$/.test(v)) next[k] = v.replace(/\/+$/, "");
      if (!Object.keys(next).length) return;
      map = { ...map, ...next };
      try { localStorage.setItem(CACHE_KEY, JSON.stringify(map)); } catch { /* sem espaço: segue sem cópia */ }
    })
    .catch(() => { /* offline: usa a cópia salva */ });
  if (Object.keys(map).length) return Promise.resolve();
  return Promise.race([refresh, new Promise<void>((r) => setTimeout(r, 8000))]);
}

/** Apaga a cópia salva (usado quando o aparelho está bloqueado, para não continuar usando os endereços). */
export function clearEndpoints() {
  map = {};
  try { localStorage.removeItem(CACHE_KEY); } catch { /* sem acesso ao armazenamento */ }
}

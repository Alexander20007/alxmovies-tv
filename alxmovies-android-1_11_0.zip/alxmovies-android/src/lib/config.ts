import { getEndpoint } from "./endpoints";

const env = import.meta.env;

// ── Proxy (Cloudflare Worker) ─────────────────────────────────────────────────────────────────────────
// Padrão: DESLIGADO — o app fala direto com os serviços, como sempre. Com VITE_USE_PROXY=true (build) tudo passa pelo proxy
// (JWT + nonce). A única parte que usa o proxy mesmo desligado é a verificação de versão nova (/release, pública).
const USE_PROXY: boolean = __USE_PROXY__;
const PROXY_URL = String(env.VITE_PROXY_URL ?? "https://alx-proxy.alexander221alex.workers.dev").replace(/\/+$/, "");

// Endereços diretos (com USE_PROXY = true este objeto vira {} e os textos somem do pacote).
const D: Record<string, string> = USE_PROXY ? {} : {
  SUPABASE: env.VITE_SUPABASE_URL ?? "https://onqxflwfkexitipylixc.supabase.co",
};
// Endereços das APIs de filmes e canais (STREAM, EXTRACTOR, CHANNELS, EPG): NÃO ficam no código.
// Vêm da tabela api_endpoints do Supabase (painel do admin → APIs), via src/lib/endpoints.ts.
const pick = (viaProxy: string, direct: string | undefined) => (USE_PROXY ? viaProxy : (direct as string));

export const CONFIG = {
  USE_PROXY,
  PROXY_URL,
  SUPABASE_URL: pick(`${PROXY_URL}/sb`, D.SUPABASE),
  SUPABASE_ANON_KEY: env.VITE_SUPABASE_ANON_KEY ?? "sb_publishable_P6xFktXhhIjgC4hVxD6FxA_EbPl-clT",
  /** Base das funções do Supabase chamadas "na mão" (convidado). */
  FUNCTIONS_URL: pick(`${PROXY_URL}/sb-fn`, D.SUPABASE ? `${D.SUPABASE}/functions/v1` : undefined),
  TMDB_FUNCTION_URL: pick(`${PROXY_URL}/sb-fn/bright-handler`, D.SUPABASE ? `${D.SUPABASE}/functions/v1/bright-handler` : undefined),
  GEMINI_FUNCTION_URL: pick(`${PROXY_URL}/sb-fn/smooth-endpoint`, D.SUPABASE ? `${D.SUPABASE}/functions/v1/smooth-endpoint` : undefined),
  TMDB_IMG_BASE: "https://image.tmdb.org/t/p",
  POSTER_SIZE: "w500",
  BACKDROP_SIZE: "w1280",
  /** APIs (pedidos com JWT + nonce) */
  get STREAM_BASE_URL() { return USE_PROXY ? `${PROXY_URL}/alx` : getEndpoint("STREAM"); },
  get EXTRACTOR_BASE_URL() { return USE_PROXY ? `${PROXY_URL}/jney` : getEndpoint("EXTRACTOR"); },
  /** Links de vídeo (player/1DM não mandam JWT/nonce): rotas de mídia do proxy, só /api/proxy e /proxy. */
  get STREAM_MEDIA_URL() { return USE_PROXY ? `${PROXY_URL}/alxm` : getEndpoint("STREAM"); },
  get EXTRACTOR_MEDIA_URL() { return USE_PROXY ? `${PROXY_URL}/jneym` : getEndpoint("EXTRACTOR"); },
  get CHANNELS_API_URL() { return USE_PROXY ? `${PROXY_URL}/canais` : getEndpoint("CHANNELS"); },
  get EPG_API_URL() { return USE_PROXY ? `${PROXY_URL}/epg` : getEndpoint("EPG"); },
  /** Versão nova: tenta o proxy (público, sem login) e, se falhar, o GitHub direto. */
  RELEASE_API_URL: `${PROXY_URL}/release`,
  RELEASE_DIRECT_URL: "https://api.github.com/repos/Alexander20007/alxmovies-tv/releases/latest",
  GEMINI_MODEL: env.VITE_GEMINI_MODEL ?? "gemini-3.5-flash",
  GUEST_SESSION_MS: 24 * 60 * 60 * 1000,
  /**
   * ANÚNCIOS (app Android): Appodeal. Quem manda de verdade é o painel do admin (/admin → Anúncios):
   * liga/desliga fontes, chave, modo teste, tipos de anúncio e frequência. Os valores abaixo são só de RESERVA
   * (usados se o servidor não responder).
   */
  ADS: {
    // Valores de RESERVA (se o servidor não responder). O painel do admin (Anúncios) é quem manda de verdade.
    APPODEAL: { APP_KEY: "e34f80ba027b3f6eedfe289b2317259d6a54cab1e14ffab5", TEST_MODE: false },
  },
} as const;

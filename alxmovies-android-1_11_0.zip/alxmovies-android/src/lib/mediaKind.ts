import type { MediaType } from "@/types";

export type Kind = "filme" | "serie" | "dorama" | "anime" | "novela" | "reality" | "doc" | "anim";
export interface KindInfo { kind: Kind; label: string }

const LABEL: Record<Kind, string> = { filme: "FILME", serie: "SÉRIE", dorama: "DORAMA", anime: "ANIME", novela: "NOVELA", reality: "REALITY", doc: "DOC.", anim: "ANIMAÇÃO" };
const DORAMA_LANGS = new Set(["ko", "ja", "zh", "cn", "th"]);
const DORAMA_COUNTRIES = new Set(["KR", "JP", "CN", "TW", "TH", "HK"]);

/**
 * Descobre o tipo do título a partir dos dados do TMDB: filme, série, dorama (série asiática de atores), anime (animação japonesa),
 * novela, reality, documentário ou animação. Sem os dados (ex.: lista salva), usa só filme/série.
 */
export function mediaKind(m: { genre_ids?: number[]; genres?: { id: number }[]; original_language?: string; origin_country?: string[] } | null | undefined, type: MediaType): KindInfo {
  const g = new Set<number>([...(m?.genre_ids ?? []), ...((m?.genres ?? []).map((x) => x.id))]);
  const lang = (m?.original_language ?? "").toLowerCase();
  const asia = DORAMA_LANGS.has(lang) || (m?.origin_country ?? []).some((c) => DORAMA_COUNTRIES.has(c));
  const japan = lang === "ja" || (m?.origin_country ?? []).includes("JP");
  const pick = (kind: Kind): KindInfo => ({ kind, label: LABEL[kind] });
  if (g.has(16)) return pick(japan ? "anime" : "anim");
  if (g.has(99)) return pick("doc");
  if (type === "tv") {
    if (g.has(10766)) return pick("novela");
    if (g.has(10764)) return pick("reality");
    if (asia) return pick("dorama");
    return pick("serie");
  }
  return pick("filme");
}

export const yearOf = (m: { release_date?: string; first_air_date?: string } | null | undefined): string | null => {
  const d = m?.release_date || m?.first_air_date || "";
  return /^\d{4}/.test(d) ? d.slice(0, 4) : null;
};

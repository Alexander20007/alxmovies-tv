import { supabase } from "@/lib/supabase";
import type { MediaType } from "@/types";

/** Regras de acesso controladas pelo admin (tabelas room_titles e channel_category_rules). Leitura liberada; só o dono altera. */
export interface RoomTitle {
  id: number; tmdb_id: number; media_type: MediaType; title: string; poster_path: string | null;
  rooms_only: boolean; allowed_plans: string[] | null; note: string | null; created_at: string;
}
export interface ChannelRule { category: string; allowed_plans: string[] | null; hidden: boolean }

export const PLAN_LABEL: Record<string, string> = { free: "Grátis", apoiador: "Apoiador", premium: "Premium", familia: "Família" };

/** null/vazio = todos os planos. */
export const planAllows = (allowed: string[] | null | undefined, planId: string | null | undefined) =>
  !allowed || allowed.length === 0 || (!!planId && allowed.includes(planId));

export const planNames = (ids: string[] | null | undefined) => (ids ?? []).map((i) => PLAN_LABEL[i] ?? i).join(", ");

export async function fetchRoomTitles(): Promise<RoomTitle[]> {
  const { data, error } = await supabase.from("room_titles").select("*").order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as RoomTitle[];
}

export async function fetchChannelRules(): Promise<ChannelRule[]> {
  const { data, error } = await supabase.from("channel_category_rules").select("*");
  if (error) throw error;
  return (data ?? []) as ChannelRule[];
}

/** Erros do servidor que começam com PLANO_ viram um aviso amigável + convite para ver os planos. */
export function parsePlanError(e: unknown): { plan: boolean; text: string } {
  const msg = e instanceof Error ? e.message : String(e ?? "");
  const m = /^PLANO_[A-Z_]+:\s*(.*)$/s.exec(msg.trim());
  return m ? { plan: true, text: m[1] } : { plan: false, text: msg };
}

import { supabase } from "@/lib/supabase";

export type PlanId = "free" | "apoiador" | "premium" | "familia";

export interface MyPlan {
  plan_id: PlanId;
  name: string;
  show_ads: boolean;
  price_brl: number | null;
  limit: number;
  used: number;
  remaining: number;
  expires_at: string | null;
  bonus_today: number;
  staff?: boolean;
  /** Limites de sala do plano: -1 = ilimitado, 0 = bloqueado. */
  rooms_join_per_month?: number; rooms_create_per_month?: number; rooms_max_members?: number; rooms_local_playback?: boolean;
  rooms_joined?: number; rooms_created?: number;
}

export interface PlanInfo {
  id: PlanId; name: string; downloads_per_month: number; show_ads: boolean; rank: number; price_brl: number | null; perks: string[];
  rooms_join_per_month?: number; rooms_create_per_month?: number; rooms_max_members?: number; rooms_local_playback?: boolean;
}

const lim = (n: number | undefined, one: string, many: string, free: string) =>
  n == null || n < 0 ? free : n === 0 ? null : `${n} ${n === 1 ? one : many} por mês`;

/** Linhas de vantagens sobre salas, geradas dos limites reais do plano (o admin muda no painel). */
export function roomPerkLines(p: Pick<PlanInfo, "rooms_join_per_month" | "rooms_create_per_month" | "rooms_max_members" | "rooms_local_playback">): string[] {
  const out: string[] = [];
  const j = lim(p.rooms_join_per_month, "sala para assistir", "salas para assistir", "Assista em salas sem limite");
  out.push(j ?? "Sem acesso a salas");
  if ((p.rooms_join_per_month ?? -1) !== 0) {
    const c = lim(p.rooms_create_per_month, "sala criada", "salas criadas", "Crie salas sem limite");
    out.push(c ?? "Não cria salas");
    if ((p.rooms_max_members ?? -1) > 0) out.push(`Até ${p.rooms_max_members} pessoas nas salas que você cria`);
    if (p.rooms_local_playback === false) out.push("Sem filme baixado nas salas");
    else out.push("Filme baixado na sala, sem gastar internet");
  }
  return out;
}

export async function getMyPlan(): Promise<MyPlan | null> {
  const { data, error } = await supabase.rpc("get_my_plan");
  if (error) throw error;
  return (data as MyPlan | null) ?? null;
}

export async function listPlans(): Promise<PlanInfo[]> {
  const { data, error } = await supabase.from("plans").select("*").order("rank");
  if (error) throw error;
  return (data ?? []) as PlanInfo[];
}

/** Gasta 1 download. ok=false quando o limite do mês acabou. */
export async function consumeDownload(): Promise<{ ok: boolean; remaining?: number }> {
  const { data, error } = await supabase.rpc("use_download");
  if (error) throw error;
  return data as { ok: boolean; remaining?: number };
}

/** +1 download por anúncio premiado assistido (máx. 3 por dia). */
export async function grantAdBonus(): Promise<{ ok: boolean; error?: string }> {
  const { data, error } = await supabase.rpc("grant_ad_bonus");
  if (error) throw error;
  return data as { ok: boolean; error?: string };
}


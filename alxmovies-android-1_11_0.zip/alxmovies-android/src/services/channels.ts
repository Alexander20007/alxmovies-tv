import { CONFIG } from "@/lib/config";
import { apiFetch } from "@/lib/proxy";
import { supabase } from "@/lib/supabase";
import { isNative } from "@/lib/native";
import { NativePlayer } from "@/lib/nativePlayer";
import { fetchChannelRules, planAllows, type ChannelRule } from "@/services/access";

export interface Channel { name?: string; group?: string; logo?: string | null; stream: string }
export interface Category { name: string | null; count: number; locked?: boolean; allowed?: string[] | null }
export interface ProgramInfo { titulo: string; inicio: string | null; fim: string | null }

const CACHE_KEY = "alxmovies_channel_cache";
const CACHE_TTL_MS = 10 * 60 * 1000;
const CATALOG_TIMEOUT_MS = 12000;
const EPG_TIMEOUT_MS = 4000;
const TEST_TIMEOUT_MS = 2500;
/** No app: 10 verificações ao mesmo tempo (o verificador nativo baixa playlist + trecho de vídeo). Na web: teste simples. */
export const TEST_CONCURRENCY = isNative ? 10 : 30;

// ---------- favoritos (por perfil) ----------
export async function getFavoriteChannels(profileId: string): Promise<Channel[]> {
  const { data, error } = await supabase.from("channel_favorites").select("*").eq("profile_id", profileId).order("added_at", { ascending: false });
  if (error) throw error;
  await loadChannelAccess();
  return (data ?? []).map((r) => ({ name: r.channel_name, group: r.channel_group, logo: r.channel_logo, stream: r.channel_stream })).filter((c) => categoryStatus(c.group) === "ok");
}

export async function toggleChannelFavorite(profileId: string, channel: Channel, currentlyFavorite: boolean) {
  if (currentlyFavorite) {
    const { error } = await supabase.from("channel_favorites").delete().eq("profile_id", profileId).eq("channel_stream", channel.stream);
    if (error) throw error;
    return { active: false };
  }
  const { error } = await supabase.from("channel_favorites").insert({
    profile_id: profileId, channel_name: channel.name || "Canal", channel_group: channel.group || null,
    channel_logo: channel.logo || null, channel_stream: channel.stream,
  });
  if (error) throw error;
  return { active: true };
}

// ---------- regras do admin: categorias liberadas só para alguns planos (ou ocultas) ----------
interface Access { planId: string | null; rules: Map<string, ChannelRule>; at: number }
let access: Access = { planId: null, rules: new Map(), at: 0 };
let accessLoading: Promise<void> | null = null;
let accessVersion = 0;
const accessListeners = new Set<() => void>();
export const subscribeChannelAccess = (fn: () => void) => { accessListeners.add(fn); return () => { accessListeners.delete(fn); }; };
export const channelAccessVersion = () => accessVersion;

/** Carrega o plano da conta e as regras (no máximo a cada 2 min, com limite de 3 s). Se falhar, nada é bloqueado. */
export function loadChannelAccess(force = false): Promise<void> {
  if (!force && Date.now() - access.at < 2 * 60_000) return Promise.resolve();
  if (!accessLoading) {
    accessLoading = Promise.race([
      Promise.all([fetchChannelRules(), Promise.resolve(supabase.rpc("get_my_plan"))]).then(([rules, plan]) => {
        const next = new Map(rules.map((r) => [r.category.toUpperCase(), r]));
        const planId = ((plan.data as { plan_id?: string } | null)?.plan_id) ?? null;
        const changed = planId !== access.planId || next.size !== access.rules.size || rules.some((r) => JSON.stringify(access.rules.get(r.category.toUpperCase())) !== JSON.stringify(r));
        access = { planId, rules: next, at: Date.now() };
        if (changed) { accessVersion++; accessListeners.forEach((f) => f()); }
      }),
      new Promise<void>((r) => setTimeout(r, 3000)),
    ]).catch(() => {}).finally(() => { accessLoading = null; });
  }
  return accessLoading;
}

/** "ok" = liberado · "locked" = existe, mas o plano da conta não inclui · "hidden" = o admin escondeu a categoria. */
export function categoryStatus(groupName: string | null | undefined): "ok" | "locked" | "hidden" {
  const key = (groupName || "").trim().replace(/^canais\s*\|\s*/i, "").trim().toUpperCase();
  const r = key ? access.rules.get(key) : undefined;
  if (!r) return "ok";
  if (r.hidden) return "hidden";
  return planAllows(r.allowed_plans, access.planId) ? "ok" : "locked";
}
export const channelStatus = (c: Pick<Channel, "group">) => categoryStatus(c.group);
export const allowedPlansFor = (groupName: string | null | undefined) =>
  access.rules.get((groupName || "").trim().replace(/^canais\s*\|\s*/i, "").trim().toUpperCase())?.allowed_plans ?? null;

// ---------- catálogo ----------
const cleanGroup = (g?: string) => (g || "").trim().replace(/^canais\s*\|\s*/i, "").trim();
export const channelGroupLabel = (g?: string) => (g || "").replace(/^canais\s*\|\s*/i, "");

let catalogPromise: Promise<Channel[]> | null = null;
/** Catálogo completo, SEM regras (usado só para listar categorias e pelo painel do admin). */
export function fetchAllChannelsRaw(): Promise<Channel[]> {
  if (!catalogPromise) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), CATALOG_TIMEOUT_MS);
    catalogPromise = apiFetch(CONFIG.CHANNELS_API_URL, { signal: controller.signal })
      .then((r) => r.json())
      .then((d) => (d?.success && Array.isArray(d.canais) ? (d.canais as Channel[]) : []))
      .then((list) => { if (!list.length) catalogPromise = null; return list; })       // lista vazia = falha: tenta de novo na próxima vez (antes ficava vazia até reiniciar o app)
      .catch(() => { catalogPromise = null; return [] as Channel[]; }) // permite tentar de novo depois
      .finally(() => clearTimeout(timeout));
  }
  return catalogPromise;
}

/** Catálogo que o usuário pode ver: sem as categorias ocultas e sem as bloqueadas pelo plano. */
export async function fetchAllChannels(): Promise<Channel[]> {
  const [all] = await Promise.all([fetchAllChannelsRaw(), loadChannelAccess()]);
  return all.filter((c) => categoryStatus(c.group) === "ok");
}

/** Todas as categorias do catálogo, com o nome limpo (para o painel do admin configurar as regras). */
export async function getAllCategoriesRaw(): Promise<Category[]> {
  const all = await fetchAllChannelsRaw();
  const counts = new Map<string, number>();
  all.forEach((c) => { const n = cleanGroup(c.group); if (n && !/adult/i.test(n)) counts.set(n, (counts.get(n) || 0) + 1); });
  return [...counts.entries()].map(([name, count]) => ({ name, count })).sort((a, b) => a.name!.localeCompare(b.name!, "pt-BR"));
}

export async function getAvailableCategories(): Promise<Category[]> {
  const [all] = await Promise.all([fetchAllChannelsRaw(), loadChannelAccess()]);
  const counts = new Map<string, number>();
  let noGroup = 0;
  all.forEach((c) => {
    const clean = cleanGroup(c.group);
    if (!clean) { noGroup++; return; }
    if (/adult/i.test(clean)) return;
    counts.set(clean, (counts.get(clean) || 0) + 1);
  });
  const cats: Category[] = [...counts.entries()]
    .filter(([name]) => categoryStatus(name) !== "hidden")
    .map(([name, count]) => ({ name, count, locked: categoryStatus(name) === "locked", allowed: allowedPlansFor(name) }))
    .sort((a, b) => a.name!.localeCompare(b.name!, "pt-BR"));
  if (noGroup > 0) cats.push({ name: null, count: noGroup });
  return cats;
}

export async function getChannelsInCategory(name: string | null): Promise<Channel[]> {
  if (name !== null && categoryStatus(name) !== "ok") { await loadChannelAccess(); if (categoryStatus(name) !== "ok") return []; }
  const all = await fetchAllChannels();
  if (name === null) return all.filter((c) => !cleanGroup(c.group));
  return all.filter((c) => (c.group || "").toUpperCase().includes(name.toUpperCase()));
}

export async function searchChannels(text: string): Promise<Channel[]> {
  try {
    const [d] = await Promise.all([(await apiFetch(`${CONFIG.CHANNELS_API_URL}?query=${encodeURIComponent(text)}`)).json(), loadChannelAccess()]);
    return d?.success && Array.isArray(d.canais) ? (d.canais as Channel[]).filter((c) => categoryStatus(c.group) === "ok") : [];
  } catch { return []; }
}

export function guessCategoryIcon(name: string) {
  const n = name.toUpperCase();
  const rules: [RegExp, string][] = [
    [/GLOBO|RECORD|BAND|SBT|RTP|SIC|TVI/, "📺"], [/ESPN|SPORT|ESPORT|LUTA|UFC|MMA|COMBATE/, "⚽"], [/FILME|MOVIE|CINEMA|SERIE/, "🎬"],
    [/ANIME|GEEK|NERD/, "🎌"], [/INFANT|KIDS|CRIAN/, "🧸"], [/NOTIC|NEWS|JORNAL/, "📰"], [/NOVELA|SOAP/, "💫"],
    [/MUSIC|MÚSIC/, "🎵"], [/RELIGI|GOSPEL|FÉ\b/, "🙏"], [/DOC/, "🎥"],
  ];
  return rules.find(([re]) => re.test(n))?.[1] ?? "📡";
}

// ---------- teste "está no ar?" com cache ----------
type Cache = Record<string, { online: boolean; testedAt: number; reason?: string }>;
const readCache = (): Cache => { try { return JSON.parse(localStorage.getItem(CACHE_KEY) ?? "{}") || {}; } catch { return {}; } };
const writeCache = (c: Cache) => { try { localStorage.setItem(CACHE_KEY, JSON.stringify(c)); } catch { /* sem espaço/privado */ } };
const cached = (c: Cache, url: string) => {
  const e = c[url];
  return e && Date.now() - e.testedAt <= CACHE_TTL_MS ? e.online : null;
};

/** Leitor rápido dos testes guardados: lê o armazenamento UMA vez e responde para vários canais (true = no ar, false = fora, null = não testado). */
export function channelStatusReader(): (url: string) => boolean | null {
  const c = readCache();
  return (url) => cached(c, url);
}
/** Esquece todos os testes (botão atualizar): os canais serão verificados de novo. */
export function clearChannelStatuses() { try { localStorage.removeItem(CACHE_KEY); } catch { /* sem acesso */ } }

/** Último resultado guardado do teste "está no ar?" (null = nunca testado / cache vencido) + quando foi. */
export function getChannelStatus(url: string): { online: boolean; testedAt: number; reason?: string } | null {
  const e = readCache()[url];
  return e && Date.now() - e.testedAt <= CACHE_TTL_MS ? e : null;
}
export function setChannelStatus(url: string, online: boolean, reason?: string) {
  const c = readCache();
  c[url] = { online, testedAt: Date.now(), reason };
  writeCache(c);
}
/** Testa de novo (ignora o cache) e guarda o resultado, com o motivo quando está fora do ar. */
export async function recheckChannel(url: string) {
  const r = await probeChannel(url);
  setChannelStatus(url, r.online, r.reason);
  return r.online;
}
/** Canais que falharam no teste recentemente (só lê o cache) — para mostrar com o selo "offline". */
export async function getKnownOfflineChannels(limit = 6) {
  const all = await fetchAllChannels();
  const cache = readCache();
  return all.filter((c) => c.stream && cached(cache, c.stream) === false).slice(0, limit);
}
/** O link do canal é um vídeo HLS direto (.m3u8)? Senão é uma página incorporada. */
export const isHlsUrl = (u: string) => /\.m3u8(\?|#|$)/i.test(u);

const norm = (t: string) => t.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/\b(hd|fhd|sd|4k|canal|tv|ao vivo)\b/g, " ").replace(/[^a-z0-9]+/g, " ").trim();

/** Procura canal pelo nome falado/digitado ("globo", "espn 2"): igual > começa com > contém todas as palavras. Prefere os que estão no ar. */
export async function findChannelFuzzy(query: string): Promise<{ channel: Channel; siblings: Channel[] } | null> {
  const q = norm(query);
  if (!q) return null;
  const all = (await fetchAllChannels()).filter((c) => c.stream);
  const words = q.split(" ");
  const scored = all.map((c) => {
    const n = norm(c.name || "");
    let score = 0;
    if (n === q) score = 100;
    else if (n.startsWith(q)) score = 80;
    else if (words.every((w) => n.includes(w))) score = 60 - Math.min(20, n.length - q.length);
    const st = getChannelStatus(c.stream);
    if (score > 0) score += st?.online === true ? 15 : st?.online === false ? -25 : 0;
    return { c, score };
  }).filter((x) => x.score > 0).sort((a, b) => b.score - a.score);
  if (!scored.length) return null;
  const channel = scored[0].c;
  const siblings = all.filter((c) => c.stream !== channel.stream && (c.group || "") === (channel.group || "") && getChannelStatus(c.stream)?.online !== false).slice(0, 30);
  return { channel, siblings };
}

export async function findChannelByName(name: string) {
  const n = name.trim().toLowerCase();
  return (await fetchAllChannels()).find((c) => (c.name || "").trim().toLowerCase() === n) ?? null;
}
export async function findChannelByStream(stream: string) {
  return (await fetchAllChannels()).find((c) => c.stream === stream) ?? null;
}

/**
 * Verificação do canal. No app Android usa o verificador nativo: baixa a playlist HLS, abre a variante e baixa um trecho real
 * do vídeo (com os mesmos headers do player). Só marca "no ar" se o trecho carregou. Na web (sem verificador nativo) é só um teste simples.
 */
export async function probeChannel(url: string): Promise<{ online: boolean; reason: string }> {
  if (isNative) {
    try {
      const r = await Promise.race([
        NativePlayer.probe({ url }),
        new Promise<never>((_, rej) => setTimeout(() => rej(new Error("Tempo esgotado")), 22000)),
      ]);
      return { online: r.online, reason: r.reason };
    } catch (e) {
      return { online: false, reason: e instanceof Error ? e.message : "Falha na verificação" };
    }
  }
  const attempt = async (method: string) => {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), TEST_TIMEOUT_MS);
    try { await fetch(url, { method, signal: ctrl.signal, mode: "no-cors" }); return true; }
    catch { return false; }
    finally { clearTimeout(t); ctrl.abort(); }
  };
  const ok = (await attempt("HEAD")) || (await attempt("GET"));
  return { online: ok, reason: ok ? "No ar" : "Sem resposta" };
}
export async function testChannelOnline(url: string) { return (await probeChannel(url)).online; }

export async function runWithConcurrency<T>(items: T[], limit: number, worker: (item: T) => Promise<void>) {
  let i = 0;
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (i < items.length) await worker(items[i++]);
  }));
}

/** Testa e entrega cada canal assim que confirmado no ar; favoritos primeiro (em lote separado). */
export interface StreamOptions { maxToShow?: number; deadlineMs?: number | null; isCancelled?: () => boolean }

export async function streamOnlineChannels(
  profileId: string, onOnline: (c: Channel) => void,
  { maxToShow = 30, deadlineMs = null, isCancelled = () => false }: StreamOptions = {}
) {
  const all = await fetchAllChannels();
  if (!all.length) return;
  const favs = new Set((await getFavoriteChannels(profileId).catch(() => [])).map((f) => f.stream));
  const cache = readCache();
  const started = Date.now();
  let shown = 0;
  const stop = () => isCancelled() || (deadlineMs != null && Date.now() - started > deadlineMs);

  const handle = async (c: Channel) => {
    if (shown >= maxToShow || stop() || !c.stream) return;
    const hit = cached(cache, c.stream);
    if (hit === true) { shown++; onOnline(c); return; }
    if (hit === false) return;
    const { online, reason } = await probeChannel(c.stream);
    cache[c.stream] = { online, testedAt: Date.now(), reason };
    writeCache(cache);
    if (online && shown < maxToShow && !isCancelled()) { shown++; onOnline(c); }
  };

  const fav = all.filter((c) => favs.has(c.stream));
  const rest = all.filter((c) => !favs.has(c.stream));
  if (fav.length) await runWithConcurrency(fav, TEST_CONCURRENCY, handle);
  if (shown < maxToShow && !stop()) await runWithConcurrency(rest, TEST_CONCURRENCY, handle);
}

/** Canais confirmados no ar recentemente (só lê o cache) — contexto real para a IA. */
export async function getKnownOnlineChannels(limit = 15) {
  const all = await fetchAllChannels();
  const cache = readCache();
  return all.filter((c) => c.stream && cached(cache, c.stream) === true).slice(0, limit);
}

// ---------- guia de programação (falha em silêncio) ----------
const normalize = (r: any): ProgramInfo | null => (r?.titulo ? { titulo: r.titulo, inicio: r.inicio || null, fim: r.fim || null } : null);
export async function getChannelProgramGuide(stream: string) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), EPG_TIMEOUT_MS);
  try {
    const res = await apiFetch(`${CONFIG.EPG_API_URL}?stream=${encodeURIComponent(stream)}`, { signal: ctrl.signal });
    if (!res.ok) return null;
    const d = await res.json();
    return d?.success ? { atual: normalize(d.atual), proximo: normalize(d.proximo) } : null;
  } catch { return null; }
  finally { clearTimeout(t); }
}

export async function removeFavoriteChannelByStream(profileId: string, stream: string) {
  const { error } = await supabase.from("channel_favorites").delete().eq("profile_id", profileId).eq("channel_stream", stream);
  if (error) throw error;
}

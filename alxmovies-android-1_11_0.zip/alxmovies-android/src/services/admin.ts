import { supabase } from "@/lib/supabase";
import type { PlanId } from "@/services/plans";

/** Funções do painel do DONO (sql/admin-painel.sql). O servidor só responde se a conta for dona; nada aqui mostra o que alguém assiste. */
async function rpc<T = unknown>(fn: string, args: Record<string, unknown> = {}): Promise<T> {
  const { data, error } = await supabase.rpc(fn, args);
  if (error) {
    const m = error.message || "";
    if (error.code === "PGRST202" || /could not find the function/i.test(m)) throw new Error("O SQL do painel ainda não foi instalado. Rode o sql/admin-painel.sql no Supabase.");
    throw new Error(m.replace(/^.*?:\s*/, "") || "Não foi possível concluir.");
  }
  return data as T;
}

export interface Dashboard {
  users_total: number; guests: number; new_24h: number; new_7d: number; active_24h: number; active_7d: number; active_30d: number; reporting: number;
  by_version: { version: string; n: number }[]; by_platform: { platform: string; n: number }[]; by_plan: { plan: string; n: number }[];
  downloads_month: number; rooms_active: number; rooms_playing: number; push_devices: number; proposals: number; staff: number; codes_open: number; messages_unread: number;
}
export interface UserFilters { search?: string; version?: string; platform?: string; plan?: string; inactiveDays?: number | null; only?: string }
export interface AdminUser {
  user_id: string; username: string; email_masked: string | null; created_at: string; last_seen: string | null; app_version: string | null; platform: string | null;
  os: string | null; model: string | null; plan_id: PlanId; plan_expires: string | null; is_guest: boolean; is_staff: boolean; suspended: boolean;
  profiles_count: number; downloads_used: number; total_count: number;
}
export interface UserDetail {
  user_id: string; username: string; email_masked: string | null; created_at: string; last_sign_in: string | null; is_guest: boolean; suspended: boolean; is_staff: boolean; is_owner: boolean;
  device: { app_version: string | null; platform: string | null; os: string | null; model: string | null; first_seen: string; last_seen: string; opens: number } | null;
  plan: { plan_id: PlanId; expires_at: string | null; source: string; updated_at: string } | null; plan_now: PlanId;
  downloads: { used: number; bonus: number } | null; profiles: { name: string; kids: boolean }[]; push_devices: number; note: string;
  messages: { sent: number; unread: number }; recent: { action: string; details: Record<string, unknown> | null; created_at: string }[];
}
export type Audience =
  | { type: "all" } | { type: "user"; user_id: string } | { type: "version_below"; version: string } | { type: "version_is"; version: string }
  | { type: "platform"; value: string } | { type: "plan"; value: string } | { type: "inactive"; days: number } | { type: "new"; days: number } | { type: "staff" };
export type MsgKind = "aviso" | "atualizacao" | "plano" | "suporte";
export interface HistoryRow { batch_id: string; title: string; body: string; kind: MsgKind; created_at: string; recipients: number; read_count: number }
export interface CodeRow {
  code: string; prize_label: string; plan_id: string | null; days: number | null; bonus_downloads: number; created_at: string; expires_at: string;
  redeemed_by: string | null; redeemed_name: string | null; redeemed_at: string | null;
}
export interface AdminRoom { id: string; title: string; host_name: string; is_private: boolean; is_playing: boolean; what: string | null; members: number; created_at: string }
export interface AuditRow { id: number; action: string; target: string | null; target_name: string | null; details: Record<string, unknown> | null; created_at: string }

export const adminSetPublicDownloads = (n: number) => rpc<number>("admin_set_public_downloads", { p_n: n });
export interface ApiEndpointRow { key: string; label: string; url: string; note: string | null; updated_at: string }
export const adminApiEndpoints = () => rpc<ApiEndpointRow[]>("admin_api_endpoints");
export const adminSetApiEndpoint = (key: string, url: string) => rpc<void>("admin_set_api_endpoint", { p_key: key, p_url: url });
export interface AccessBlockRow { id: number; kind: "ip" | "country"; value: string; reason: string | null; created_at: string }
export const adminAccessBlocks = () => rpc<AccessBlockRow[]>("admin_access_blocks");
export const adminMyAccess = () => rpc<{ ip: string | null; country: string | null }>("admin_my_access");
export const adminAddAccessBlock = (kind: "ip" | "country", value: string, reason: string) => rpc<void>("admin_add_access_block", { p_kind: kind, p_value: value, p_reason: reason });
export const adminRemoveAccessBlock = (id: number) => rpc<void>("admin_remove_access_block", { p_id: id });
export const adminDashboard = () => rpc<Dashboard>("admin_dashboard");
export const adminUsers = (f: UserFilters, offset = 0, limit = 25) => rpc<AdminUser[]>("admin_users", {
  p_search: f.search || null, p_version: f.version || null, p_platform: f.platform || null, p_plan: f.plan || null,
  p_inactive_days: f.inactiveDays ?? null, p_only: f.only || null, p_limit: limit, p_offset: offset,
});
export const adminUserDetail = (id: string) => rpc<UserDetail>("admin_user_detail", { p_user: id });
export const adminSetPlan = (id: string, plan: string, days: number | null) => rpc("admin_set_plan", { p_user: id, p_plan: plan, p_days: days });
export const adminAddBonus = (id: string, n: number) => rpc("admin_add_bonus", { p_user: id, p_n: n });
export const adminResetDownloads = (id: string) => rpc("admin_reset_downloads", { p_user: id });
export const adminSetNote = (id: string, note: string) => rpc("admin_set_note", { p_user: id, p_note: note });
export const adminSetSuspended = (id: string, v: boolean) => rpc("admin_set_suspended", { p_user: id, p_suspended: v });
export const adminStaffAdd = (id: string, canPublish: boolean) => rpc("admin_staff_add", { p_user: id, p_can_publish: canPublish });
export const adminAudienceCount = (aud: Audience) => rpc<number>("admin_audience_count", { p_aud: aud });
export const adminSendMessage = (aud: Audience, title: string, body: string, url: string, kind: MsgKind, push: boolean) =>
  rpc<{ ok: boolean; sent: number; push: boolean }>("admin_send_message", { p_aud: aud, p_title: title, p_body: body, p_url: url.trim() || null, p_kind: kind, p_push: push });
export const adminHistory = () => rpc<HistoryRow[]>("admin_messages_history", { p_limit: 40 });
export const adminRecall = (batch: string) => rpc<number>("admin_recall_batch", { p_batch: batch });
export const adminPlanUpdate = (id: string, name: string, downloads: number, ads: boolean, price: number | null) =>
  rpc("admin_plans_update", { p_id: id, p_name: name, p_downloads: downloads, p_show_ads: ads, p_price: price });
export const adminCodesCreate = (o: { plan: string | null; days: number; bonus: number; qty: number; validDays: number; label?: string }) =>
  rpc<{ ok: boolean; codes: string[]; label: string }>("admin_codes_create", { p_plan: o.plan, p_days: o.days, p_bonus: o.bonus, p_qty: o.qty, p_valid_days: o.validDays, p_label: o.label || null });
export const adminCodes = () => rpc<CodeRow[]>("admin_codes_list", { p_limit: 80 });
export const adminCodeRevoke = (code: string) => rpc("admin_code_revoke", { p_code: code });
export const adminRooms = () => rpc<AdminRoom[]>("admin_rooms_list");
export const adminCloseRoom = (id: string) => rpc("admin_close_room", { p_id: id });
export const adminAudit = () => rpc<AuditRow[]>("admin_audit_list", { p_limit: 100 });

export const adminPlanFeaturesUpdate = (id: string, join: number, create: number, members: number, local: boolean) =>
  rpc("admin_plan_features_update", { p_id: id, p_join: join, p_create: create, p_members: members, p_local: local });
export const adminRoomTitleSave = (t: { tmdbId: number; type: "movie" | "tv"; title: string; poster: string | null; roomsOnly: boolean; allowed: string[] | null; note?: string | null }) =>
  rpc("admin_room_title_save", { p_tmdb_id: t.tmdbId, p_type: t.type, p_title: t.title, p_poster: t.poster, p_rooms_only: t.roomsOnly, p_allowed: t.allowed, p_note: t.note ?? null });
export const adminRoomTitleRemove = (id: number) => rpc("admin_room_title_remove", { p_id: id });
export const adminChannelRuleSet = (category: string, allowed: string[] | null, hidden: boolean) =>
  rpc("admin_channel_rule_set", { p_category: category, p_allowed: allowed, p_hidden: hidden });

// ---- permissões da equipe (só o dono gerencia) ----
export interface MyPerms { owner: boolean; perms: string[] }
export interface StaffMember { user_id: string; username: string; can_publish: boolean; granted_via: string; since: string; perms: string[] }
export const myAdminPerms = () => rpc<MyPerms>("my_admin_perms");
export const adminStaffList = () => rpc<StaffMember[]>("admin_staff_list");
export const adminStaffSetPerms = (id: string, perms: string[]) => rpc("admin_staff_set_perms", { p_user: id, p_perms: perms });
export interface AuditFeedRow { id: number; action: string; admin_name: string | null; target: string | null; target_name: string | null; details: Record<string, unknown> | null; created_at: string }
export const adminAuditFeed = () => rpc<AuditFeedRow[]>("admin_audit_feed", { p_limit: 120 });

// ---- anúncios ----
export interface AdProviderRow { id: string; name: string; platform: "android" | "web"; enabled: boolean; available: boolean; priority: number; settings: Record<string, unknown>; note: string | null }
export interface AdSettingsRow {
  master_enabled: boolean; staff_see_ads: boolean; interstitial_enabled: boolean; rewarded_enabled: boolean; banner_enabled: boolean;
  details_chance: number; download_chance: number; min_gap_seconds: number; max_per_session: number;
}
export const adminAdsGet = () => rpc<{ settings: AdSettingsRow; providers: AdProviderRow[] }>("admin_ads_get");
export const adminAdsSetProvider = (id: string, enabled: boolean, priority: number, settings: Record<string, unknown>) =>
  rpc("admin_ads_set_provider", { p_id: id, p_enabled: enabled, p_priority: priority, p_settings: settings });
export const adminAdsSetSettings = (s: AdSettingsRow) => rpc("admin_ads_set_settings", {
  p_master: s.master_enabled, p_staff: s.staff_see_ads, p_inter: s.interstitial_enabled, p_reward: s.rewarded_enabled, p_banner: s.banner_enabled,
  p_details: s.details_chance, p_download: s.download_chance, p_gap: s.min_gap_seconds, p_max: s.max_per_session,
});

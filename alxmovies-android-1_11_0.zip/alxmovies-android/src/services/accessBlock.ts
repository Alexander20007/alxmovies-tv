import { supabase } from "@/lib/supabase";

export interface AccessResult { blocked: boolean; kind?: "ip" | "country" }

/** Pergunta ao servidor se este aparelho (IP/país) está bloqueado. Se não der para saber, NÃO bloqueia. */
export async function checkAccess(): Promise<AccessResult> {
  try {
    const { data, error } = await supabase.rpc("check_access");
    if (error || !data || typeof data !== "object") return { blocked: false };
    const d = data as { blocked?: boolean; kind?: string };
    return d.blocked ? { blocked: true, kind: d.kind === "ip" ? "ip" : "country" } : { blocked: false };
  } catch { return { blocked: false }; }
}

import { supabase } from "@/lib/supabase";

/** Número de downloads que o dono escolheu mostrar no site (público, funciona sem login). 0 = não mostrar. */
export async function getPublicDownloads(): Promise<number> {
  try {
    const { data, error } = await supabase.rpc("get_public_downloads");
    if (error) return 0;
    const n = Number(data);
    return Number.isFinite(n) && n > 0 ? n : 0;
  } catch { return 0; }
}

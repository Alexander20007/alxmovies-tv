import { createPortal } from "react-dom";
import { useNavigate } from "react-router-dom";
import { useBackClose } from "@/hooks/useBackClose";

/** Aviso de recurso que depende do plano: explica o limite e leva para a tela de planos. */
export function UpgradeNotice({ open, title, text, plans, onClose }: { open: boolean; title: string; text: string; plans?: string; onClose: () => void }) {
  const navigate = useNavigate();
  useBackClose(open, onClose);
  if (!open) return null;
  return createPortal(
    <div className="upg-bg" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="upg" role="dialog" aria-modal="true" aria-label={title}>
        <span className="upg-ico" aria-hidden>🔒</span>
        <h2>{title}</h2>
        <p>{text}</p>
        {plans && <p className="upg-plans">Disponível em: <b>{plans}</b></p>}
        <button type="button" className="upg-main" onClick={() => { onClose(); navigate("/planos"); }}>Ver planos</button>
        <button type="button" className="upg-sec" onClick={onClose}>Agora não</button>
      </div>
    </div>,
    document.body,
  );
}

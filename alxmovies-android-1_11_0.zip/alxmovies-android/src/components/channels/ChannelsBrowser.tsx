import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { ChannelCard } from "@/components/channels/ChannelCard";
import { Icon } from "@/components/Icon";
import { UpgradeNotice } from "@/components/UpgradeNotice";
import { planNames } from "@/services/access";
import { useChannelsUi } from "@/context/ChannelsUiContext";
import { useProfile } from "@/context/ProfileContext";
import { useChannelFavorites } from "@/hooks/useChannelFavorites";
import { useDebounce } from "@/hooks/useDebounce";
import {
  channelAccessVersion, channelStatusReader, clearChannelStatuses, fetchAllChannels, getAvailableCategories, getChannelsInCategory, getFavoriteChannels, getKnownOfflineChannels,
  guessCategoryIcon, recheckChannel, runWithConcurrency, searchChannels, streamOnlineChannels, subscribeChannelAccess, TEST_CONCURRENCY, type Category, type Channel,
} from "@/services/channels";

const titleCase = (s: string) => s.replace(/\w\S*/g, (t) => t.charAt(0).toUpperCase() + t.slice(1).toLowerCase());
const PAGE = 36;   // quantos canais aparecem de cada vez (o resto vem ao rolar)

type View = { k: "live" } | { k: "fav" } | { k: "cat"; cat: Category };

function Skeleton({ n = 9 }: { n?: number }) {
  return <div className="cpx-grid" aria-hidden="true">{Array.from({ length: n }, (_, i) => <div key={i} className="cn2-skel" style={{ animationDelay: `${(i % 6) * 90}ms` }} />)}</div>;
}

function Empty({ icon, title, text, action, onAction }: { icon: string; title: string; text?: string; action?: string; onAction?: () => void }) {
  return (
    <div className="cn2-empty">
      <span aria-hidden="true">{icon}</span>
      <h3>{title}</h3>
      {text && <p>{text}</p>}
      {action && <button type="button" onClick={onAction}>{action}</button>}
    </div>
  );
}

interface ResultsProps { viewKey: string; mode: "live" | "list"; load: () => Promise<Channel[]>; emptyTitle: string; emptyText: string; showOffline: boolean; onRetry: () => void }

/**
 * Lista de canais. "live" = só os que estão no ar agora (testados um a um). "list" (categoria, busca, favoritos) = mostra TODOS na hora,
 * com o selo de cada um vindo do último teste, e vai verificando em segundo plano os que aparecem na tela.
 */
function Results({ viewKey, mode, load, emptyTitle, emptyText, showOffline, onRetry }: ResultsProps) {
  const { activeProfile } = useProfile();
  const navigate = useNavigate();
  const { openPlayer, closePanel } = useChannelsUi();
  const { isFavorite, toggle, busy } = useChannelFavorites();
  const pid = activeProfile!.id;

  const [list, setList] = useState<Channel[]>([]);
  const [offList, setOffList] = useState<Channel[]>([]);        // modo "live": canais que falharam no teste recentemente
  const [loading, setLoading] = useState(true);
  const [failed, setFailed] = useState(false);                  // catálogo não carregou (sem internet / API fora do ar)
  const [searching, setSearching] = useState(false);            // modo "live": ainda procurando canais no ar
  const [probe, setProbe] = useState({ n: 0, total: 0 });
  const [local, setLocal] = useState<Map<string, boolean>>(() => new Map());
  const [visible, setVisible] = useState(PAGE);
  const probed = useRef(new Set<string>());
  const sentinel = useRef<HTMLDivElement>(null);
  const press = useRef<{ t?: number; fired: boolean }>({ fired: false });

  // ---- carregar a lista ----
  useEffect(() => {
    let cancel = false;
    setList([]); setOffList([]); setLoading(true); setFailed(false); setSearching(false); setLocal(new Map()); setVisible(PAGE); probed.current = new Set();
    (async () => {
      if (mode === "live") {
        const all = await fetchAllChannels().catch(() => [] as Channel[]);
        if (cancel) return;
        if (!all.length) { setFailed(true); setLoading(false); return; }
        setSearching(true);
        const on: Channel[] = [];
        await streamOnlineChannels(pid, (c) => { on.push(c); if (!cancel) { setList([...on]); setLoading(false); } },
          { maxToShow: 80, deadlineMs: 30000, isCancelled: () => cancel }).catch(() => {});
        const off = await getKnownOfflineChannels(40).catch(() => [] as Channel[]);
        if (cancel) return;
        setOffList(off.filter((o) => !on.some((x) => x.stream === o.stream)));
        setLoading(false); setSearching(false);
        return;
      }
      const raw = (await load().catch(() => [] as Channel[])).filter((c) => c.stream);
      if (cancel) return;
      const st = channelStatusReader();
      const rank = (c: Channel) => { const s = st(c.stream); return s === true ? 0 : s === null ? 1 : 2; };
      setList(raw.map((c, i) => ({ c, i, r: rank(c) })).sort((a, b) => a.r - b.r || a.i - b.i).map((x) => x.c));
      setLoading(false);
    })();
    return () => { cancel = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [viewKey, pid]);

  // ---- verificar em segundo plano só os canais que estão aparecendo ----
  useEffect(() => {
    if (mode !== "list" || !list.length) return;
    let cancel = false;
    const st = channelStatusReader();
    const todo = list.slice(0, visible).filter((c) => st(c.stream) === null && !probed.current.has(c.stream));
    if (!todo.length) return;
    todo.forEach((c) => probed.current.add(c.stream));
    const finished = new Set<string>();
    let n = 0;
    setProbe({ n: 0, total: todo.length });
    void runWithConcurrency(todo, TEST_CONCURRENCY, async (c) => {
      if (cancel) return;
      const ok = await recheckChannel(c.stream).catch(() => false);
      if (cancel) return;
      finished.add(c.stream); n++;
      setLocal((m) => new Map(m).set(c.stream, ok));
      setProbe({ n, total: todo.length });
    });
    return () => { cancel = true; todo.forEach((c) => { if (!finished.has(c.stream)) probed.current.delete(c.stream); }); };
  }, [list, visible, mode]);

  // ---- carregar mais ao chegar no fim ----
  useEffect(() => {
    const el = sentinel.current;
    if (!el || typeof IntersectionObserver === "undefined") return;
    const io = new IntersectionObserver((es) => { if (es.some((e) => e.isIntersecting)) setVisible((v) => v + PAGE); }, { rootMargin: "500px 0px" });
    io.observe(el);
    return () => io.disconnect();
  }, [list.length, visible, showOffline]);

  const status = channelStatusReader();
  const onlineOf = (c: Channel): boolean | null => (mode === "live" && list.includes(c) ? true : local.get(c.stream) ?? status(c.stream));
  const all = mode === "live" ? [...list, ...(showOffline ? offList : [])] : list;
  const rows = all.map((c) => ({ c, online: mode === "live" && !list.includes(c) ? false : onlineOf(c) }));
  const shown = rows.filter((r) => showOffline || r.online !== false);
  const page = shown.slice(0, visible);
  const nOn = rows.filter((r) => r.online === true).length;
  const nOff = rows.filter((r) => r.online === false).length;
  const pending = mode === "live" ? searching : probe.total > 0 && probe.n < probe.total;

  const play = (c: Channel) => {
    const queue = shown.filter((r) => r.online !== false).map((r) => r.c);
    openPlayer(c, queue.some((x) => x.stream === c.stream) ? queue : [c, ...queue]);   // a lista continua por baixo: ao fechar o player você volta para ela
  };
  const details = (c: Channel) => { closePanel(); navigate(`/canal?s=${encodeURIComponent(c.stream)}`, { state: { channel: c } }); };
  const down = (c: Channel) => {
    press.current.fired = false;
    window.clearTimeout(press.current.t);
    press.current.t = window.setTimeout(() => { press.current.fired = true; try { navigator.vibrate?.(14); } catch { /* sem vibração */ } details(c); }, 520);
  };
  const up = () => window.clearTimeout(press.current.t);

  return (
    <>
      <div className="cn2-stats">
        <span className="cn2-on"><i />{nOn} no ar</span>
        {nOff > 0 && <span className="cn2-offp">{nOff} offline</span>}
        {pending && <span className="cn2-prog"><i className="cn2-spin" />{mode === "list" ? `Verificando ${probe.n}/${probe.total}` : "Procurando canais…"}</span>}
      </div>
      {pending && mode === "list" && <div className="cn2-bar"><i style={{ width: `${probe.total ? Math.round((probe.n / probe.total) * 100) : 0}%` }} /></div>}

      {failed ? <Empty icon="📡" title="Não foi possível carregar os canais" text="Verifique sua internet e tente de novo." action="Tentar de novo" onAction={onRetry} />
        : loading && !page.length ? <Skeleton />
        : !page.length ? (pending ? <Skeleton n={6} /> : <Empty icon={mode === "live" ? "📡" : "🔎"} title={emptyTitle} text={emptyText} action={mode === "live" ? "Procurar de novo" : undefined} onAction={onRetry} />)
        : (
          <>
            {mode === "live" || shown.length > 0 ? <p className="cn2-hint">Toque para assistir · segure para ver detalhes</p> : null}
            <div className="cpx-grid">
              {page.map(({ c, online }) => (
                <div key={c.stream} className="cpx-item"
                  onPointerDown={() => down(c)} onPointerUp={up} onPointerLeave={up} onPointerCancel={up} onContextMenu={(e) => e.preventDefault()}>
                  <ChannelCard channel={c} online={online} onClick={() => { if (press.current.fired) { press.current.fired = false; return; } play(c); }} />
                  <button type="button" className={`cpx-fav${isFavorite(c.stream) ? " on" : ""}`} disabled={busy} aria-label={isFavorite(c.stream) ? "Remover dos favoritos" : "Favoritar"}
                    onPointerDown={(e) => e.stopPropagation()} onClick={() => toggle(c)}><Icon name="heart" size={17} fill={isFavorite(c.stream) ? "currentColor" : "none"} /></button>
                </div>
              ))}
            </div>
            {shown.length > page.length && <div ref={sentinel} className="cn2-more"><i className="cn2-spin" /> Carregando mais canais…</div>}
          </>
        )}
    </>
  );
}

/**
 * Canais ao vivo em tela cheia: busca, filtros (no ar agora · favoritos · categorias) e grade de capas grandes com selo AO VIVO / OFFLINE.
 * `inline` = usado dentro da página Buscar (sem cabeçalho próprio, a busca vem de fora).
 */
export function ChannelsBrowser({ externalSearch, onClearSearch, onClose, inline }: { externalSearch?: string; onClearSearch?: () => void; onClose?: () => void; inline?: boolean }) {
  const { activeProfile } = useProfile();
  const pid = activeProfile!.id;
  const [own, setOwn] = useState("");
  const text = (externalSearch ?? own).trim();
  const debounced = useDebounce(text, 400);
  const [view, setView] = useState<View>({ k: "live" });
  const [showOffline, setShowOffline] = useState(false);
  const [round, setRound] = useState(0);   // muda ao tocar em atualizar: refaz a lista e os testes
  const chips = useRef<HTMLDivElement>(null);
  const accessV = useSyncExternalStore(subscribeChannelAccess, channelAccessVersion);
  const cats = useQuery({ queryKey: ["channelCategories", accessV], queryFn: getAvailableCategories, staleTime: Infinity });
  const [lockedCat, setLockedCat] = useState<Category | null>(null);

  useEffect(() => { chips.current?.scrollTo({ left: 0 }); }, [debounced]);

  const refresh = () => { clearChannelStatuses(); setRound((n) => n + 1); void cats.refetch(); };
  const label = view.k === "cat" ? (view.cat.name === null ? "Sem categoria" : titleCase(view.cat.name)) : view.k === "fav" ? "Favoritos" : "No ar agora";
  const k = (s: string) => `${s}:${round}`;

  let body;
  if (debounced) {
    body = <Results key={k(`s:${debounced}`)} viewKey={k(`s:${debounced}`)} mode="list" showOffline={showOffline} load={() => searchChannels(debounced)} emptyTitle="Nada encontrado" emptyText={`Nenhum canal para “${debounced}”. Tente outro nome.`} onRetry={refresh} />;
  } else if (view.k === "fav") {
    body = <Results key={k("fav")} viewKey={k("fav")} mode="list" showOffline={showOffline} load={() => getFavoriteChannels(pid)} emptyTitle="Sem favoritos ainda" emptyText="Toque no coração de um canal para guardá-lo aqui." onRetry={refresh} />;
  } else if (view.k === "cat") {
    const cat = view.cat;
    body = <Results key={k(`c:${cat.name}`)} viewKey={k(`c:${cat.name}`)} mode="list" showOffline={showOffline} load={() => getChannelsInCategory(cat.name)} emptyTitle="Categoria vazia" emptyText="Nenhum canal encontrado nessa categoria." onRetry={refresh} />;
  } else {
    body = <Results key={k("live")} viewKey={k("live")} mode="live" showOffline={showOffline} load={async () => []} emptyTitle="Nenhum canal no ar" emptyText="Nenhum canal respondeu agora. Tente de novo em instantes ou veja as categorias." onRetry={refresh} />;
  }

  return (
    <div className={`cpx-in cn2${inline ? " inline" : ""}`}>
      {!inline && (
        <header className="cn2-top">
          <button type="button" className="cn2-ic" aria-label="Voltar" onClick={onClose}><Icon name="arrowLeft" size={24} strokeWidth={2.2} /></button>
          <div className="cn2-ttl"><h1>Canais ao vivo</h1><small>{debounced ? `Busca: “${debounced}”` : label}</small></div>
          <button type="button" className="cn2-ic" aria-label="Atualizar canais" onClick={refresh}><Icon name="refresh" size={22} strokeWidth={2.2} /></button>
        </header>
      )}

      {!inline && (
        <div className="cn2-search">
          <Icon name="search" size={20} />
          <input type="search" value={own} onChange={(e) => setOwn(e.target.value)} placeholder="Buscar canal…" enterKeyHint="search" autoComplete="off" />
          {own && <button type="button" aria-label="Limpar busca" onClick={() => { setOwn(""); onClearSearch?.(); }}><Icon name="close" size={18} /></button>}
        </div>
      )}

      {!debounced && (
        <div className="cn2-chips" ref={chips} role="tablist" aria-label="Filtros de canais">
          <button type="button" role="tab" aria-selected={view.k === "live"} className={view.k === "live" ? "on" : ""} onClick={() => setView({ k: "live" })}>{view.k === "live" && <Icon name="check" size={16} strokeWidth={3} />}🔴 No ar agora</button>
          <button type="button" role="tab" aria-selected={view.k === "fav"} className={view.k === "fav" ? "on" : ""} onClick={() => setView({ k: "fav" })}>{view.k === "fav" && <Icon name="check" size={16} strokeWidth={3} />}⭐ Favoritos</button>
          {(cats.data ?? []).map((cat) => {
            const on = view.k === "cat" && view.cat.name === cat.name;
            return (
              <button key={cat.name ?? "none"} type="button" role="tab" aria-selected={on} className={`${on ? "on" : ""}${cat.locked ? " locked" : ""}`} onClick={() => (cat.locked ? setLockedCat(cat) : setView({ k: "cat", cat }))}>
                {on && <Icon name="check" size={16} strokeWidth={3} />}
                {cat.locked ? "🔒" : cat.name === null ? "🗂️" : guessCategoryIcon(cat.name)} {cat.name === null ? "Sem categoria" : titleCase(cat.name)} <i>{cat.count}</i>
              </button>
            );
          })}
          {cats.isSuccess && (cats.data ?? []).length === 0 && <button type="button" className="retry" onClick={refresh}>↻ Carregar categorias</button>}
        </div>
      )}

      <label className="cn2-switch">
        <span>Mostrar também os offline</span>
        <input type="checkbox" role="switch" checked={showOffline} onChange={(e) => setShowOffline(e.target.checked)} />
        <i className="cn2-sw" />
      </label>

      <div className="cpx-body">{body}</div>
      <UpgradeNotice open={!!lockedCat} onClose={() => setLockedCat(null)} title="Categoria de canais bloqueada"
        text={`A categoria “${lockedCat?.name ? titleCase(lockedCat.name) : ""}” não está incluída no seu plano.`} plans={planNames(lockedCat?.allowed)} />
    </div>
  );
}

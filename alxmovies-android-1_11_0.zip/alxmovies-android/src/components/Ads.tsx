import { useEffect, useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { adsenseClient, initAds, loadAdsForGuest, setBanner } from "@/lib/ads";
import { useAdsEnabled } from "@/hooks/useAdsEnabled";
import { isNative } from "@/lib/native";

/** Site: scripts de anúncio só para convidado (fontes ligadas no painel). App: liga o Appodeal quando o servidor manda mostrar anúncios. */
export function AdsLoader() {
  const { user } = useAuth();
  const guest = !!user?.is_anonymous;
  const adsOn = useAdsEnabled();
  useEffect(() => { if (guest) loadAdsForGuest(); }, [guest]);
  useEffect(() => { if (adsOn) void initAds(); }, [adsOn]);
  return null;
}

/** Banner do rodapé (app, plano Grátis). Coloque só nas telas escolhidas; some sozinho ao sair da tela. */
export function NativeBanner() {
  const on = useAdsEnabled();
  useEffect(() => {
    if (!on) return;
    void setBanner(true);
    return () => { void setBanner(false); };
  }, [on]);
  return null;
}

/** Bloco do AdSense (só convidado e se a fonte estiver ligada no painel). */
export function AdBlock() {
  const { user } = useAuth();
  const guest = !!user?.is_anonymous;
  const [client, setClient] = useState<string | null>(null);
  useEffect(() => { if (guest && !isNative) void adsenseClient().then(setClient); }, [guest]);
  useEffect(() => {
    if (!client) return;
    try { ((window as any).adsbygoogle = (window as any).adsbygoogle || []).push({}); }
    catch (err) { console.warn("AdSense ainda não carregou:", err); }
  }, [client]);
  if (!guest || isNative || !client) return null;
  return (
    <div className="ad-block">
      <ins className="adsbygoogle" style={{ display: "block" }} data-ad-client={client} data-ad-slot="0000000000"
        data-ad-format="auto" data-full-width-responsive="true" />
    </div>
  );
}

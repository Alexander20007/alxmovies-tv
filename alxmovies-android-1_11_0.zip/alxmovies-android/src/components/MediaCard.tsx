import { memo } from "react";
import { useNavigate } from "react-router-dom";
import { mediaKind, yearOf } from "@/lib/mediaKind";
import { rowPosterSize } from "@/lib/preferences";
import { posterUrl } from "@/services/tmdb";
import type { MediaItem, MediaType } from "@/types";

interface Props {
  id: number;
  type: MediaType;
  title?: string;
  posterPath: string | null;
  progress?: number | null;
  to?: "details" | "watch";
  rank?: number;
  rating?: number | null;
  /** Dados completos do TMDB (tipo, ano, classificação). Sem isso o cartão mostra só filme/série. */
  item?: MediaItem;
}

const fallback = (e: React.SyntheticEvent<HTMLImageElement>) => { e.currentTarget.onerror = null; e.currentTarget.src = "/assets/no-poster.png"; };

export const MediaCard = memo(function MediaCard({ id, type, title, posterPath, progress, to = "details", rank, rating, item }: Props) {
  const navigate = useNavigate();
  const nota = rating ? rating.toFixed(1) : null;
  const k = mediaKind(item, type);
  const year = yearOf(item);
  const img = <img src={posterUrl(posterPath, rowPosterSize())} alt={title ?? ""} loading="lazy" onError={fallback} />;
  const adult = item?.adult ? <span className="mc-cert">18</span> : null;
  const stars = nota ? <span className="card-rating">★ {nota}</span> : null;
  const meta = (
    <div className="mc-meta">
      <b className="mc-title">{title ?? ""}</b>
      <div className="mc-tags"><span className={`mc-type k-${k.kind}`}>{k.label}</span>{year && <span className="mc-year">{year}</span>}</div>
    </div>
  );

  return (
    <div className={`media-card mc${rank != null ? " ranked" : ""}`} onClick={() => navigate(`/${to}?id=${id}&type=${type}`)}>
      {rank != null ? (
        <>
          <span className="rank-number">{rank}</span>
          <div className="rank-poster">{img}{adult}{stars}</div>
        </>
      ) : (
        <div className="mc-poster">
          {img}{adult}{stars}
          {progress != null && <div className="progress-bar"><div className="progress-bar-fill" style={{ width: `${progress}%` }} /></div>}
        </div>
      )}
      {meta}
    </div>
  );
});

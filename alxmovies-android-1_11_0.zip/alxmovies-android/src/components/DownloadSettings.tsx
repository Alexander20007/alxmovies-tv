import { useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { Icon, type IconName } from "@/components/Icon";
import { useBackClose } from "@/hooks/useBackClose";
import { useDownloads } from "@/context/DownloadsContext";
import { getQuality, getRoomsLocal, QUALITIES, setQuality, setRoomsLocalPref, SPEEDS, type Quality } from "@/lib/downloads";

function Row({ icon, title, hint, children }: { icon: IconName; title: string; hint?: string; children: ReactNode }) {
  return (
    <div className="dx-set-row">
      <span className="dx-set-ico"><Icon name={icon} size={19} /></span>
      <div className="dx-set-txt"><b>{title}</b>{hint && <small>{hint}</small>}</div>
      {children}
    </div>
  );
}

function Switch({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button type="button" role="switch" aria-checked={on} aria-label={label} className={`dx-switch${on ? " on" : ""}`} onClick={() => onChange(!on)}><i /></button>
  );
}

/** Folha com as configurações do download: Wi-Fi, velocidade, qualidade e uso nas salas. Usada na aba Downloads e na folha "Baixar". */
export function DownloadSettings({ open, onClose }: { open: boolean; onClose: () => void }) {
  useBackClose(open, onClose);
  const d = useDownloads();
  const [quality, setQ] = useState<Quality>(getQuality());
  const [rooms, setRooms] = useState(getRoomsLocal());
  if (!open) return null;

  return createPortal(
    <div className="dx-sheet-bg" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="dx-sheet" role="dialog" aria-modal="true" aria-label="Configurações do download">
        <span className="dx-grab" aria-hidden />
        <header className="dx-sheet-head">
          <span className="dx-sheet-ico"><Icon name="settings" size={22} /></span>
          <div><small>Downloads</small><h2>Configurações</h2></div>
          <button type="button" className="dx-x" onClick={onClose} aria-label="Fechar"><Icon name="close" size={20} /></button>
        </header>

        <section className="dx-set-group">
          <Row icon="wifiOff" title="Só no Wi-Fi" hint="Não gasta seu pacote de dados">
            <Switch on={d.wifiOnly} onChange={d.setWifiOnly} label="Baixar só no Wi-Fi" />
          </Row>
          <Row icon="users" title="Usar nas salas" hint="Se você já baixou o filme, a sala toca o arquivo do aparelho e não gasta internet com o vídeo">
            <Switch on={rooms} onChange={(v) => { setRooms(v); setRoomsLocalPref(v); }} label="Usar downloads nas salas" />
          </Row>
        </section>

        <section className="dx-set-group">
          <div className="dx-set-block">
            <div className="dx-set-title"><Icon name="trending" size={17} /> Velocidade do download</div>
            <div className="dx-seg">
              {SPEEDS.map((x) => (
                <button key={x.v} type="button" className={d.speed === x.v ? "on" : ""} onClick={() => d.setSpeed(x.v)}>{x.label}</button>
              ))}
            </div>
            <small className="dx-set-hint">“Turbo” usa o máximo de conexões e mantém o Wi-Fi e o processador em alto desempenho durante o download. Se o servidor reclamar, o app diminui o ritmo sozinho.</small>
          </div>
          <div className="dx-set-block">
            <div className="dx-set-title"><Icon name="film" size={17} /> Qualidade dos próximos downloads</div>
            <div className="dx-seg">
              {QUALITIES.map((q) => (
                <button key={q.v} type="button" className={quality === q.v ? "on" : ""} onClick={() => { setQ(q.v); setQuality(q.v); }}>{q.label}</button>
              ))}
            </div>
            <small className="dx-set-hint">Qualidade menor baixa mais rápido e ocupa menos espaço no celular.</small>
          </div>
        </section>

        <button type="button" className="dx-ok" onClick={onClose}>Pronto</button>
      </div>
    </div>,
    document.body,
  );
}

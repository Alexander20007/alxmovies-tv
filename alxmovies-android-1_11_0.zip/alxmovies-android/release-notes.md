## Melhorado
- Laura IA com nova tela e opções na engrenagem
- Downloads mais rápidos

## Melhorado
- Laura IA com nova tela e opções na engrenagem
- Downloads mais rápidos e tela de Downloads renovada
- Canais ao vivo e busca renovados
- Filmes e séries com tipo e ano nas capas
- Salas: avançar o filme não recomeça mais do início

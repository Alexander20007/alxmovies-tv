-- ============================================================================
-- ALXmovies — BLOQUEIO DE IP E DE PAÍS
-- Rode DEPOIS de: admin-painel.sql e api-endpoints.sql. Pode rodar de novo sem problema.
--
-- • O dono bloqueia um IP, um intervalo de IPs (ex.: 203.0.113.0/24) ou um país (código de 2 letras, ex.: BR) no painel: Admin → 🚫 Bloqueios.
-- • O app pergunta ao servidor se o aparelho está bloqueado e mostra a tela "Acesso indisponível".
-- • Quem está bloqueado também deixa de receber os endereços das APIs de filmes e canais (get_api_endpoints devolve vazio).
-- • O dono nunca é bloqueado (não perde o acesso ao painel) e o painel recusa bloquear o IP/país que você está usando agora.
-- • Se o servidor não conseguir descobrir o IP/país, NÃO bloqueia (falha para o lado de deixar entrar).
-- ============================================================================
create table if not exists public.access_blocks (
  id         bigint generated always as identity primary key,
  kind       text not null check (kind in ('ip', 'country')),
  value      text not null,          -- IP/intervalo como foi digitado, ou código do país (ex.: BR)
  net        inet,                   -- só para kind = 'ip'
  reason     text,
  created_at timestamptz not null default now(),
  created_by uuid default auth.uid(),
  unique (kind, value)
);
alter table public.access_blocks enable row level security;   -- sem policies: só as funções abaixo mexem

-- IP e país de quem está chamando, como o servidor enxerga (vêm nos cabeçalhos da requisição).
create or replace function public._req_ip() returns inet language plpgsql stable as $$
declare h jsonb; v text;
begin
  begin h := current_setting('request.headers', true)::jsonb; exception when others then return null; end;
  if h is null then return null; end if;
  v := coalesce(nullif(h->>'cf-connecting-ip', ''), nullif(btrim(split_part(coalesce(h->>'x-forwarded-for', ''), ',', 1)), ''), nullif(h->>'x-real-ip', ''));
  if v is null then return null; end if;
  begin return v::inet; exception when others then return null; end;
end $$;

create or replace function public._req_country() returns text language plpgsql stable as $$
declare h jsonb; c text;
begin
  begin h := current_setting('request.headers', true)::jsonb; exception when others then return null; end;
  if h is null then return null; end if;
  c := upper(nullif(h->>'cf-ipcountry', ''));
  if c is null or c !~ '^[A-Z]{2}$' or c in ('XX', 'T1') then return null; end if;
  return c;
end $$;

-- O app chama isto ao abrir. O dono nunca é bloqueado.
create or replace function public.check_access() returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare ip inet := public._req_ip(); c text := public._req_country(); r record;
begin
  if public.is_app_admin() then return jsonb_build_object('blocked', false); end if;
  select b.kind into r from public.access_blocks b
   where (b.kind = 'country' and c is not null and b.value = c)
      or (b.kind = 'ip' and ip is not null and b.net is not null and ip <<= b.net)
   limit 1;
  if found then return jsonb_build_object('blocked', true, 'kind', r.kind); end if;
  return jsonb_build_object('blocked', false);
end $$;

-- Quem está bloqueado não recebe os endereços das APIs de filmes e canais.
create or replace function public.get_api_endpoints() returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if coalesce((public.check_access()->>'blocked')::boolean, false) then return '{}'::jsonb; end if;
  return coalesce((select jsonb_object_agg(key, url) from public.api_endpoints), '{}'::jsonb);
end $$;

-- ---- painel (só o dono) ----
create or replace function public.admin_my_access() returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  perform public._require_owner();
  return jsonb_build_object('ip', host(public._req_ip()), 'country', public._req_country());
end $$;

create or replace function public.admin_access_blocks()
returns table (id bigint, kind text, value text, reason text, created_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  perform public._require_owner();
  return query select b.id, b.kind, b.value, b.reason, b.created_at from public.access_blocks b order by b.created_at desc;
end $$;

create or replace function public.admin_add_access_block(p_kind text, p_value text, p_reason text default null)
returns void language plpgsql security definer set search_path = public as $$
declare v text := btrim(coalesce(p_value, '')); n inet; me_ip inet := public._req_ip(); me_c text := public._req_country();
begin
  perform public._require_owner();
  if p_kind = 'country' then
    v := upper(v);
    if v !~ '^[A-Z]{2}$' then raise exception 'País: use o código de 2 letras (ex.: BR, AO, MZ, PT).'; end if;
    if me_c is not null and me_c = v then raise exception 'Você está acessando deste país (%): bloquear travaria você mesmo.', v; end if;
    insert into public.access_blocks (kind, value, reason) values ('country', v, nullif(btrim(coalesce(p_reason, '')), ''))
      on conflict (kind, value) do update set reason = excluded.reason;
  elsif p_kind = 'ip' then
    begin n := v::inet; exception when others then raise exception 'IP inválido. Exemplos: 203.0.113.7 ou 203.0.113.0/24'; end;
    if me_ip is not null and me_ip <<= n then raise exception 'Este IP/intervalo inclui o seu IP atual: bloquear travaria você mesmo.'; end if;
    insert into public.access_blocks (kind, value, net, reason) values ('ip', v, n, nullif(btrim(coalesce(p_reason, '')), ''))
      on conflict (kind, value) do update set reason = excluded.reason, net = excluded.net;
  else
    raise exception 'Tipo inválido.';
  end if;
  perform public._audit('bloqueio_add', null, jsonb_build_object('tipo', p_kind, 'valor', v));
end $$;

create or replace function public.admin_remove_access_block(p_id bigint)
returns void language plpgsql security definer set search_path = public as $$
declare r record;
begin
  perform public._require_owner();
  delete from public.access_blocks where id = p_id returning kind, value into r;
  if found then perform public._audit('bloqueio_remove', null, jsonb_build_object('tipo', r.kind, 'valor', r.value)); end if;
end $$;

revoke execute on function public.admin_my_access(), public.admin_access_blocks(),
  public.admin_add_access_block(text, text, text), public.admin_remove_access_block(bigint) from public, anon;
grant  execute on function public.admin_my_access(), public.admin_access_blocks(),
  public.admin_add_access_block(text, text, text), public.admin_remove_access_block(bigint) to authenticated;
grant  execute on function public.check_access(), public.get_api_endpoints() to anon, authenticated;

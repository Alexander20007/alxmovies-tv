-- ============================================================================
-- ALXmovies — LIMITES POR PLANO (salas), TÍTULOS SÓ-SALA e REGRAS DE CANAIS POR CATEGORIA
-- JÁ INSTALADO no Supabase do projeto (migrações planos_funcoes_1 e _2). Rode só em OUTRO projeto, depois do admin-painel.sql.
-- Tudo começa liberado/ilimitado (-1): nada muda até o dono configurar no painel (/admin → Planos e Salas e canais).
-- ============================================================================
alter table public.plans add column if not exists rooms_join_per_month   int     not null default -1;  -- -1 ilimitado, 0 bloqueado
alter table public.plans add column if not exists rooms_create_per_month int     not null default -1;
alter table public.plans add column if not exists rooms_max_members     int     not null default -1;  -- lotação das salas que a pessoa cria
alter table public.plans add column if not exists rooms_local_playback   boolean not null default true; -- pode usar o filme baixado na sala

create table if not exists public.room_usage (
  user_id uuid not null references auth.users(id) on delete cascade, period text not null,
  joins int not null default 0, creates int not null default 0, primary key (user_id, period));
alter table public.room_usage enable row level security;
drop policy if exists room_usage_own on public.room_usage;
create policy room_usage_own on public.room_usage for select using (auth.uid() = user_id);

create table if not exists public.room_titles (
  id bigint generated always as identity primary key, tmdb_id int not null, media_type text not null check (media_type in ('movie','tv')),
  title text not null, poster_path text, rooms_only boolean not null default true, allowed_plans text[], note text,
  created_by uuid references auth.users(id) on delete set null, created_at timestamptz not null default now(), unique (tmdb_id, media_type));
alter table public.room_titles enable row level security;
drop policy if exists room_titles_read on public.room_titles;
create policy room_titles_read on public.room_titles for select to anon, authenticated using (true);

create table if not exists public.channel_category_rules (
  category text primary key, allowed_plans text[], hidden boolean not null default false, updated_at timestamptz not null default now());
alter table public.channel_category_rules enable row level security;
drop policy if exists channel_rules_read on public.channel_category_rules;
create policy channel_rules_read on public.channel_category_rules for select to anon, authenticated using (true);

-- As funções (_effective_plan, get_my_plan, create_watch_room, join_watch_room, admin_plan_features_update,
-- admin_room_title_save/remove, admin_channel_rule_set) estão nas migrações aplicadas no Supabase
-- (consulte "Database → Migrations": planos_funcoes_1_tabelas_e_limites e planos_funcoes_2_regras_nas_salas_e_admin).
-- Erros de regra começam com PLANO_ (PLANO_CRIAR, PLANO_ENTRAR, PLANO_SALA_CHEIA, PLANO_TITULO): o app mostra o convite para ver os planos.

-- ============================================================================
-- ALXmovies — PAINEL DO DONO (v2): usuários, versão do app, mensagens oficiais, planos, códigos, salas, registro
-- Rode DEPOIS de: planos-e-anuncios.sql, planos-site-login.sql, avisos.sql, admins.sql, admin-selo.sql, push-notifications.sql.
-- Pode rodar de novo sem problema.
--
-- PRIVACIDADE (regra do painel): o dono NUNCA vê o que a pessoa assiste, favoritos, histórico, conversas de amigos ou
-- mensagens de sala. O painel só enxerga dados de CONTA e do APARELHO: nome de usuário, e-mail MASCARADO (j***@gmail.com),
-- data de criação, última vez que abriu o app, versão do app, sistema (Android/web), modelo do aparelho, plano e uso de downloads.
-- ============================================================================

-- 1) Informações do aparelho (uma linha por conta: o último aparelho/versão que abriu o app) ---------------------------------
create table if not exists public.app_devices (
  user_id     uuid primary key references auth.users(id) on delete cascade,
  app_version text,
  platform    text,                 -- android | web
  os          text,                 -- ex.: Android 13
  model       text,                 -- ex.: SM-A135F
  first_seen  timestamptz not null default now(),
  last_seen   timestamptz not null default now(),
  opens       int not null default 1
);
create index if not exists app_devices_version_idx on public.app_devices (app_version);
create index if not exists app_devices_seen_idx on public.app_devices (last_seen desc);
alter table public.app_devices enable row level security;   -- sem policies: ninguém lê direto (só as funções do dono)

-- 2) Mensagens oficiais (aparecem no app em Mensagens → ALXmovies) ------------------------------------------------------------
create table if not exists public.admin_messages (
  id         bigint generated always as identity primary key,
  user_id    uuid not null references auth.users(id) on delete cascade,   -- quem recebe
  title      text not null check (char_length(title) between 1 and 80),
  body       text not null check (char_length(body) between 1 and 1000),
  url        text check (url is null or (url ~* '^https://' and char_length(url) <= 300)),
  kind       text not null default 'aviso' check (kind in ('aviso', 'atualizacao', 'plano', 'suporte')),
  push       boolean not null default false,
  batch_id   uuid,                                                          -- mesmo envio para várias pessoas
  sent_by    uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  read_at    timestamptz
);
create index if not exists admin_messages_user_idx on public.admin_messages (user_id, created_at desc);
create index if not exists admin_messages_batch_idx on public.admin_messages (batch_id);
alter table public.admin_messages enable row level security;
drop policy if exists admin_messages_own on public.admin_messages;
create policy admin_messages_own on public.admin_messages for select using (auth.uid() = user_id);

-- 3) Registro de tudo que o dono faz no painel ---------------------------------------------------------------------------------
create table if not exists public.admin_audit (
  id         bigint generated always as identity primary key,
  admin_id   uuid references auth.users(id) on delete set null,
  action     text not null,
  target     uuid,
  details    jsonb,
  created_at timestamptz not null default now()
);
create index if not exists admin_audit_idx on public.admin_audit (created_at desc);
alter table public.admin_audit enable row level security;

-- 4) Anotações internas do dono sobre uma conta (a pessoa nunca vê) -------------------------------------------------------------
create table if not exists public.admin_notes (
  user_id    uuid primary key references auth.users(id) on delete cascade,
  note       text not null default '' check (char_length(note) <= 1000),
  updated_at timestamptz not null default now()
);
alter table public.admin_notes enable row level security;

-- ============================================================================
-- APOIO
-- ============================================================================
create or replace function public._require_owner()
returns void language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_app_admin() then raise exception 'sem permissão'; end if;
end $$;
revoke all on function public._require_owner() from public, anon, authenticated;

create or replace function public._audit(p_action text, p_target uuid, p_details jsonb default null)
returns void language sql security definer set search_path = public as $$
  insert into public.admin_audit (admin_id, action, target, details) values (auth.uid(), p_action, p_target, p_details);
$$;
revoke all on function public._audit(text, uuid, jsonb) from public, anon, authenticated;

-- "1.8.0" → {1,8,0,0} (para comparar versões do app)
create or replace function public._ver_arr(v text)
returns int[] language sql immutable as $$
  select (coalesce(string_to_array(nullif(regexp_replace(coalesce(v, ''), '[^0-9.]', '', 'g'), ''), '.')::int[], '{}'::int[]) || array[0, 0, 0, 0])[1:4];
$$;

create or replace function public._mask_email(e text)
returns text language sql immutable as $$
  select case when e is null or e = '' then null
              else left(split_part(e, '@', 1), 1) || '***@' || split_part(e, '@', 2) end;
$$;

-- plano que vale hoje para a conta (plano vencido = free)
create or replace function public._plan_of(p_uid uuid)
returns text language sql stable security definer set search_path = public as $$
  select coalesce((select plan_id from public.user_plans where user_id = p_uid and (expires_at is null or expires_at > now())), 'free');
$$;
revoke all on function public._plan_of(uuid) from public, anon, authenticated;

-- ============================================================================
-- LADO DO USUÁRIO (qualquer conta logada)
-- ============================================================================

-- O app avisa a versão em que está (no máximo 1 vez a cada poucas horas). Só estes 4 dados, nada pessoal.
create or replace function public.report_app_info(p_version text, p_platform text, p_os text default null, p_model text default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return; end if;
  insert into public.app_devices (user_id, app_version, platform, os, model)
  values (auth.uid(), left(p_version, 20), case when p_platform in ('android', 'web') then p_platform else 'android' end, left(p_os, 40), left(p_model, 60))
  on conflict (user_id) do update
    set app_version = excluded.app_version, platform = excluded.platform, os = excluded.os, model = excluded.model,
        last_seen = now(), opens = public.app_devices.opens + 1;
end $$;

create or replace function public.my_admin_messages(p_limit int default 60)
returns setof public.admin_messages
language sql stable security definer set search_path = public as $$
  select * from public.admin_messages where user_id = auth.uid() order by created_at desc limit greatest(1, least(coalesce(p_limit, 60), 200));
$$;

create or replace function public.my_admin_unread()
returns int language sql stable security definer set search_path = public as $$
  select count(*)::int from public.admin_messages where user_id = auth.uid() and read_at is null;
$$;

create or replace function public.mark_admin_messages_read()
returns void language sql security definer set search_path = public as $$
  update public.admin_messages set read_at = now() where user_id = auth.uid() and read_at is null;
$$;

grant execute on function public.report_app_info(text, text, text, text) to authenticated;
grant execute on function public.my_admin_messages(int)                  to authenticated;
grant execute on function public.my_admin_unread()                       to authenticated;
grant execute on function public.mark_admin_messages_read()              to authenticated;

-- ============================================================================
-- SÓ O DONO
-- ============================================================================

-- Painel de resumo
create or replace function public.admin_dashboard()
returns json language plpgsql stable security definer set search_path = public as $$
declare per text := to_char(now() at time zone 'America/Sao_Paulo', 'YYYY-MM'); r json;
begin
  perform public._require_owner();
  with u as (
    select a.id, a.created_at, coalesce(a.is_anonymous, false) as guest,
           greatest(d.last_seen, a.last_sign_in_at) as seen, d.app_version, d.platform
      from auth.users a left join public.app_devices d on d.user_id = a.id
  )
  select json_build_object(
    'users_total',   (select count(*) from u where not guest),
    'guests',        (select count(*) from u where guest),
    'new_24h',       (select count(*) from u where not guest and created_at > now() - interval '24 hours'),
    'new_7d',        (select count(*) from u where not guest and created_at > now() - interval '7 days'),
    'active_24h',    (select count(*) from u where seen > now() - interval '24 hours'),
    'active_7d',     (select count(*) from u where seen > now() - interval '7 days'),
    'active_30d',    (select count(*) from u where seen > now() - interval '30 days'),
    'reporting',     (select count(*) from u where app_version is not null),
    'by_version',    coalesce((select json_agg(x order by x.n desc) from (select app_version as version, count(*) as n from u where app_version is not null group by 1 order by 2 desc limit 12) x), '[]'::json),
    'by_platform',   coalesce((select json_agg(x) from (select platform, count(*) as n from u where platform is not null group by 1) x), '[]'::json),
    'by_plan',       coalesce((select json_agg(x) from (select public._plan_of(u.id) as plan, count(*) as n from u where not guest group by 1) x), '[]'::json),
    'downloads_month', coalesce((select sum(used) from public.download_counters where period = per), 0),
    'rooms_active',  (select count(*) from public.watch_rooms where is_active),
    'rooms_playing', (select count(*) from public.watch_rooms where is_active and is_playing),
    'push_devices',  (select count(*) from public.push_tokens),
    'proposals',     (select count(*) from public.announcement_proposals where status = 'pending'),
    'staff',         (select count(*) from public.app_staff),
    'codes_open',    (select count(*) from public.promo_codes where redeemed_by is null and expires_at > now() and code not like 'X%'),
    'messages_unread', (select count(*) from public.admin_messages where read_at is null)
  ) into r;
  return r;
end $$;

-- Lista de usuários (só dados de conta/aparelho)
create or replace function public.admin_users(
  p_search text default null, p_version text default null, p_platform text default null, p_plan text default null,
  p_inactive_days int default null, p_only text default null, p_limit int default 30, p_offset int default 0)
returns table (
  user_id uuid, username text, email_masked text, created_at timestamptz, last_seen timestamptz, app_version text, platform text,
  os text, model text, plan_id text, plan_expires timestamptz, is_guest boolean, is_staff boolean, suspended boolean,
  profiles_count int, downloads_used int, total_count bigint)
language plpgsql stable security definer set search_path = public as $$
declare per text := to_char(now() at time zone 'America/Sao_Paulo', 'YYYY-MM'); s text := nullif(trim(coalesce(p_search, '')), '');
begin
  perform public._require_owner();
  return query
  with base as (
    select a.id,
           coalesce(a.raw_user_meta_data->>'username', 'sem nome') as uname,
           a.email, a.created_at as created, a.banned_until,
           greatest(d.last_seen, a.last_sign_in_at) as seen,
           d.app_version as ver, d.platform as plat, d.os as dos, d.model as dmodel,
           coalesce(a.is_anonymous, false) as guest,
           public._plan_of(a.id) as pl,
           (select up.expires_at from public.user_plans up where up.user_id = a.id and (up.expires_at is null or up.expires_at > now())) as pl_exp,
           public._is_staffer(a.id) as staff,
           (select count(*)::int from public.profiles p where p.user_id = a.id) as np,
           coalesce((select c.used from public.download_counters c where c.user_id = a.id and c.period = per), 0) as dl
      from auth.users a left join public.app_devices d on d.user_id = a.id
  ), f as (
    select * from base b
     where (s is null
            or b.uname ilike '%' || s || '%'
            or b.id::text like lower(s) || '%'
            or lower(coalesce(b.email, '')) = lower(s)
            or exists (select 1 from public.profiles p where p.user_id = b.id and p.name ilike '%' || s || '%'))
       and (p_version is null or p_version = '' or b.ver = p_version)
       and (p_platform is null or p_platform = '' or b.plat = p_platform)
       and (p_plan is null or p_plan = '' or b.pl = p_plan)
       and (p_inactive_days is null or coalesce(b.seen, b.created) < now() - make_interval(days => p_inactive_days))
       and (p_only is null or p_only = ''
            or (p_only = 'staff' and b.staff)
            or (p_only = 'guest' and b.guest)
            or (p_only = 'real' and not b.guest)
            or (p_only = 'suspended' and b.banned_until is not null and b.banned_until > now())
            or (p_only = 'no_info' and b.ver is null))
  )
  select f.id, f.uname, public._mask_email(f.email), f.created, f.seen, f.ver, f.plat, f.dos, f.dmodel, f.pl, f.pl_exp,
         f.guest, f.staff, (f.banned_until is not null and f.banned_until > now()), f.np, f.dl::int, count(*) over ()
    from f order by coalesce(f.seen, f.created) desc
   limit greatest(1, least(coalesce(p_limit, 30), 100)) offset greatest(coalesce(p_offset, 0), 0);
end $$;

-- Ficha de uma conta (sem histórico de filmes, sem conversas)
create or replace function public.admin_user_detail(p_user uuid)
returns json language plpgsql stable security definer set search_path = public as $$
declare per text := to_char(now() at time zone 'America/Sao_Paulo', 'YYYY-MM'); r json;
begin
  perform public._require_owner();
  select json_build_object(
    'user_id', a.id,
    'username', coalesce(a.raw_user_meta_data->>'username', 'sem nome'),
    'email_masked', public._mask_email(a.email),
    'created_at', a.created_at,
    'last_sign_in', a.last_sign_in_at,
    'is_guest', coalesce(a.is_anonymous, false),
    'suspended', (a.banned_until is not null and a.banned_until > now()),
    'is_staff', public._is_staffer(a.id),
    'is_owner', exists (select 1 from public.app_admins x where x.user_id = a.id),
    'device', (select row_to_json(d) from (select app_version, platform, os, model, first_seen, last_seen, opens from public.app_devices where user_id = a.id) d),
    'plan', (select row_to_json(p) from (select plan_id, expires_at, source, updated_at from public.user_plans where user_id = a.id) p),
    'plan_now', public._plan_of(a.id),
    'downloads', (select row_to_json(c) from (select used, bonus from public.download_counters where user_id = a.id and period = per) c),
    'profiles', coalesce((select json_agg(json_build_object('name', p.name, 'kids', coalesce(p.is_kids, false)) order by p.created_at) from public.profiles p where p.user_id = a.id), '[]'::json),
    'push_devices', (select count(*) from public.push_tokens where user_id = a.id),
    'note', coalesce((select note from public.admin_notes where user_id = a.id), ''),
    'messages', json_build_object(
      'sent', (select count(*) from public.admin_messages where user_id = a.id),
      'unread', (select count(*) from public.admin_messages where user_id = a.id and read_at is null)),
    'recent', coalesce((select json_agg(x order by x.created_at desc) from (select action, details, created_at from public.admin_audit where target = a.id order by created_at desc limit 8) x), '[]'::json)
  ) into r from auth.users a where a.id = p_user;
  if r is null then raise exception 'Conta não encontrada.'; end if;
  return r;
end $$;

-- Ativar / trocar / remover plano de uma conta (p_days nulo ou 0 = sem vencimento; plano 'free' remove o plano pago)
create or replace function public.admin_set_plan(p_user uuid, p_plan text, p_days int default null)
returns json language plpgsql security definer set search_path = public as $$
declare exp timestamptz;
begin
  perform public._require_owner();
  if not exists (select 1 from auth.users where id = p_user) then raise exception 'Conta não encontrada.'; end if;
  if p_plan is null or p_plan = 'free' then
    delete from public.user_plans where user_id = p_user;
    perform public._audit('plano_removido', p_user, null);
    return json_build_object('ok', true, 'plan', 'free');
  end if;
  if not exists (select 1 from public.plans where id = p_plan) then raise exception 'Plano inexistente.'; end if;
  exp := case when coalesce(p_days, 0) > 0 then now() + make_interval(days => least(p_days, 3650)) else null end;
  insert into public.user_plans (user_id, plan_id, expires_at, source) values (p_user, p_plan, exp, 'admin')
  on conflict (user_id) do update set plan_id = excluded.plan_id, expires_at = excluded.expires_at, source = 'admin', updated_at = now();
  perform public._audit('plano_ativado', p_user, jsonb_build_object('plano', p_plan, 'dias', p_days));
  return json_build_object('ok', true, 'plan', p_plan, 'expires_at', exp);
end $$;

-- Dar downloads extras neste mês / zerar o contador do mês
create or replace function public.admin_add_bonus(p_user uuid, p_n int)
returns void language plpgsql security definer set search_path = public as $$
declare per text := to_char(now() at time zone 'America/Sao_Paulo', 'YYYY-MM');
begin
  perform public._require_owner();
  if coalesce(p_n, 0) = 0 or abs(p_n) > 1000 then raise exception 'Quantidade inválida (1 a 1000).'; end if;
  insert into public.download_counters (user_id, period, bonus) values (p_user, per, greatest(p_n, 0))
  on conflict (user_id, period) do update set bonus = greatest(public.download_counters.bonus + p_n, 0);
  perform public._audit('bonus_downloads', p_user, jsonb_build_object('qtd', p_n));
end $$;

create or replace function public.admin_reset_downloads(p_user uuid)
returns void language plpgsql security definer set search_path = public as $$
declare per text := to_char(now() at time zone 'America/Sao_Paulo', 'YYYY-MM');
begin
  perform public._require_owner();
  update public.download_counters set used = 0 where user_id = p_user and period = per;
  perform public._audit('downloads_zerados', p_user, null);
end $$;

create or replace function public.admin_set_note(p_user uuid, p_note text)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public._require_owner();
  insert into public.admin_notes (user_id, note) values (p_user, left(coalesce(p_note, ''), 1000))
  on conflict (user_id) do update set note = excluded.note, updated_at = now();
end $$;

-- Suspender / reativar o acesso de uma conta (não vale para você nem para outros donos)
create or replace function public.admin_set_suspended(p_user uuid, p_suspended boolean)
returns void language plpgsql security definer set search_path = public, auth as $$
begin
  perform public._require_owner();
  if p_user = auth.uid() or exists (select 1 from public.app_admins where user_id = p_user) then raise exception 'Não é possível suspender um dono.'; end if;
  update auth.users set banned_until = case when p_suspended then now() + interval '100 years' else null end where id = p_user;
  perform public._audit(case when p_suspended then 'conta_suspensa' else 'conta_reativada' end, p_user, null);
end $$;

-- Colocar alguém na equipe de admins (sem precisar do teste)
create or replace function public.admin_staff_add(p_user uuid, p_can_publish boolean default false)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public._require_owner();
  if not exists (select 1 from auth.users where id = p_user and coalesce(is_anonymous, false) = false) then raise exception 'Só contas reais podem ser admin.'; end if;
  insert into public.app_staff (user_id, can_publish, granted_via) values (p_user, coalesce(p_can_publish, false), 'owner')
  on conflict (user_id) do update set can_publish = excluded.can_publish;
  perform public._audit('admin_adicionado', p_user, jsonb_build_object('publica', p_can_publish));
end $$;

-- ---- quem recebe uma mensagem ----
create or replace function public._audience(p_aud jsonb)
returns setof uuid language plpgsql stable security definer set search_path = public as $$
declare t text := coalesce(p_aud->>'type', '');
begin
  if t = 'user' then
    return query select id from auth.users where id = (p_aud->>'user_id')::uuid;
  elsif t = 'all' then
    return query select id from auth.users where coalesce(is_anonymous, false) = false and (banned_until is null or banned_until < now());
  elsif t = 'version_below' then
    return query select d.user_id from public.app_devices d join auth.users a on a.id = d.user_id
      where coalesce(a.is_anonymous, false) = false and public._ver_arr(d.app_version) < public._ver_arr(p_aud->>'version');
  elsif t = 'version_is' then
    return query select d.user_id from public.app_devices d join auth.users a on a.id = d.user_id
      where coalesce(a.is_anonymous, false) = false and d.app_version = p_aud->>'version';
  elsif t = 'platform' then
    return query select d.user_id from public.app_devices d join auth.users a on a.id = d.user_id
      where coalesce(a.is_anonymous, false) = false and d.platform = p_aud->>'value';
  elsif t = 'plan' then
    return query select a.id from auth.users a where coalesce(a.is_anonymous, false) = false and public._plan_of(a.id) = p_aud->>'value';
  elsif t = 'inactive' then
    return query select a.id from auth.users a left join public.app_devices d on d.user_id = a.id
      where coalesce(a.is_anonymous, false) = false
        and coalesce(greatest(d.last_seen, a.last_sign_in_at), a.created_at) < now() - make_interval(days => greatest(1, coalesce((p_aud->>'days')::int, 14)));
  elsif t = 'new' then
    return query select a.id from auth.users a where coalesce(a.is_anonymous, false) = false
      and a.created_at > now() - make_interval(days => greatest(1, coalesce((p_aud->>'days')::int, 7)));
  elsif t = 'staff' then
    return query select user_id from public.app_staff;
  end if;
end $$;
revoke all on function public._audience(jsonb) from public, anon, authenticated;

-- Quantas pessoas receberiam (para mostrar antes de enviar)
create or replace function public.admin_audience_count(p_aud jsonb)
returns int language plpgsql stable security definer set search_path = public as $$
begin
  perform public._require_owner();
  return (select count(*)::int from public._audience(p_aud));
end $$;

-- Envia a mensagem oficial. Push: para "todos" vai um aviso único pelo tópico; para grupos até 300 pessoas, push individual.
create or replace function public.admin_send_message(p_aud jsonb, p_title text, p_body text, p_url text default null, p_kind text default 'aviso', p_push boolean default true)
returns json language plpgsql security definer set search_path = public, extensions as $$
declare bid uuid := gen_random_uuid(); n int; do_push boolean; is_all boolean := coalesce((p_aud->>'type') = 'all', false);
begin
  perform public._require_owner();
  if char_length(trim(coalesce(p_title, ''))) = 0 or char_length(trim(coalesce(p_body, ''))) = 0 then raise exception 'Escreva o título e a mensagem.'; end if;
  select count(*)::int into n from public._audience(p_aud);
  if n = 0 then raise exception 'Nenhuma conta encontrada para esse público.'; end if;
  if n > 20000 then raise exception 'Público grande demais (máx. 20000).'; end if;
  do_push := coalesce(p_push, true) and not is_all and n <= 300;

  insert into public.admin_messages (user_id, title, body, url, kind, push, batch_id, sent_by)
  select u, trim(p_title), trim(p_body), nullif(trim(coalesce(p_url, '')), ''), coalesce(p_kind, 'aviso'), do_push, bid, auth.uid()
    from public._audience(p_aud) u;

  if is_all and coalesce(p_push, true) then
    begin
      perform net.http_post(
        url := 'https://onqxflwfkexitipylixc.supabase.co/functions/v1/push-send',
        headers := jsonb_build_object('Content-Type', 'application/json', 'x-push-secret', 'TROQUE_ESTE_SEGREDO'),
        body := jsonb_build_object('table', 'admin_broadcast', 'record', jsonb_build_object('title', trim(p_title), 'body', trim(p_body))));
    exception when others then null;
    end;
  end if;

  perform public._audit('mensagem_enviada', null, jsonb_build_object('publico', p_aud, 'titulo', trim(p_title), 'pessoas', n, 'lote', bid));
  return json_build_object('ok', true, 'sent', n, 'batch', bid, 'push', coalesce(p_push, true) and (is_all or do_push));
end $$;

-- Histórico de envios (agrupado por lote)
create or replace function public.admin_messages_history(p_limit int default 40)
returns table (batch_id uuid, title text, body text, kind text, created_at timestamptz, recipients bigint, read_count bigint)
language plpgsql stable security definer set search_path = public as $$
begin
  perform public._require_owner();
  return query
    select coalesce(m.batch_id, gen_random_uuid()), max(m.title), max(m.body), max(m.kind), max(m.created_at), count(*), count(m.read_at)
      from public.admin_messages m group by m.batch_id, case when m.batch_id is null then m.id end
     order by max(m.created_at) desc limit greatest(1, least(coalesce(p_limit, 40), 200));
end $$;

create or replace function public.admin_recall_batch(p_batch uuid)
returns int language plpgsql security definer set search_path = public as $$
declare n int;
begin
  perform public._require_owner();
  delete from public.admin_messages where batch_id = p_batch;
  get diagnostics n = row_count;
  perform public._audit('mensagem_apagada', null, jsonb_build_object('lote', p_batch, 'pessoas', n));
  return n;
end $$;

-- Gatilho de push individual (usa a mesma função/segredo das mensagens de amigos)
drop trigger if exists push_on_admin_message on public.admin_messages;
create trigger push_on_admin_message after insert on public.admin_messages
  for each row when (new.push) execute function public.push_notify();

-- ---- planos e códigos ----
create or replace function public.admin_plans_update(p_id text, p_name text, p_downloads int, p_show_ads boolean, p_price numeric)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public._require_owner();
  if p_downloads < 0 or p_downloads > 100000 then raise exception 'Limite de downloads inválido.'; end if;
  update public.plans set name = left(trim(p_name), 30), downloads_per_month = p_downloads, show_ads = coalesce(p_show_ads, false), price_brl = p_price where id = p_id;
  perform public._audit('plano_editado', null, jsonb_build_object('plano', p_id, 'downloads', p_downloads, 'anuncios', p_show_ads, 'preco', p_price));
end $$;

create or replace function public.admin_codes_create(p_plan text, p_days int, p_bonus int, p_qty int default 1, p_valid_days int default 30, p_label text default null)
returns json language plpgsql security definer set search_path = public as $$
declare i int; c text; made text[] := '{}'; lbl text;
begin
  perform public._require_owner();
  if p_qty < 1 or p_qty > 100 then raise exception 'Quantidade de códigos: 1 a 100.'; end if;
  if (p_plan is null or coalesce(p_days, 0) = 0) and coalesce(p_bonus, 0) = 0 then raise exception 'Escolha um plano com dias ou downloads extras.'; end if;
  if p_plan is not null and not exists (select 1 from public.plans where id = p_plan) then raise exception 'Plano inexistente.'; end if;
  lbl := coalesce(nullif(trim(p_label), ''), case when p_plan is not null and coalesce(p_days, 0) > 0 then initcap(p_plan) || ' por ' || p_days || ' dias' else '+' || p_bonus || ' downloads' end);
  for i in 1..p_qty loop
    c := 'ALX-' || upper(substr(md5(random()::text || clock_timestamp()::text || i), 1, 4)) || '-' || upper(substr(md5(random()::text || clock_timestamp()::text || i), 5, 4));
    insert into public.promo_codes (code, plan_id, days, bonus_downloads, prize_label, expires_at)
    values (c, case when coalesce(p_days, 0) > 0 then p_plan end, nullif(p_days, 0), coalesce(p_bonus, 0), lbl, now() + make_interval(days => greatest(1, least(coalesce(p_valid_days, 30), 365))));
    made := made || c;
  end loop;
  perform public._audit('codigos_criados', null, jsonb_build_object('qtd', p_qty, 'plano', p_plan, 'dias', p_days, 'bonus', p_bonus));
  return json_build_object('ok', true, 'codes', to_json(made), 'label', lbl);
end $$;

create or replace function public.admin_codes_list(p_limit int default 60)
returns table (code text, prize_label text, plan_id text, days int, bonus_downloads int, created_at timestamptz, expires_at timestamptz, redeemed_by uuid, redeemed_name text, redeemed_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  perform public._require_owner();
  return query
    select c.code, c.prize_label, c.plan_id, c.days, c.bonus_downloads, c.created_at, c.expires_at, c.redeemed_by,
           (select coalesce(a.raw_user_meta_data->>'username', 'sem nome') from auth.users a where a.id = c.redeemed_by), c.redeemed_at
      from public.promo_codes c where c.code not like 'X%' order by c.created_at desc limit greatest(1, least(coalesce(p_limit, 60), 300));
end $$;

create or replace function public.admin_code_revoke(p_code text)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public._require_owner();
  delete from public.promo_codes where code = upper(trim(p_code)) and redeemed_by is null;
  perform public._audit('codigo_apagado', null, jsonb_build_object('codigo', upper(trim(p_code))));
end $$;

-- ---- salas (moderação: salas privadas não mostram o que estão assistindo) ----
create or replace function public.admin_rooms_list()
returns table (id uuid, title text, host_name text, is_private boolean, is_playing boolean, what text, members bigint, created_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  perform public._require_owner();
  return query
    select r.id, r.title, r.host_name, r.is_private, r.is_playing, case when r.is_private then null else r.movie_title end,
           (select count(*) from public.watch_room_members m where m.room_id = r.id), r.created_at
      from public.watch_rooms r where r.is_active order by r.created_at desc limit 100;
end $$;

create or replace function public.admin_close_room(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public._require_owner();
  update public.watch_rooms set is_active = false where id = p_id;
  perform public._audit('sala_encerrada', null, jsonb_build_object('sala', p_id));
end $$;

-- ---- registro ----
create or replace function public.admin_audit_list(p_limit int default 80)
returns table (id bigint, action text, target uuid, target_name text, details jsonb, created_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  perform public._require_owner();
  return query
    select a.id, a.action, a.target, (select coalesce(u.raw_user_meta_data->>'username', 'sem nome') from auth.users u where u.id = a.target), a.details, a.created_at
      from public.admin_audit a order by a.created_at desc limit greatest(1, least(coalesce(p_limit, 80), 300));
end $$;

grant execute on function public.admin_dashboard()                                                  to authenticated;
grant execute on function public.admin_users(text, text, text, text, int, text, int, int)         to authenticated;
grant execute on function public.admin_user_detail(uuid)                                            to authenticated;
grant execute on function public.admin_set_plan(uuid, text, int)                                    to authenticated;
grant execute on function public.admin_add_bonus(uuid, int)                                         to authenticated;
grant execute on function public.admin_reset_downloads(uuid)                                        to authenticated;
grant execute on function public.admin_set_note(uuid, text)                                         to authenticated;
grant execute on function public.admin_set_suspended(uuid, boolean)                                 to authenticated;
grant execute on function public.admin_staff_add(uuid, boolean)                                     to authenticated;
grant execute on function public.admin_audience_count(jsonb)                                        to authenticated;
grant execute on function public.admin_send_message(jsonb, text, text, text, text, boolean)         to authenticated;
grant execute on function public.admin_messages_history(int)                                        to authenticated;
grant execute on function public.admin_recall_batch(uuid)                                           to authenticated;
grant execute on function public.admin_plans_update(text, text, int, boolean, numeric)              to authenticated;
grant execute on function public.admin_codes_create(text, int, int, int, int, text)                 to authenticated;
grant execute on function public.admin_codes_list(int)                                              to authenticated;
grant execute on function public.admin_code_revoke(text)                                            to authenticated;
grant execute on function public.admin_rooms_list()                                                 to authenticated;
grant execute on function public.admin_close_room(uuid)                                             to authenticated;
grant execute on function public.admin_audit_list(int)                                              to authenticated;

-- (JÁ INSTALADO no Supabase do projeto, com a senha certa.) Se rodar este arquivo em OUTRO projeto, troque TROQUE_ESTE_SEGREDO pela MESMA senha que você usou no sql/push-notifications.sql
-- (e coloque o mesmo valor no secret PUSH_SECRET da Edge Function push-send).

-- ============================================================================
-- ALXmovies — ENDEREÇOS DAS APIs (filmes e canais) GUARDADOS NO SUPABASE
-- Rode DEPOIS de: admin-painel.sql. Pode rodar de novo sem problema (não apaga nem sobrescreve nada).
--
-- O app Android lê estes endereços ao abrir (e guarda uma cópia no aparelho). O dono troca pelo painel:
-- Admin → "🔌 APIs". Nada de endereço de API fica no código-fonte do app.
-- ============================================================================
create table if not exists public.api_endpoints (
  key        text primary key,
  label      text not null,
  url        text not null,
  note       text,
  updated_at timestamptz not null default now()
);
alter table public.api_endpoints enable row level security;   -- sem policies: só as funções abaixo mexem

insert into public.api_endpoints (key, label, url, note) values
  ('STREAM',    'Filmes e séries — API principal',   'https://alx-api.onrender.com',                                         'Player: servidores e links de vídeo.'),
  ('EXTRACTOR', 'Filmes e séries — API reserva',      'https://api-alex-jney.onrender.com',                                   'Entra se a principal falhar ou demorar (usada também nas salas).'),
  ('CHANNELS',  'TV ao vivo — lista de canais',       'https://alx-player.netlify.app/.netlify/functions/canais',             'Catálogo e busca de canais.'),
  ('EPG',       'TV ao vivo — programação (EPG)',     'https://alx-player.netlify.app/.netlify/functions/programacao',        'Guia do que está passando em cada canal.')
on conflict (key) do nothing;

-- O app lê (qualquer pessoa, mesmo sem login — o app precisa disto antes do login).
create or replace function public.get_api_endpoints()
returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_object_agg(key, url), '{}'::jsonb) from public.api_endpoints;
$$;

-- O painel lê a lista completa (só o dono).
create or replace function public.admin_api_endpoints()
returns table (key text, label text, url text, note text, updated_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  perform public._require_owner();
  return query select e.key, e.label, e.url, e.note, e.updated_at from public.api_endpoints e order by e.key;
end $$;

-- O painel troca um endereço (só o dono; precisa ser https://).
create or replace function public.admin_set_api_endpoint(p_key text, p_url text)
returns void language plpgsql security definer set search_path = public as $$
declare v text := regexp_replace(btrim(coalesce(p_url, '')), '/+$', '');
begin
  perform public._require_owner();
  if not exists (select 1 from public.api_endpoints where key = p_key) then raise exception 'API desconhecida.'; end if;
  if v !~ '^https://[^\s]+$' or length(v) > 300 then raise exception 'O endereço precisa começar com https:// e não ter espaços.'; end if;
  update public.api_endpoints set url = v, updated_at = now() where key = p_key;
  perform public._audit('api_editada', null, jsonb_build_object('api', p_key));
end $$;

revoke execute on function public.admin_api_endpoints()                 from public, anon;
revoke execute on function public.admin_set_api_endpoint(text, text)    from public, anon;
grant  execute on function public.get_api_endpoints()                   to anon, authenticated;
grant  execute on function public.admin_api_endpoints()                 to authenticated;
grant  execute on function public.admin_set_api_endpoint(text, text)    to authenticated;

-- ============================================================================
-- ALXmovies — NÚMERO DE DOWNLOADS MOSTRADO NO SITE
-- Rode DEPOIS de: admin-painel.sql. Pode rodar de novo sem problema.
--
-- Como funciona:
--   • O número do GitHub (contador real do APK) agora só aparece no painel do dono.
--   • O dono digita no painel (Resumo → "Downloads mostrados no site") o total que quer mostrar
--     (somando Lojas, outros sites etc.). Esse número aparece no site para todos, mesmo sem login.
-- ============================================================================
create table if not exists public.site_settings (
  key        text primary key,
  value      text not null,
  updated_at timestamptz not null default now()
);
alter table public.site_settings enable row level security;   -- sem policies: só as funções abaixo mexem

create or replace function public.get_public_downloads()
returns bigint language sql stable security definer set search_path = public as $$
  select coalesce((select nullif(value, '')::bigint from public.site_settings where key = 'public_downloads'), 0);
$$;

create or replace function public.admin_set_public_downloads(p_n bigint)
returns bigint language plpgsql security definer set search_path = public as $$
begin
  perform public._require_owner();
  if p_n is null or p_n < 0 or p_n > 10000000000 then raise exception 'Número inválido.'; end if;
  insert into public.site_settings (key, value, updated_at) values ('public_downloads', p_n::text, now())
  on conflict (key) do update set value = excluded.value, updated_at = now();
  perform public._audit('downloads_site', null, jsonb_build_object('numero', p_n));
  return p_n;
end $$;

grant execute on function public.get_public_downloads()          to anon, authenticated;
grant execute on function public.admin_set_public_downloads(bigint) to authenticated;

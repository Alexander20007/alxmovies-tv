# ALXmovies — React

Vite + React 18 + TypeScript + React Router + TanStack Query + Supabase (Realtime) + hls.js.

```bash
cp .env.example .env     # opcional: os valores padrão já apontam para o seu Supabase
npm install
npm run dev              # desenvolvimento
npm run typecheck        # só checagem de tipos
npm run build            # build de produção (dist/)
npm run build:strict     # typecheck + build
```

## Rotas
Públicas: `/login`, `/reset-password`, `/privacidade`, `/cookies`, `/seguranca`.
Com login: `/profiles`, `/manage-profiles`.
Com login + perfil: `/home`, `/details`, `/episodes`, `/info`, `/watch`, `/search`, `/mylist`, `/salas`, `/sala`, `/amigos`, `/mensagens`, `/account`.

## APIs de filmes e canais
Os endereços (player, API reserva, canais e EPG) ficam na tabela `api_endpoints` do Supabase (`sql/api-endpoints.sql`) e o dono troca em **Admin → 🔌 APIs**. O app guarda uma cópia no aparelho (`src/lib/endpoints.ts`).

## Bloqueio de IP e país
O dono bloqueia IPs (ou intervalos como `203.0.113.0/24`) e países em **Admin → 🚫 Bloqueios** (`sql/bloqueios.sql`). O app consulta `check_access()` ao abrir (`src/components/AccessGate.tsx`); o dono nunca é bloqueado e o painel recusa bloquear o IP/país que você está usando.

## Bloqueio de DNS (domínios)
O dono bloqueia domínios em **Admin → 🚫 Bloqueios → Domínios (DNS)** (`sql/dns-bloqueio.sql`). Bloquear `exemplo.com` bloqueia também todos os subdomínios. No Android o bloqueio vale na página (WebView), no player, nas salas, no baixador e no verificador de canais (`AlxHostBlock`); no JavaScript barra `fetch` e `XMLHttpRequest` (`src/lib/hostBlock.ts`). O painel não deixa bloquear o Supabase, o site nem o domínio de uma API em uso.

## Variáveis de ambiente (`.env.example`)
`VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, `VITE_TMDB_FUNCTION_URL`, `VITE_GEMINI_FUNCTION_URL`, `VITE_GEMINI_MODEL` (assistente de IA).

## Deploy no Netlify
`netlify.toml` já define: build (`npm run build` → `dist`), redirecionamento SPA, cabeçalhos de segurança (CSP) e cache.
1. Cadastre as variáveis `VITE_*` em *Site settings → Environment variables*.
2. Supabase → Authentication → URL Configuration: coloque o domínio do Netlify em *Site URL* e em *Redirect URLs*, incluindo `https://SEU-SITE.netlify.app/reset-password`.
3. Função Edge do Gemini (`smooth-endpoint`): inclua o domínio do Netlify na lista de origens permitidas.
4. Aplique no Supabase os SQL de `sql/` (salas: `watch-rooms*.sql`; amigos: `sql/amigos/parte-1` a `parte-7`).
5. Anúncios (só convidado): troque `data-ad-slot` em `src/components/Ads.tsx` pelo ID real do bloco do AdSense.

## Observações
- O PIN de perfil e a restrição de horário são conferidos no navegador (como no site original): servem para uso familiar, não como segurança forte.
- Preferência "avisos por e-mail" só grava a escolha; o envio de e-mails não existe (igual ao original).
- Service worker (`public/sw.js`): navegações são sempre buscadas na rede para não servir um `index.html` antigo após um deploy.

## App Android (Capacitor)
Veja `README-ANDROID.md`. Mesmo código do site: `lib/native.ts` detecta o app (`isNative`) e liga o que é só do Android.
